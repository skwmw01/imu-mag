/*
 * project.h
 *
 *  Created on: Mar 7, 2024
 *      Author: Michael.Oleksy
 */

#ifndef INC_PROJECT_HPP_
#define INC_PROJECT_HPP_

#include <stdint.h>
#include <stdbool.h>


typedef uint8_t  	UINT8;
typedef uint16_t   	UINT16;
typedef uint32_t   	UINT32;
typedef bool	   	BOOL;

#define PACK

typedef uint32_t 	long_time_ms_t;        // measured in milli-seconds
typedef int32_t 	sint32_t;


//using UINT8 = uint8_t;
//using UINT16 = uint16_t;
//using UINT32 = uint32_t;
//using BOOL = bool;


#endif /* INC_PROJECT_HPP_ */
