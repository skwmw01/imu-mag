/*
 * SPISetup.c
 *
 *  Created on: Apr 11, 2024
 *      Author: Michael.Oleksy
 */

#ifndef _SPIMANAGER_H_
#define _SPIMANAGER_H_

#include "SPIPort.h"
#include "SPIMain.h"
#include <vector>


// SPIManager was meant to be a C++ class.
// However, it needs to define callback functions to STM32 code (specifically for SPI comms).
// Having C callback functions reference a C++ class did not work...
#ifdef __cplusplus
extern "C"
{
#endif

extern UINT16 imuBitmapGrouping[3];

typedef struct
{
	UINT16	id;
	UINT8	spiIndex;
	UINT8	imuIndex;
}imuHardwareGroup_t;

#define IMUS_IN_GROUP 5
extern imuHardwareGroup_t imuHardwareGrouping[3][IMUS_IN_GROUP];


void SPIManager_SPIManager();

// SPI Setup functions
SPIPort* SPIManager_setupSPI1_4(UINT8 SPIPortNumber, bool initDMP);
SPIPort* SPIManager_setupSPI2_4(UINT8 SPIPortNumber, bool initDMP);
SPIPort* SPIManager_setupSPI3_7(UINT8 SPIPortNumber, bool initDMP);


std::vector<SPIPort*> SPIManager_getSPIPorts();

UINT8 SPIManager_numberOfSPIPorts();

bool SPIManager_receivedAllData();
void SPIManager_outputAllData();


#ifdef __cplusplus
}
#endif

#endif /* _SPIMANAGER_H_ */
