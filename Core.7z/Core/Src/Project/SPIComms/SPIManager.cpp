/*
 * SPISetup.cpp
 *
 *  Created on: Mar 15, 2024
 *      Author: Michael.Oleksy
 */

#include "main.h"
#include <vector>

#include <SPIBlock.hpp>
#include <SPIInt.hpp>

#include <IMU/ICMManager.h>
#include <IMU/CmdManager.h>
#include "SPIComms/SPImain.h"
#include "SPIComms/SPIPort.h"


// SPI buses
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef hspi3;


#ifdef __cplusplus
extern "C"
{
#endif

#include "SPIManager.h"



UINT8 NUMBER_OF_SPI_PORTS;

// There are 3 SPI ports
UINT16 imuBitmapGrouping[3];

// Group IMU's into 3 groups of 5
// IMU-ID, SPI-Port index, Index of IMU in SPI array
imuHardwareGroup_t imuHardwareGrouping[3][5] = {
{
	// Left leg + right lower arm
	{0x0001, 0, 0},
	{0x0002, 0, 1},
	{0x0004, 0, 2},
	{0x0008, 0, 3},
	{0x0200, 2, 1}
},
{
	// Right leg + right lower arm
	{0x0010, 1, 0},
	{0x0020, 1, 1},
	{0x0040, 1, 2},
	{0x0080, 1, 3},
	{0x1000, 2, 4}
},
{
	{0x0100, 2, 0},
	{0x0400, 2, 2},
	{0x0800, 2, 3},
	{0x2000, 2, 5},
	{0x4000, 2, 6},
}};



//extern std::vector<std::unique_ptr<SPIPort>> SPIPorts;
extern std::vector<SPIPort*> SPIPorts;


void IMU_Gap(void)
{
	for( UINT8 i=0 ; i<4 ; i++ )
	{
		// Low
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
		HAL_Delay(50);

		// High
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
		HAL_Delay(50);
	}
}


// This indicates how many SPI ports we're using on the micro-controller

//==========================================================================================
//==========================================================================================
static void Index0_TX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_0)];
	spi.setTXCompleteFlag(true);
}

static void Index0_RX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_0)];
	spi.setRXCompleteFlag(true);
}

//==========================================================================================
//==========================================================================================
static void Index1_TX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_1)];
	spi.setTXCompleteFlag(true);
}

static void Index1_RX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_1)];
	spi.setRXCompleteFlag(true);
}

//==========================================================================================
//==========================================================================================
static void Index2_TX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_2)];
	spi.setTXCompleteFlag(true);
}


static void Index2_RX_complete_cb(__SPI_HandleTypeDef *spiHandle)
{
	SPIPort& spi = *SPIPorts[static_cast<int>(SPIPortNumber::index_2)];
	spi.setRXCompleteFlag(true);
}


//==========================================================================================
// Setup Callback functions for the SPI ports
//==========================================================================================
static void setupCB_functions(enum SPIPortNumber portIndex, ptrCB_C_t* rxCB, ptrCB_C_t* txCB )
{
	switch( portIndex )
	{
	case SPIPortNumber::index_0:
		*txCB = &Index0_TX_complete_cb;
		*rxCB = &Index0_RX_complete_cb;
		break;

	case SPIPortNumber::index_1:
		*txCB = &Index1_TX_complete_cb;
		*rxCB = &Index1_RX_complete_cb;
		break;

	case SPIPortNumber::index_2:
		*txCB = &Index2_TX_complete_cb;
		*rxCB = &Index2_RX_complete_cb;
		break;

	default:
		*txCB = nullptr;
		*rxCB = nullptr;
	}
}


UINT8 SPIManager_numberOfSPIPorts()
{
	return SPIPorts.size();
}


std::vector<SPIPort*> SPIManager_getSPIPorts()
{
	return SPIPorts;
}


//====================================================================
// Create and Initialise the IMUs
//====================================================================
void SPIManager_SPIManager()
{
	int arrayIndex;

	bool leg1 = true;
	bool leg2 = true;
	bool torso = true;


	//===========================================================
	// SPI1 with 4 IMU - Leg
	// 0001.0002.0004.0008
	//===========================================================
	if( leg1 )
	{
		arrayIndex = SPIPorts.size();
		SPIPort* spi1 = SPIManager_setupSPI1_4(arrayIndex, true);
		SPIPorts.push_back(spi1);
	}

	//===========================================================
	// SPI2 with 4 IMU - Leg
	// 0010.0020.0040.0080
	//===========================================================
	if( leg2 )
	{
		arrayIndex = SPIPorts.size();
		SPIPort* spi2 = SPIManager_setupSPI2_4(arrayIndex, true);
		SPIPorts.push_back(spi2);
	}

	//===========================================================
	// SPI port with 7 IMU - Arms and Head
	// 0100 		  - Head
	// 0200.0400.0800 - Left Arm
	// 1000.2000.4000 - Right Arm
	//===========================================================
	if( torso )
	{
		arrayIndex = SPIPorts.size();
		SPIPort* spi3 = SPIManager_setupSPI3_7(arrayIndex, true);
		SPIPorts.push_back(spi3);
	}

	IMU_Gap();


	// Reset all devices so they start together...
	for( auto& port : SPIPorts ) {
		port->reset_devices();
	}

	NUMBER_OF_SPI_PORTS = SPIPorts.size();

	// Set the logical grouping for the devices
	imuBitmapGrouping[0] = 0x010F;		// 0100, 0008, 0004, 0002, 0001 = 0000.0001.0000.1111 = 01.0F
	imuBitmapGrouping[1] = 0x08F0;		// 0800, 0080, 0040, 0020, 0010 = 0000.1000.1111.0000 = 08.F0
	imuBitmapGrouping[2] = 0x7E00;		// 4000, 2000, 1000, 0400, 0200 = 0111.1110.0000.0000 = 7E.00
}


//=====================================================================================
// Output all the data from all the SPI ports
//=====================================================================================
void SPIManager_outputAllData()
{
	// Output all data from each SPI port
	for( UINT8 i=0 ; i<NUMBER_OF_SPI_PORTS ; i++ )
		SPIPorts[i]->outputData();
}

//=====================================================================================
// Assume all ports have received data from all their IMUs
// Once logical AND is false, it can never be true again, that's why we start
// off with true
//=====================================================================================
bool SPIManager_receivedAllData()
{
	bool result = true;

	for( UINT8 i=0 ; i<NUMBER_OF_SPI_PORTS ; i++ )
		result = result && SPIPorts[i]->isAllDataReceived();

	return result;
}


//=======================================================================================================
// Setup SPI Channel x
// - We configure all the IMU's attached to this SPI channel.
// - Each IMU indicates its Chip Select (CS) port and pin
// - The portIndex is the array index of this SPI port.  It is needed to because the SPI port must
//   use the correct callback function for TX and RX interrupts
//=======================================================================================================


//==========================================================================================
// SPI Port 1
//==========================================================================================
SPIPort* SPIManager_setupSPI1_4(UINT8 portIndex, bool initDMP)
{
	ptrCB_C_t ptrRxCB;	// Pointer to the Rx Callback function
	ptrCB_C_t ptrTxCB;	// Pointer to the Tx Callback function


	// Setup Callback function for SPI
	setupCB_functions(static_cast<SPIPortNumber>(portIndex), &ptrRxCB, &ptrTxCB);

	// Create IMU devices for SPI1
	ICMManager* imu_manager {new ICMManager()};

	// Create IMU devices
	ICM20948* imu1 = new ICM20948( IMUPort(GPIOA, GPIO_PIN_4, hspi1), 0x0001 );
	ICM20948* imu2 = new ICM20948( IMUPort(GPIOA, GPIO_PIN_3, hspi1), 0x0002 );
	ICM20948* imu3 = new ICM20948( IMUPort(GPIOA, GPIO_PIN_2, hspi1), 0x0004 );
	ICM20948* imu4 = new ICM20948( IMUPort(GPIOA, GPIO_PIN_1, hspi1), 0x0008 );

	// Add IMU to IMU manager
	imu_manager->addIMU(imu1);
	imu_manager->addIMU(imu2);
	imu_manager->addIMU(imu3);
	imu_manager->addIMU(imu4);

	// Initialize the DMP if requested
	if( initDMP )
	{
		imu1->init();
		imu2->init();
		imu3->init();
		imu4->init();
	}

	SPIPort* spi = new SPIPort(hspi1, imu_manager, portIndex, ptrRxCB, ptrTxCB);
	return spi;
}



//==========================================================================================
// SPI Port 2
//==========================================================================================
SPIPort* SPIManager_setupSPI2_4(UINT8 portIndex, bool initDMP)
{
	ptrCB_C_t ptrRxCB;	// Pointer to the Rx Callback function
	ptrCB_C_t ptrTxCB;	// Pointer to the Tx Callback function


	// Setup Callback function for SPI
	setupCB_functions(static_cast<SPIPortNumber>(portIndex), &ptrRxCB, &ptrTxCB);

	// Create IMU devices for SPI1
	ICMManager* imu_manager {new ICMManager()};

	// Create IMU devices
	ICM20948* imu1 = new ICM20948( IMUPort(GPIOB, GPIO_PIN_12, hspi2), 0x0010 );
	ICM20948* imu2 = new ICM20948( IMUPort(GPIOB, GPIO_PIN_11, hspi2), 0x0020 );
	ICM20948* imu3 = new ICM20948( IMUPort(GPIOB, GPIO_PIN_10, hspi2), 0x0040 );
	ICM20948* imu4 = new ICM20948( IMUPort(GPIOE, GPIO_PIN_15, hspi2), 0x0080 );

	// Add IMU to the IMU Manager
	imu_manager->addIMU(imu1);
	imu_manager->addIMU(imu2);
	imu_manager->addIMU(imu3);
	imu_manager->addIMU(imu4);

	// Initialize the DMP if requested
	if( initDMP )
	{
		imu1->init();
		imu2->init();
		imu3->init();
		imu4->init();
	}

	SPIPort* spi = new SPIPort(hspi2, imu_manager, portIndex, ptrRxCB, ptrTxCB);
	return spi;
}


//==========================================================================================
// SPI Port 3 - Arm Left
//==========================================================================================
SPIPort* SPIManager_setupSPI3_7(UINT8 portIndex, bool initDMP)
{
	ptrCB_C_t ptrRxCB;			// Pointer to Rx Callback function
	ptrCB_C_t ptrTxCB;			// Pointer to Tx Callback function


	#define head		// Head
	#define left_arm	// Left arm - connector furtherest from the battery
	#define right_arm	// Right arm - connector closest to the battery


	setupCB_functions(static_cast<SPIPortNumber>(portIndex), &ptrRxCB, &ptrTxCB);

	// Create IMU devices for SPI1
	ICMManager* imu_manager {new ICMManager()};

	// Head - middle connector
	#ifdef head
		ICM20948* imu1 = new ICM20948( IMUPort(GPIOB, GPIO_PIN_8, hspi3), 0x0100 );	// Head
	#endif

	// Left Arm - connector furtherest from the battery
	#ifdef left_arm
		ICM20948* imu2 = new ICM20948( IMUPort(GPIOB, GPIO_PIN_9, hspi3), 0x0200 );	// Lower arm
		ICM20948* imu3 = new ICM20948( IMUPort(GPIOE, GPIO_PIN_0, hspi3), 0x0400 );	// Upper arm
		ICM20948* imu4 = new ICM20948( IMUPort(GPIOE, GPIO_PIN_1, hspi3), 0x0800 );	// Shoulder
	#endif

	// Right Arm - connector closest to the battery
	#ifdef right_arm
		ICM20948* imu5 = new ICM20948( IMUPort(GPIOD, GPIO_PIN_6, hspi3), 0x1000 );	// Lower arm
		ICM20948* imu6 = new ICM20948( IMUPort(GPIOD, GPIO_PIN_5, hspi3), 0x2000 );	// Upper arm
		ICM20948* imu7 = new ICM20948( IMUPort(GPIOD, GPIO_PIN_4, hspi3), 0x4000 );	// Shoulder
	#endif


	#ifdef head
		imu_manager->addIMU(imu1);	// Head
	#endif

	#ifdef left_arm
		imu_manager->addIMU(imu2);	// Left Arm - connector furtherest from the battery
		imu_manager->addIMU(imu3);
		imu_manager->addIMU(imu4);
	#endif

	#ifdef right_arm
		imu_manager->addIMU(imu5);	// Right Arm - Connector closest to the battery
		imu_manager->addIMU(imu6);
		imu_manager->addIMU(imu7);
	#endif

	if( initDMP )
	{
		#ifdef head
			imu1->init();		// Head
		#endif

		#ifdef left_arm
			imu2->init();
			imu3->init();
			imu4->init();
		#endif

		#ifdef right_arm
			imu5->init();
			imu6->init();
			imu7->init();
		#endif
	}

	SPIPort* spi = new SPIPort(hspi3, imu_manager, portIndex, ptrRxCB, ptrTxCB);
	return spi;
}



#ifdef __cplusplus
}
#endif

