/*
 * SPImain.h
 *
 *  Created on: Mar 15, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_SPICOMMS_SPIMAIN_H_
#define SRC_PROJECT_SPICOMMS_SPIMAIN_H_


enum class SPIPortNumber {
	index_0 = 0,
	index_1 = 1,
	index_2 = 2,
};


// The SPI port unique ID uniquely identifies the SPI port.
// It's used in setting the global flag, which indicates that all SPI ports
// have received all the data from their IMUs
enum class SPIPortUniqueID {
	index_0 = 0x01,
	index_1 = 0x02,
	index_2 = 0x04,
};


#endif /* SRC_PROJECT_SPICOMMS_SPIMAIN_H_ */
