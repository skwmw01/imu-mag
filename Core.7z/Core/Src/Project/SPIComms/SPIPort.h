/*
 * StateMachine.h
 *
 *  Created on: Mar 8, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_SPIPORT_H_
#define SRC_PROJECT_SPIPORT_H_

#include <vector>
#include <memory>

#include "main.h"
#include <project.hpp>
#include "IMU/ICMManager.h"
#include "ICM20948/ICM20948.hpp"
#include "SPImain.h"

// Forward declaration
class SPIPort;


// Define a pointer (my_func_ptr) to point to a class function
//void (SPIPort::*my_func_ptr)(__SPI_HandleTypeDef *spiHandle);

// Callback pointer to a C++ member function
typedef void (SPIPort::*ptrCB_Cpp_t)(__SPI_HandleTypeDef *spiHandle);

// Callback pointer to a C function
typedef void (*ptrCB_C_t)(__SPI_HandleTypeDef*);



enum class SPIState {
	STATE_IDLE,
	STATE_SELECT_IMU,
	STATE_SEND_CMD,
	STATE_WAIT_SEND_COMPLETION,
	STATE_SEND_GET_RESPONSE,
	STATE_WAIT_RECV_RESPONSE,
	STATE_NO_RECV_RESPONSE,
};


enum class NewSPIState {
	STATE_IDLE,

	// Send command "Read Global interrupt"
	STATE_SEND_CMD_REG_INT_STATUS,
	STATE_WAIT_CMD_REG_INT,

	// Read response "Read DMP interrupt"
	STATE_READ_RESP_CMD_REG_INT,
	STATE_WAIT_RESP_CMD_REG_INT,


	// Send command "Read DMP interrupt"
	STATE_SEND_CMD_DMP_INT,
	STATE_WAIT_CMD_DMP_INT,

	// Read response "Read DMP interrupt"
	STATE_READ_RESP_CMD_DMP_INT,
	STATE_WAIT_RESP_CMD_DMP_INT,

	// Assuming 0x10 bytes
	STATE_SEND_CMD_READ_FIFO_COUNT,

	// Send command "Read FIFO Buffer"
	STATE_SEND_CMD_READ_FIFO_BUFFER,
	STATE_WAIT_CMD_READ_FIFO_BUFFER,

	// Read response from FIFO buffer
	STATE_SEND_READ_BUFFER,
	STATE_WAIT_READ_BUFFER,
};

// Forward declarations
class ICMManager;


class SPIPort
{
public:
	SPIPort(SPI_HandleTypeDef& hspi,
			ICMManager* imuManager,
			UINT8 uniqueID,
			ptrCB_C_t rx_CB,
			ptrCB_C_t tx_CB);

	virtual ~SPIPort(){};

	// Methods
	void Execute();

	void Execute_Group_Of_Five();
	void Execute_SPI_Ports();


	void MyTask_NonBlock();

	// Determines whether all IMUs have responded with data
	inline bool isAllDataReceived() { return receivedAllData; }
	inline void setAllDataReceived(bool value) { receivedAllData = value; }

	// Outputs all data from this SPI port
	void outputData();
	void reset_devices();

	UINT16 getBitmap() { return bitmap; }
	inline void clearBitmap(UINT16 value) { bitmap &= value; }


	void task_DMP();

	ICMManager& IMUManager() { return *icmManager; }

	void setTXCompleteFlag(BOOL value) { spi_tx_complete = value; }
	void setRXCompleteFlag(BOOL value) { spi_rx_complete = value; }

	SPI_HandleTypeDef& getSPIHandle(){return spiHandle;}

	UINT16	reg_int_status;		// Stores both 0x19 and 0x18 results
	UINT8	dataSize;
	UINT8	uniqueID;

	//int transfer_tx_block(UINT8 reg_address, const UINT8* data, UINT32 len);
	//int transfer_rx_block(UINT8 reg_address, const UINT8* data, UINT32 len);


private:
	enum SPIState		state;
	enum NewSPIState	new_state;
	ICMManager*			icmManager;
	ICM20948* 			pIMU;			// The current active IMU

	UINT16	bitmap;						// Keeps record of IMUs that have data available
	UINT16	bitmapMask;					// The bitmap mask that represents all IMU's on this chain
	bool 	receivedAllData;			// True if SPI collected data from each IMU
	bool	output_ascii_data;


	UINT8 		spi_buf[64];
	SPI_HandleTypeDef& spiHandle;

	ptrCB_C_t ptrRxCB;					// Pointer to Rx Callback function
	ptrCB_C_t ptrTxCB;					// Pointer to Tx Callback function

	// For static functions
	// These variables are instance variables
	volatile BOOL	spi_tx_complete = false;
	volatile BOOL	spi_rx_complete = false;
};


#endif /* SRC_PROJECT_SPIPORT_H_ */
