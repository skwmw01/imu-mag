/*
 * StateMachine.cpp
 *
 *  Created on: Mar 8, 2024
 *      Author: Michael.Oleksy
 */

#include <IMU/ICMManager.h>
#include <functional>
#include <memory>

#include "ICM20948/ICM20948Helper.h"
#include "ICM20948/Driver/ICM20948.h"
#include "SPIComms/SPIPort.h"
#include "SPImain.h"

#include "Debug/DebugLog.h"

extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef hspi3;


// suppress the typecast from C ptr-to-func to C++ ptr-to-member-func
//#pragma GCC diagnostic ignored "-Wpmf-conversions"



SPIPort::SPIPort(SPI_HandleTypeDef& hspi,
				 ICMManager* imuManager,
				 UINT8 _uniqueID,
				 ptrCB_C_t rx_CB,
				 ptrCB_C_t tx_CB)
	: state{SPIState::STATE_IDLE}
	, new_state{NewSPIState::STATE_SEND_CMD_REG_INT_STATUS}
	, icmManager{imuManager}
	, spiHandle{hspi}
	, ptrRxCB {rx_CB}
	, ptrTxCB {tx_CB}
{
	// Setup the callback functions for the SPI Port
	HAL_SPI_RegisterCallback(&spiHandle, HAL_SPI_TX_COMPLETE_CB_ID, ptrTxCB );
	HAL_SPI_RegisterCallback(&spiHandle, HAL_SPI_RX_COMPLETE_CB_ID, ptrRxCB );

	uniqueID = _uniqueID*2;		// Need 1, 2, 4, 8 value
	if( uniqueID == 0)
		uniqueID = 1;


	// Have we received data from all the IMUs attached to this SPI port?
	receivedAllData = false;

	output_ascii_data = true;
	//output_ascii_data = false;

	// Each SPI port has a collection of IMUs, and each IMU has an unique ID.
	// This represents all the IMUs on this SPI port
	bitmap = 0;
	bitmapMask = 0;
	for( auto& device : icmManager->getDevices() ) {
		bitmapMask |= device.getID();
	}
}


void SPIPort::reset_devices()
{
	for( auto& device : icmManager->getDevices() )
	{
		device.reset_dmp();
	}
}


void SPIPort::outputData()
{
	//if( pIMU.settings()->enable_quaternion )
	icmManager->Output_Quaternion_Data(output_ascii_data);

	// Take the accelerometer data from each IMU and group it into a single string.
	// Output that on the UART

	//if( pIMU.settings()->enable_accelerometer )
	icmManager->Output_Accel_Data(output_ascii_data);

	icmManager->Output_Mag_Data(output_ascii_data);
	// Once the data is output, reset it again
	setAllDataReceived(false);
}



//==========================================================================
// New State Machine for the SPI Port
// Finite state machine to allow for non-blocking SPI transmit/receive
//==========================================================================
void SPIPort::Execute_Group_Of_Five()
{
	switch(new_state)
	{
		// Issue 0x99 (Read general interrupt register)
		// If set, indicates the DMP has generated INT1 interrupt.
		case NewSPIState::STATE_SEND_CMD_REG_INT_STATUS:
		{
			pIMU = icmManager->getCurrentIMU();
			if( pIMU->isProcessed() )
			{
				//DBG_LOG_MESSAGE("!");
				icmManager->getNextIMU();
				return;
			}


			pIMU->setCS(GPIO_PIN_RESET);			// Set CS low (active)
			spi_buf[0] = REG_INT_STATUS | READ_BIT_MASK;

			// Perform blocking write to SPI
			HAL_SPI_Transmit(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);
			HAL_SPI_Receive(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);

			// Store in LOW byte
			reg_int_status = spi_buf[0];		// xx.data[1]

			pIMU->setCS(GPIO_PIN_SET);			// Set CS high (inactive)

			// Optimisation - only issue 0x98 if 0x99 has generated an interrupt
			// Don't change state if 0x99 did not generate an interrupt
			if( reg_int_status )
				new_state = NewSPIState::STATE_SEND_CMD_DMP_INT;
			else
			{
				// Reference the next IMU in the chain
				icmManager->getNextIMU();
			}
			break;
		}

		// Issue 0x98
		// Read the DMP internal register
		// Select an IMU and send command to get the DMP interrupt value
		case NewSPIState::STATE_SEND_CMD_DMP_INT:
		{
			pIMU->setCS(GPIO_PIN_RESET);		// Set CS low (active)
			spi_buf[0] = REG_DMP_INT_STATUS | READ_BIT_MASK;

			// Perform blocking write to SPI
			HAL_SPI_Transmit(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);

			// Get response from 0x98 (Store in HI byte)
			HAL_SPI_Receive(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);
			reg_int_status |= (UINT16)(spi_buf[0] << 8);		// Store INT result in two bytes

			pIMU->setCS(GPIO_PIN_SET);		// Set CS high (inactive)

			// Check if an interrupt bit is set
			if( reg_int_status & (BIT_MSG_DMP_INT | BIT_MSG_DMP_INT_0) )
			{
				// Indicate this IMU has output data
				pIMU->setProcessed(true);

				bitmap |= pIMU->getID();

				// Get data from the IMU
				MyTaskExecute( pIMU, pIMU->icm_device, pIMU, build_sensor_event_data);
    		}

        	// Process the next IMU
        	new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
			icmManager->getNextIMU();
			break;
		}
	}
}



//==========================================================================
// New State Machine for the SPI Port
// Finite state machine to allow for non-blocking SPI transmit/receive
//==========================================================================
void SPIPort::Execute_SPI_Ports()
{
	// If we received data from a
	// If we have received data from each IMU on this port already, don't process this SPI port
	//if( isAllDataReceived() )
	//	return;

	//if( global_flag & uniqueID )
	//	return;

	switch(new_state)
	{
		//case NewSPIState::STATE_IDLE:
		//{
		//	new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
		//	break;
		//}

		// Issue 0x99 (Read general interrupt register)
		// If set, indicates the DMP has generated INT1 interrupt.
		case NewSPIState::STATE_SEND_CMD_REG_INT_STATUS:
		{
			pIMU = icmManager->getCurrentIMU();
			if( pIMU->isProcessed() )
			{
				//DBG_LOG_MESSAGE("!");
				icmManager->getNextIMU();
				return;
			}


			pIMU->setCS(GPIO_PIN_RESET);			// Set CS low (active)
			spi_buf[0] = REG_INT_STATUS | READ_BIT_MASK;

			// Perform blocking write to SPI
			HAL_SPI_Transmit(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);
			HAL_SPI_Receive(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);

			// Store in LOW byte
			reg_int_status = spi_buf[0];		// xx.data[1]

			pIMU->setCS(GPIO_PIN_SET);			// Set CS high (inactive)

			// Optimisation - only issue 0x98 if 0x99 has generated an interrupt
			// Don't change state if 0x99 did not generate an interrupt
			if( reg_int_status )
				new_state = NewSPIState::STATE_SEND_CMD_DMP_INT;
			else
			{
				// Reference the next IMU in the chain
				icmManager->getNextIMU();
			}
			break;
		}

		// Issue 0x98
		// Read the DMP internal register
		// Select an IMU and send command to get the DMP interrupt value
		case NewSPIState::STATE_SEND_CMD_DMP_INT:
		{
			pIMU->setCS(GPIO_PIN_RESET);		// Set CS low (active)
			spi_buf[0] = REG_DMP_INT_STATUS | READ_BIT_MASK;

			// Perform blocking write to SPI
			HAL_SPI_Transmit(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);

			// Get response from 0x98 (Store in HI byte)
			HAL_SPI_Receive(&spiHandle, (uint8_t*)&spi_buf[0], 1, 100);
			reg_int_status |= (UINT16)(spi_buf[0] << 8);		// Store INT result in two bytes

			pIMU->setCS(GPIO_PIN_SET);		// Set CS high (inactive)

			// Check if an interrupt bit is set
			if( reg_int_status & (BIT_MSG_DMP_INT | BIT_MSG_DMP_INT_0) )
			{
				// Indicate this IMU has output data
				pIMU->setProcessed(true);				// output per SPI

				//char msg[20];
				//sprintf(msg, "%04X\0", pIMU->getID() );
				//DBG_LOG_MESSAGE(msg);

				// Grab data from IMU
				//DBG_LOG_MESSAGE("S");
				MyTaskExecute( pIMU, pIMU->icm_device, pIMU, build_sensor_event_data);
				//DBG_LOG_MESSAGE("E");

				bitmap |= pIMU->getID();
				if( bitmap == bitmapMask )
				{
					//sprintf(msg, "DATA-DATA-DATA\0", uniqueID );
					//DBG_LOG_MESSAGE(msg);

					if( pIMU->settings()->enable_quaternion )				// output per SPI
						icmManager->Output_Quaternion_Data(output_ascii_data);

					if( pIMU->settings()->enable_accelerometer )			// output per SPI
						icmManager->Output_Accel_Data(output_ascii_data);

					if( pIMU->settings()->enable_magnetometer )			// output per SPI
						icmManager->Output_Mag_Data(output_ascii_data);

					// Set all IMUs as not processed
					icmManager->clearProcessFlag();		// output per SPI

					//global_flag |= uniqueID;
					//setAllDataReceived(true);

					bitmap = 0;							// output per SPI
				}
    		}

        	// Process the next IMU
        	new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
			icmManager->getNextIMU();
			break;
		}
	}
}







//==========================================================================
// New State Machine for the SPI Port
// Test getting a quaternion data from IMU's in a chain....
//==========================================================================
void SPIPort::MyTask_NonBlock()
{
	// Finite state machine to allow for non-blocking SPI transmit/receive
	switch(new_state)
	{
		case NewSPIState::STATE_IDLE:
		{
			new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
			break;
		}

		// Issue 0x99
		case NewSPIState::STATE_SEND_CMD_REG_INT_STATUS:
		{
			pIMU = icmManager->getCurrentIMU();
			if( pIMU->getCmdState() == CommandState::STATE_CMD_PENDING )
			{
				pIMU->setCS(GPIO_PIN_RESET);			// Set CS low (active)
				spi_buf[0] = REG_INT_STATUS | READ_BIT_MASK;

				// Perform non-blocking write to SPI
				HAL_SPI_Transmit_IT(&spiHandle, (uint8_t *)&spi_buf[0], 1);
				new_state = NewSPIState::STATE_WAIT_CMD_REG_INT;
			}
			break;
		}

		// Wait for 0x99 transmission to complete...
		case NewSPIState::STATE_WAIT_CMD_REG_INT:
		{
	    	if (spi_tx_complete) {
	    		spi_tx_complete = false;
	    		new_state = NewSPIState::STATE_READ_RESP_CMD_REG_INT;
	        }
			break;
		}

		// Read response from command 0x99
		case NewSPIState::STATE_READ_RESP_CMD_REG_INT:
		{
			 HAL_SPI_Receive_IT(&spiHandle, (uint8_t *)&spi_buf[0], 1);
			 new_state = NewSPIState::STATE_WAIT_RESP_CMD_REG_INT;
			 break;
		}

		// Process Response from 0x99...
		case NewSPIState::STATE_WAIT_RESP_CMD_REG_INT:
		{
			if (spi_rx_complete)
			{
				spi_rx_complete = false;

				// Check if an interrupt bit is set
				//if( spi_buf[0] == 0x01 ) {
				//	new_state = NewSPIState::STATE_SEND_CMD_READ_BUFFER;
				//	break;
				//}
				pIMU->setCS(GPIO_PIN_SET);			// Set CS high (inactive)
				new_state = NewSPIState::STATE_SEND_CMD_DMP_INT;
			}
			break;
		}

		// Issue 0x98
		// Select an IMU and send command to get the DMP interrupt value
		case NewSPIState::STATE_SEND_CMD_DMP_INT:
		{
			//pIMU = icmManager->getCurrentIMU();
			//if( pIMU->getCmdState() == CommandState::STATE_CMD_PENDING )
			//{
				pIMU->setCS(GPIO_PIN_RESET);		// Set CS low (active)
				spi_buf[0] = REG_DMP_INT_STATUS | READ_BIT_MASK;

				// Perform non-blocking write to SPI
				HAL_SPI_Transmit_IT(&spiHandle, (uint8_t *)&spi_buf[0], 1);
				new_state = NewSPIState::STATE_WAIT_CMD_DMP_INT;
			//}
			break;
		}

		// Wait for command 0x98 transmission to complete...
	    case NewSPIState::STATE_WAIT_CMD_DMP_INT:
	    {
	    	if (spi_tx_complete) {
	    		spi_tx_complete = false;
	    		new_state = NewSPIState::STATE_READ_RESP_CMD_DMP_INT;
	        }
	    	break;
	    }

	    // Initiate the reception of data: Read DMP Interrupt flag response
   	    case NewSPIState::STATE_READ_RESP_CMD_DMP_INT:
   	    {
	        HAL_SPI_Receive_IT(&spiHandle, (uint8_t *)&spi_buf[0], 1);
	        new_state = NewSPIState::STATE_WAIT_RESP_CMD_DMP_INT;
	        break;
   	    }

   	    // Check data received from command 0x98
	    case NewSPIState::STATE_WAIT_RESP_CMD_DMP_INT:
	    {
	    	if (spi_rx_complete)
	        {
	    		spi_rx_complete = false;
	    		pIMU->setCS(GPIO_PIN_SET);		// Set CS high (inactive)

	    		// Check if an interrupt bit is set
	    		if( spi_buf[0] == 0x01 ) {
	    			new_state = NewSPIState::STATE_SEND_CMD_READ_FIFO_BUFFER;
	    			break;
	    		}

	        	// No data available from IMU
	        	//pIMU->setCS(GPIO_PIN_SET);		// Set CS High (inactive)
	        	icmManager->getNextIMU();
	        	new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
	        }
	        break;
	    }

	    // Send "Read FIFO buffer" command
	    case NewSPIState::STATE_SEND_CMD_READ_FIFO_BUFFER:
	    {
	    	// Set CS low (active)
	    	pIMU->setCS(GPIO_PIN_RESET);		// Set CS low (active)
	    	spi_buf[0] = REG_FIFO_R_W | READ_BIT_MASK;

	    	// Perform non-blocking write to SPI
	    	HAL_SPI_Transmit_IT(&spiHandle, (uint8_t *)&spi_buf[0], 1);
	    	new_state = NewSPIState::STATE_WAIT_CMD_READ_FIFO_BUFFER;
	    	break;
	    }

	    // Wait for command to be sent.
	    case NewSPIState::STATE_WAIT_CMD_READ_FIFO_BUFFER:
		{
			if (spi_tx_complete) {
				spi_tx_complete = false;
			    new_state = NewSPIState::STATE_SEND_READ_BUFFER;
			}
	    	break;
		}

		// Read FIFO buffer (16 bytes)
	    case NewSPIState::STATE_SEND_READ_BUFFER:
	    {
	    	HAL_SPI_Receive_IT(&spiHandle, (uint8_t *)&spi_buf[0], 16);
	    	new_state = NewSPIState::STATE_WAIT_READ_BUFFER;
	    	break;
	    }

	    // Wait for FIFO buffer to be fully read...
	    case NewSPIState::STATE_WAIT_READ_BUFFER:
	    {
	    	if (spi_rx_complete)
	    	{
	    		spi_rx_complete = false;
	    		// Check if an interrupt bit is set
	    		//DBG_QUATERNION_TO_JS_OBJECT(quat_w, quat_x, quat_y, quat_z );

	    		pIMU->setCS(GPIO_PIN_SET);		// Set CS High (inactive)
	    		icmManager->getNextIMU();
	    		new_state = NewSPIState::STATE_SEND_CMD_REG_INT_STATUS;
	    	}
	    }

	}
}



//===============================================================================
// Process each IMU on the SPI port
//===============================================================================
void SPIPort::Execute()
{
	// Finite state machine to allow for non-blocking SPI transmit/receive
	switch(state)
	{
		case SPIState::STATE_IDLE:
		{
			state = SPIState::STATE_SELECT_IMU;
			break;
		}

		// Select an IMU
		case SPIState::STATE_SELECT_IMU:
		{
			pIMU = icmManager->getCurrentIMU();
			if( pIMU->getCmdState() == CommandState::STATE_CMD_PENDING )
			{
				// Set CS low (active)
				pIMU->setCS(GPIO_PIN_RESET);
				state = SPIState::STATE_SEND_CMD;
			}
			break;
		}

		// Transmit Command
		case SPIState::STATE_SEND_CMD:
		{
			// Get the current command from the IMU
			Command_t& cmd = pIMU->getNextCmd();
			spi_buf[0] = cmd.address;

			for( int i = 0 ; i < cmd.TxDataLen-1 ; i++ )
				spi_buf[i+1] = cmd.data;

			// Perform non-blocking write to SPI
			HAL_SPI_Transmit_IT(&spiHandle, (uint8_t *)&spi_buf[0], cmd.TxDataLen);

			state = SPIState::STATE_WAIT_SEND_COMPLETION;
			break;
		}

		// Wait for transmit flag
	    case SPIState::STATE_WAIT_SEND_COMPLETION:
	    {
	    	if (spi_tx_complete)
	        {
	          // Clear flag and go to next state
	          spi_tx_complete = false;
	          state = SPIState::STATE_SEND_GET_RESPONSE;
	        }
	        break;
	    }

	    // Set up for interrupt-based SPI receive
	    case SPIState::STATE_SEND_GET_RESPONSE:
	    {
	    	// Read data from IMU
	    	Command_t& cmd = pIMU->getCmd();

			// Check if there is any data to receive
			if( cmd.RxDataLen == 0 )
			{
				state = SPIState::STATE_NO_RECV_RESPONSE;
				break;
			}

			for( unsigned int i=0 ; i<sizeof(spi_buf) ; i++)
				spi_buf[i] = 0;

	        HAL_SPI_Receive_IT(&spiHandle, (uint8_t *)spi_buf, cmd.RxDataLen);

	        // Go to next state: waiting for receive to finish
	        state = SPIState::STATE_WAIT_RECV_RESPONSE;
	        break;
	    }

	    case SPIState::STATE_NO_RECV_RESPONSE:
	    {
	    	// Get the current IMU and set the CS high
        	pIMU->setCS(GPIO_PIN_SET);
        	icmManager->getNextIMU();

        	state = SPIState::STATE_SELECT_IMU;
	    	break;
	    }

	    // Wait for receive flag to be set.
	    // It is set once the data has been received
	    case SPIState::STATE_WAIT_RECV_RESPONSE:
	    {
	    	if (spi_rx_complete)
	        {
	    		// Get the current IMU and set the CS high
	        	pIMU->setCS(GPIO_PIN_SET);
	        	icmManager->getNextIMU();

	        	spi_rx_complete = false;
	        	state = SPIState::STATE_SELECT_IMU;
	        }
	        break;
	    }

	    default:
	    	break;
	}
}


void SPIPort::task_DMP()
{
	pIMU = icmManager->getCurrentIMU();
	pIMU->task();


	// Sample accelerometer values
	// Do not output values when sampling in progress...
	if( pIMU->sample_accel )
	{
		pIMU->gatherAccelSamples();
		return;
	}


    if( pIMU->accel_data_ready )
    {
    	//pIMU->applyAccelOffset();
    	icmManager->Output_Accel_Data(output_ascii_data);
    	pIMU->accel_data_ready = false;
    }

    if( pIMU->mag_data_ready )
    {
    	//pIMU->applyAccelOffset();
    	icmManager->Output_Mag_Data(output_ascii_data);
    	pIMU->mag_data_ready = false;
    }

	if( pIMU->quat_data_ready )
	{
		icmManager->Output_Quaternion_Data(output_ascii_data);
		pIMU->quat_data_ready = false;
	}

	icmManager->getNextIMU();
}

