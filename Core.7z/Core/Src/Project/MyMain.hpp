/*
 * MyMain.h
 *
 *  Created on: Mar 7, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_MYMAIN_HPP_
#define SRC_PROJECT_MYMAIN_HPP_


void MyMainCPP(void);


#endif /* SRC_PROJECT_MYMAIN_HPP_ */
