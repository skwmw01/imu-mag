/*
 * SPIComms.cpp
 *
 *  Created on: Mar 7, 2024
 *      Author: Michael.Oleksy
 */

#include <SPIBlock.hpp>
#include "main.h"


SPIBlock::SPIBlock(SPI_HandleTypeDef hspi)
{
	spiHandle = hspi;
}

SPIBlock::~SPIBlock() {
	// TODO Auto-generated destructor stub
}

// CS high is inactive
void SPIBlock::setCSHigh() {
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
}


// CS low is active
void SPIBlock::setCSLow() {
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
}


// Send Data over SPI
int SPIBlock::SendData(UINT8* srcBuffer, UINT16 len)
{
	// CS goes low (active) at the start of transmission and goes back high (inactive) at the end.
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);

	// Send Byte using SPI
	HAL_SPI_Transmit(&spiHandle, (uint8_t*)srcBuffer, 1, 100);

	return len;
}


// Receive Data over SPI
int SPIBlock::ReceiveData(UINT8* dstBuffer, UINT16 len)
{
	// Store data in destination buffer
	HAL_SPI_Receive(&spiHandle, dstBuffer, len, 100);

	// CS goes high (inactive) at the end of transmission.
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

	return 0;
}

