/*
 * InvMsg.c
 *
 *  Created on: Mar 28, 2024
 *      Author: Michael.Oleksy
 */
#include <project.hpp>
#include "main.h"
#include <stdio.h>

#include <iostream>
#include <sstream>
#include <iomanip>

#include "ICM20948.h"
#include "ICM20948/Driver/ICM20948Dmp3Driver.h"
#include "Debug/RegisterDescription.h"


// External variables

// Need for UART1 - M.O.
extern UART_HandleTypeDef 	huart3;
#define UART_PORT			huart3

extern inv_icm20948_t icm_device;


#ifdef __cplusplus
extern "C"
{
#endif

extern bool __log_enabled;



// Prototypes
static std::string CommandDescription( int reg, int bank );
static std::string DataDescription( uint8_t reg, uint8_t* data, int size );




//====================================================================
// String sent to the Node.JS application to visualise quaternion
// NB: Set the IMU settings in Project->Properties->MCU Settings-> sprintf...
//====================================================================
void DBG_QUATERNION_TO_JS_OBJECT(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id )
{
	std::stringstream ss;


	// Create a JSON object
	ss << "{" << std::setprecision(6);
	ss << std::quoted("id") << ":" << std::to_string(id) << ", ";
	ss << std::quoted("quat_w") << ":" << std::to_string(quat_w) << ", ";
	ss << std::quoted("quat_x") << ":" << std::to_string(quat_x) << ", ";
	ss << std::quoted("quat_y") << ":" << std::to_string(quat_y) << ", ";
	ss << std::quoted("quat_z") << ":" << std::to_string(quat_z) << "}" << "\n";

	std::string s = ss.str();

	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);
}

//============================================================================================
void DBG_QUATERNION_TO_JS_OBJECT_C(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id )
{
	//char ss[128];

	//sprintf(ss, "{\"quat_w\":%f, \"quat_x\":%f, \"quat_y\":%f, \"quat_z\":%f}\n\0", quat_w, quat_x, quat_y, quat_z);
    //sprintf(ss, "{\"quat_w\":%f, \"quat_x\":%f, \"quat_y\":%f, \"quat_z\":%f}", quat_w, quat_x, quat_y, quat_z);


	// Need for UART1 - M.O.
	//HAL_UART_Transmit(&huart4, (uint8_t*)ss, strlen(ss), 1000);
}


//============================================================================================
void DBG_QUATERNION_TO_FLOATS(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id )
{
	char ss[512];
	uint16_t offset = 0;
//	long qquat_w = 0x31313131;
//	long qquat_x = 0x32323232;
//	long qquat_y = 0x33333333;
//	long qquat_z = 0x34343434;
//
//	uint8_t c = 'A';
//	offset = 0;
//	for( uint16_t i=0 ; i<15 ; i++ )
//	{
//		ss[offset] = c;
//
//		offset++;
//		memcpy( &ss[offset], &qquat_w, sizeof(float) );
//
//		offset += sizeof(float);
//		memcpy( &ss[offset], &qquat_x, sizeof(float) );
//
//		offset += sizeof(float);
//		memcpy( &ss[offset], &qquat_y, sizeof(float) );
//
//		offset += sizeof(float);
//		memcpy( &ss[offset], &qquat_z, sizeof(float) );
//
//		offset += sizeof(float);
//	}
//	ss[offset] = 0;

	ss[0] = id;
	memcpy( &ss[offset + 0*sizeof(float)], &quat_w, sizeof(float) );
	memcpy( &ss[offset + 1*sizeof(float)], &quat_x, sizeof(float) );
	memcpy( &ss[offset + 2*sizeof(float)], &quat_y, sizeof(float) );
	memcpy( &ss[offset + 3*sizeof(float)], &quat_z, sizeof(float) );
	ss[offset + 4*sizeof(float)] = 0;

	// Need for UART1 - M.O.
	//HAL_UART_Transmit(&huart4, (uint8_t*)ss, strlen(ss), 1000);
}




//====================================================================
// Used to add an arbitrary message to the UART log
//====================================================================
void DBG_LOG_MESSAGE(const char* pData)
{
	std::string s{pData};
	//s += "\r\n";

	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);
}



//====================================================================
// Dumps Command Data to the log file
//====================================================================
std::string DBG_LOG_DATA(uint8_t reg, uint8_t bank, uint8_t* pData, uint32_t size)
{
	std::stringstream ss;
	std::string s;

	if( size == 0 ) {
		s = "";
		return s;
	}

	// Data to be written
	ss << "Data : ";
	for( uint32_t i{} ; i<size ; i++) {
		ss << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << static_cast<int>(pData[i]) << ((i==(size-1)) ? "" : ".");
	}

	// Convert stream into std::string
	s = ss.str() + DataDescription((reg & 0x7F), pData, size) + "\r\n\r\n";
	return s;
}



//================================================================
// Read IMU
//================================================================
void DBG_LOG_RD_IMU( uint8_t reg, uint8_t* pData, uint32_t size )
{
	if( !__log_enabled )
		return;

	std::stringstream ss;
	uint8_t userBank = icm_device.lastBank;


	// Clear Bit7 for IMU Reads
	ss << "Read : " << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)reg << " ";
	ss << "[User Bank " << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)userBank << ". ";
	ss << "Reg " << "0x" << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)(reg & 0x7F) << "";
	ss << " " << CommandDescription(reg & 0x7F, (int)userBank) << "]";

	// Convert stream into std::string
	std::string s = ss.str();
	s += "\r\n";

	// Display the Read Command
	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);


	// Clear the stream
	ss.str( std::string() );
	ss.clear();

	// Display the data that was read from IMU
	s = DBG_LOG_DATA(reg, userBank, pData, size);

	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);
}


//================================================================
// Write IMU
//================================================================
void DBG_LOG_WR_IMU( uint8_t reg, uint8_t* pData, uint32_t size )
{
	if( !__log_enabled )
		return;

	std::stringstream ss;
	std::string s;

	uint8_t userBank = icm_device.lastBank;

	ss << "Write: " << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)reg << " ";
	ss << "[User Bank " << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)userBank << ". ";
	ss << "Reg " << "0x" << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)reg << "";
	ss << " " << CommandDescription(reg, (int)icm_device.lastBank) << "]";

	// Convert stream into std::string
	s = ss.str();
	s += "\r\n";

	// Display the Write Command
	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);


	// Clear the stream
	ss.str( std::string() );
	ss.clear();

	// Display the data that was written to the IMU
	s = DBG_LOG_DATA(reg, userBank, pData, size);

	// Need for UART1 - M.O.
	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);
}



//=====================================================================================
// Data Description
//=====================================================================================
std::string DataDescription( uint8_t reg, uint8_t* data, int size )
{
	int bank = (int)icm_device.lastBank;
	int dataValue = 0;

	// Register Bank Select
	if( reg == 0xFF || reg == 0x7F)
	{
		std::stringstream ss;
		ss << " [Select Register Bank " << std::hex << std::setfill('0') << std::setw(2) << std::uppercase << (int)(*data >> 4) << "]";
		std::string s = ss.str();		// Convert stream into std::string

		return s;
	}

	if( size == 1 )
		dataValue = *data;

	//if( size == 2 )
//		dataValue = (icm_device.lLastBankSelected)*256 + *data;


	// Bank 0
	if( bank == 0 )
	{
		// For Bank 0
		switch(reg)
		{
			case 0x03: return Register_0x0003(*data); break;
			case 0x06: return Register_0x0006(*data); break;
			case 0x07: return Register_0x0007(*data); break;
			case 0x10: return Register_0x0010(*data); break;
			case 0x11: return Register_0x0011(*data); break;
			case 0x12: return Register_0x0012(*data); break;
			case 0x13: return Register_0x0013(*data); break;
			case 0x19: return Register_0x0019(*data); break;

			// Memory Bank Selection
			case 0x7E:
			{
				std::stringstream ss;
				ss << " [Select Memory Bank 0x" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)(dataValue << 8) << "]";
				return ss.str();
			}
			break;

			case 0x7C:
			{
				std::stringstream ss {};
				std::string s {};
				int dataValue = (icm_device.lLastBankSelected)*256 + *data;
				ss << " [Memory Address: 0x" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)(dataValue) << ". ";
				s = ss.str();

				switch(dataValue)
				{
					case DATA_OUT_CTL1:			s += std::string{"DATA_OUT_CTL1 = (4 * 16)"}; break;
					case DATA_OUT_CTL2:			s += std::string{"DATA_OUT_CTL2 = (4 * 16 + 2)"}; break;
					case DATA_INTR_CTL:			s += std::string{"DATA_INTR_CTL = (4 * 16 + 12)"}; break;
					case FIFO_WATERMARK: 		s += std::string{"FIFO_WATERMARK = (31 * 16 + 14)"}; break;
					case MOTION_EVENT_CTL:		s += std::string{"MOTION_EVENT_CTL = (4 * 16 + 14)"}; break;
					case DATA_RDY_STATUS:		s += std::string{"DATA_RDY_STATUS = (8 * 16 + 10)"}; break;

					case BM_BATCH_CNTR:			s += std::string{"BM_BATCH_CNTR = (27 * 16)"}; break;
					case BM_BATCH_THLD:			s += std::string{"BM_BATCH_THLD = (19 * 16 + 12)"}; break;
					case BM_BATCH_MASK:			s += std::string{"BM_BATCH_MASK = (21 * 16 + 14)"}; break;

					// Sensor output data rate
					case ODR_ACCEL:				s += std::string{"ODR_ACCEL	(11 * 16 + 14)"};  break;
					case ODR_GYRO:				s += std::string{"ODR_GYRO (11 * 16 + 10)"}; break;
					case ODR_CPASS:				s += std::string{"ODR_CPASS	(11 * 16 +  6)"}; break;
					case ODR_ALS:				s += std::string{"ODR_ALS (11 * 16 +  2)"}; break;
					case ODR_QUAT6:				s += std::string{"ODR_QUAT6 (10 * 16 + 12)"}; break;
					case ODR_QUAT9:				s += std::string{"ODR_QUAT9 (10 * 16 +  8)"}; break;
					case ODR_PQUAT6:			s += std::string{"ODR_PQUAT6 (10 * 16 +  4)"}; break;
					case ODR_GEOMAG:			s += std::string{"ODR_GEOMAG (10 * 16 +  0)"}; break;
					case ODR_PRESSURE:			s += std::string{"ODR_PRESSURE (11 * 16 + 12)"}; break;
					case ODR_GYRO_CALIBR:		s += std::string{"ODR_GYRO_CALIBR (11 * 16 +  8)"}; break;
					case ODR_CPASS_CALIBR:		s += std::string{"ODR_CPASS_CALIBR (11 * 16 +  4)"}; break;

					// Sensor output data rate counter
					case ODR_CNTR_ACCEL: 		s += std::string{"ODR_CNTR_ACCEL (9 * 16 + 14)"}; break;
					case ODR_CNTR_GYRO:	 		s += std::string{"ODR_CNTR_GYRO	(9 * 16 + 10)"}; break;
					case ODR_CNTR_CPASS: 		s += std::string{"ODR_CNTR_CPASS (9 * 16 +  6)"}; break;
					case ODR_CNTR_ALS:	 		s += std::string{"ODR_CNTR_ALS (9 * 16 +  2)"}; break;
					case ODR_CNTR_QUAT6: 		s += std::string{"ODR_CNTR_QUAT6 (8 * 16 + 12)"}; break;
					case ODR_CNTR_QUAT9: 		s += std::string{"ODR_CNTR_QUAT9 (8 * 16 +  8)"}; break;
					case ODR_CNTR_PQUAT6: 		s += std::string{"ODR_CNTR_PQUAT6 (8 * 16 +  4)"}; break;
					case ODR_CNTR_GEOMAG: 		s += std::string{"ODR_CNTR_GEOMAG (8 * 16 +  0)"}; break;
					case ODR_CNTR_PRESSURE: 	s += std::string{"ODR_CNTR_PRESSURE (9 * 16 + 12)"}; break;
					case ODR_CNTR_GYRO_CALIBR: 	s += std::string{"ODR_CNTR_GYRO_CALIBR (9 * 16 +  8)"}; break;
					case ODR_CNTR_CPASS_CALIBR:	s += std::string{"ODR_CNTR_CPASS_CALIBR (9 * 16 +  4)"}; break;

					// Gyro FSR
					case GYRO_FULLSCALE: 		s += std::string{"Gyro FSR (72 * 16 + 12)"}; break;

					// Accel FSR
					case ACC_SCALE: 			s += std::string{"Accel FSR (30 * 16 + 0)"}; break;
					case ACC_SCALE2: 			s += std::string{"Accel2 FSR (79 * 16 + 4)"}; break;


					// Accel FSR
					case GYRO_SF: 				s += std::string{"GYRO SF (19 * 16)"}; break;
					case ACCEL_FB_GAIN: 		s += std::string{"ACCEL FB GAIN (34 * 16)"}; break;
					case ACCEL_ONLY_GAIN: 		s += std::string{"ACCEL ONLY GAIN (16 * 16 + 12)"}; break;

					// Gyro Bias
					case GYRO_BIAS_X:		s += std::string{"GYRO_BIAS_X = (139 * 16 + 4)"} + ""; break;
					case GYRO_BIAS_Y: 		s += std::string{"GYRO_BIAS_Y = (139 * 16 + 8)"} + ""; break;
					case GYRO_BIAS_Z: 		s += std::string{"GYRO_BIAS_Y = (139 * 16 + 12)"} + ""; break;
					case GYRO_ACCURACY: 	s += std::string{"GYRO_ACCURACY = (138 * 16 +  2)"} + ""; break;
					case GYRO_BIAS_SET: 	s += std::string{"GYRO_BIAS_SET = (138 * 16 +  6)"} + ""; break;
					case GYRO_LAST_TEMPR: 	s += std::string{"GYRO_LAST_TEMPR = (134 * 16)"} + ""; break;
					case GYRO_SLOPE_X: 		s += std::string{"GYRO_SLOPE_X = (78 * 16 +  4)"} + ""; break;
					case GYRO_SLOPE_Y: 		s += std::string{"GYRO_SLOPE_Y = (78 * 16 +  8)"} + ""; break;
					case GYRO_SLOPE_Z: 		s += std::string{"GYRO_SLOPE_Z = (78 * 16 + 12)"} + ""; break;


					case ACCEL_BIAS_X: 				s += std::string{"ACCEL_BIAS_X = (110 * 16 + 4)"} + ""; break;
					case ACCEL_BIAS_Y: 				s += std::string{"ACCEL_BIAS_Y = (110 * 16 + 8)"} + ""; break;
					case ACCEL_BIAS_Z: 				s += std::string{"ACCEL_BIAS_Z = (110 * 16 + 12)"} + ""; break;
					case ACCEL_ACCURACY: 			s += std::string{"ACCEL_ACCURACY = (97 * 16)"} + ""; break;
					case ACCEL_CAL_RESET: 			s += std::string{"ACCEL_CAL_RESET = (77 * 16)"} + ""; break;
					case ACCEL_VARIANCE_THRESH: 	s += std::string{"ACCEL_VARIANCE_THRESH = (93 * 16)"} + ""; break;
					case ACCEL_CAL_RATE: 			s += std::string{"ACCEL_CAL_RATE = (94 * 16 + 4)"} + ""; break;
					case ACCEL_PRE_SENSOR_DATA:		s += std::string{"ACCEL_PRE_SENSOR_DATA = (97 * 16 + 4)"} + ""; break;
					case ACCEL_COVARIANCE:			s += std::string{"ACCEL_COVARIANCE = (101 * 16 + 8)"} + ""; break;
					case ACCEL_ALPHA_VAR:			s += std::string{"ACCEL_ALPHA_VAR = (91 * 16)"} + ""; break;
					case ACCEL_A_VAR:				s += std::string{"ACCEL_A_VAR = (92 * 16)"} + ""; break;
					case ACCEL_CAL_INIT:			s += std::string{"ACCEL_CAL_INIT = (94 * 16 + 2)"} + ""; break;
					case ACCEL_CAL_SCALE_COVQ_IN_RANGE:		s += std::string{"ACCEL_CAL_SCALE_COVQ_IN_RANGE = (194 * 16)"} + ""; break;
					case ACCEL_CAL_SCALE_COVQ_OUT_RANGE:	s += std::string{"ACCEL_CAL_SCALE_COVQ_OUT_RANGE = (195 * 16)"} + ""; break;
					case ACCEL_CAL_TEMPERATURE_SENSITIVITY:	s += std::string{"ACCEL_CAL_TEMPERATURE_SENSITIVITY = (194 * 16 + 4)"} + ""; break;
					case ACCEL_CAL_TEMPERATURE_OFFSET_TRIM:	s += std::string{"ACCEL_CAL_TEMPERATURE_OFFSET_TRIM = (194 * 16 + 12"} + ""; break;


					case CPASS_BIAS_X: 			s += std::string{"CPASS_BIAS_X = (126 * 16 + 4)"} + ""; break;
					case CPASS_BIAS_Y: 			s += std::string{"CPASS_BIAS_Y = (126 * 16 + 8)"} + ""; break;
					case CPASS_BIAS_Z: 			s += std::string{"CPASS_BIAS_Z = (126 * 16 + 12)"} + ""; break;

					case CPASS_ACCURACY: 		s += std::string{"CPASS_ACCURACY = (37 * 16)"} + ""; break;
					case CPASS_BIAS_SET: 		s += std::string{"CPASS_BIAS_SET = (34 * 16 + 14)"} + ""; break;
					case MAR_MODE: 				s += std::string{"MAR_MODE = (37 * 16 + 2)"} + ""; break;
					case CPASS_COVARIANCE: 		s += std::string{"CPASS_COVARIANCE = (115 * 16)"} + ""; break;
					case CPASS_COVARIANCE_CUR: 	s += std::string{"CPASS_COVARIANCE_CUR = (118 * 16 + 8)"} + ""; break;
					case CPASS_REF_MAG_3D: 		s += std::string{"CPASS_REF_MAG_3D = (122 * 16)"} + ""; break;
					case CPASS_CAL_INIT: 		s += std::string{"CPASS_CAL_INIT = (114 * 16)"} + ""; break;
					case CPASS_EST_FIRST_BIAS: 	s += std::string{"CPASS_EST_FIRST_BIAS = (113 * 16)"} + ""; break;
					case MAG_DISTURB_STATE: 	s += std::string{"MAG_DISTURB_STATE = (113 * 16 + 2)"} + ""; break;
					case CPASS_VAR_COUNT: 		s += std::string{"CPASS_VAR_COUNT = (113 * 16 + 6)"} + ""; break;
					case CPASS_COUNT_7: 		s += std::string{"CPASS_COUNT_7 = (87 * 16 + 2)"} + ""; break;
					case CPASS_MAX_INNO: 		s += std::string{"CPASS_MAX_INNO = (124 * 16)"} + ""; break;
					case CPASS_BIAS_OFFSET: 	s += std::string{"CPASS_BIAS_OFFSET = (113 * 16 + 4)"} + ""; break;
					case CPASS_CUR_BIAS_OFFSET: s += std::string{"CPASS_CUR_BIAS_OFFSET (114 * 16 + 4)"} + ""; break;
					case CPASS_PRE_SENSOR_DATA: s += std::string{"CPASS_PRE_SENSOR_DATA ( 87 * 16 + 4)"} + ""; break;

					case BAC_RATE:				s += std::string{"BAC_RATE(48 * 16 + 10)"} + ""; break;
					case BAC_STATE: 			s += std::string{"BAC_STATE (179 * 16 +  0)"} + ""; break;
					case BAC_STATE_PREV: 		s += std::string{"BAC_STATE_PREV (179 * 16 +  4)"} + ""; break;



					// Mounting matrix
					case CPASS_MTX_00: s += std::string{"CPASS_MTX_00 = (23 * 16 + 0)"} + ""; break;
					case CPASS_MTX_01: s += std::string{"CPASS_MTX_01 = (23 * 16 + 4)"} + ""; break;
					case CPASS_MTX_02: s += std::string{"CPASS_MTX_02 = (23 * 16 + 8)"} + ""; break;
					case CPASS_MTX_10: s += std::string{"CPASS_MTX_10 = (23 * 16 + 12)"} + ""; break;
					case CPASS_MTX_11: s += std::string{"CPASS_MTX_11 = (24 * 16 + 0)"} + ""; break;
					case CPASS_MTX_12: s += std::string{"CPASS_MTX_12 = (24 * 16 + 4)"} + ""; break;
					case CPASS_MTX_20: s += std::string{"CPASS_MTX_20 = (24 * 16 + 8)"} + ""; break;
					case CPASS_MTX_21: s += std::string{"CPASS_MTX_21 = (24 * 16 + 12)"} + ""; break;
					case CPASS_MTX_22: s += std::string{"CPASS_MTX_22 = (25 * 16 + 0)"} + ""; break;


					// Mounting matrix
					case B2S_RATE:		s += std::string{"B2S_RATE =  (48 * 16 + 8)"} + ""; break;
					case B2S_MTX_00:	s += std::string{"B2S_MTX_00 = (208 * 16 + 0)"} + ""; break;
					case B2S_MTX_01: 	s += std::string{"B2S_MTX_01 = (208 * 16 + 4)"} + ""; break;
					case B2S_MTX_02: 	s += std::string{"B2S_MTX_02 = (208 * 16 + 8)"} + ""; break;
					case B2S_MTX_10: 	s += std::string{"B2S_MTX_10 = (208 * 16 + 12)"} + ""; break;
					case B2S_MTX_11: 	s += std::string{"B2S_MTX_11 = (209 * 16 + 0)"} + ""; break;
					case B2S_MTX_12: 	s += std::string{"B2S_MTX_12 = (209 * 16 + 4)"} + ""; break;
					case B2S_MTX_20: 	s += std::string{"B2S_MTX_20 = (209 * 16 + 8)"} + ""; break;
					case B2S_MTX_21: 	s += std::string{"B2S_MTX_21 = (209 * 16 + 12)"} + ""; break;
					case B2S_MTX_22: 	s += std::string{"B2S_MTX_22 = (210 * 16 + 0)"} + ""; break;

					// Dmp3 orientation parameters (Q30) initialization
					case Q0_QUAT6: s += std::string{"Q0_QUAT6 = (33 * 16 + 0)"} + ""; break;
					case Q1_QUAT6: s += std::string{"Q1_QUAT6 = (33 * 16 + 4)"} + ""; break;
					case Q2_QUAT6: s += std::string{"Q2_QUAT6 = (33 * 16 + 8)"} + ""; break;
					case Q3_QUAT6: s += std::string{"Q3_QUAT6 = (33 * 16 + 12)"} + ""; break;

				}
				s += ']';

				return s;
			}
			break;

			default:
				return std::string{" [??]"};
		}
	}

	return std::string{" [??]"};

}


//=====================================================================================
// Command Description
//=====================================================================================
std::string CommandDescription( int reg, int bank )
{
	// For Bank 0
	if( bank == 0 )
	{
		// For Bank 0
		switch(reg)
		{
			case 0x00: return std::string{"REG_WHO_AM_I"}; break;
			case 0x03: return std::string{"REG_USER_CTRL"}; break;
			case 0x05: return std::string{"REG_LP_CONFIG"}; break;
			case 0x06: return std::string{"REG_PWR_MGMT_1"}; break;
			case 0x07: return std::string{"REG_PWR_MGMT_2"}; break;

			case 0x0F: return std::string{"REG_INT_PIN_CFG"}; break;
			case 0x10: return std::string{"REG_INT_ENABLE"}; break;
			case 0x11: return std::string{"REG_INT_ENABLE_1"}; break;
			case 0x12: return std::string{"REG_INT_ENABLE_2"}; break;
			case 0x13: return std::string{"REG_INT_ENABLE_3"}; break;

			case 0x18: return std::string{"REG_DMP_INT_STATUS"}; break;
			case 0x19: return std::string{"REG_INT_STATUS"}; break;
			case 0x1A: return std::string{"REG_INT_STATUS_1"}; break;
			case 0x1B: return std::string{"REG_INT_STATUS_2"}; break;
			case 0x26: return std::string{"REG_SINGLE_FIFO_PRIORITY_SEL"}; break;

			case 0x2D: return std::string{"REG_ACCEL_XOUT_H_SH"}; break;
			case 0x2E: return std::string{"REG_ACCEL_XOUT_L_SH"}; break;
			case 0x2F: return std::string{"REG_ACCEL_YOUT_H_SH"}; break;
			case 0x30: return std::string{"REG_ACCEL_YOUT_L_SH"}; break;
			case 0x31: return std::string{"REG_ACCEL_ZOUT_H_SH"}; break;
			case 0x32: return std::string{"REG_ACCEL_ZOUT_L_SH"}; break;
			case 0x33: return std::string{"REG_GYRO_XOUT_H_SH"}; break;

			case 0x39: return std::string{"REG_TEMPERATURE"}; break;

			case 0x3B: return std::string{"REG_EXT_SLV_SENS_DATA_00"}; break;
			case 0x43: return std::string{"REG_EXT_SLV_SENS_DATA_08"}; break;
			case 0x44: return std::string{"REG_EXT_SLV_SENS_DATA_09"}; break;
			case 0x45: return std::string{"REG_EXT_SLV_SENS_DATA_10"}; break;

			case 0x50: return std::string{"PRGM_START_ADDRH"}; break;
			case 0x53: return std::string{"REG_TEMP_CONFIG"}; break;

			case 0x66: return std::string{"REG_FIFO_EN"}; break;
			case 0x67: return std::string{"REG_FIFO_EN_2"}; break;
			case 0x68: return std::string{"REG_FIFO_RST"}; break;

			case 0x70: return std::string{"REG_FIFO_COUNT_H"}; break;
			case 0x71: return std::string{"REG_FIFO_COUNT_L"}; break;
			case 0x72: return std::string{"REG_FIFO_R_W"}; break;

			case 0x75: return std::string{"REG_HW_FIX_DISABLE"}; break;
			case 0x76: return std::string{"REG_FIFO_CFG"}; break;

			// Memory Bank Selection
			case 0x7C: return std::string{"REG_MEM_START_ADDR"}; break;
			case 0x7D: return std::string{"REG_MEM_R_W"}; break;
			case 0x7E: return std::string{"REG_MEM_BANK_SEL"}; break;

			// Register Bank Selection 0..3
			case 0x7F: return std::string{"REG_BANK_SEL"}; break;

			default: return std::string{"** Bank 0 - Reg ?? **"};
		}
	}
	// Bank 1
	else if ( bank == 1 )
	{
		switch(reg)
		{
			case 0x02: return std::string{"REG_SELF_TEST1"}; break;
			case 0x03: return std::string{"REG_SELF_TEST2"}; break;
			case 0x04: return std::string{"REG_SELF_TEST3"}; break;
			case 0x0E: return std::string{"REG_SELF_TEST4"}; break;
			case 0x0F: return std::string{"REG_SELF_TEST5"}; break;
			case 0x10: return std::string{"REG_SELF_TEST6"}; break;

			case 0x14: return std::string{"REG_XA_OFFS_H"}; break;
			case 0x15: return std::string{"REG_XA_OFFS_L"}; break;
			case 0x17: return std::string{"REG_YA_OFFS_H"}; break;
			case 0x18: return std::string{"REG_YA_OFFS_L"}; break;
			case 0x1A: return std::string{"REG_ZA_OFFS_H"}; break;
			case 0x1B: return std::string{"REG_ZA_OFFS_L"}; break;

			case 0x28: return std::string{"REG_TIMEBASE_CORRECTION_PLL"}; break;
			case 0x29: return std::string{"REG_TIMEBASE_CORRECTION_RCOSC"}; break;

			case 0x50: return std::string{"REG_PRGM_START_ADDRH"}; break;

			case 0x7F: return std::string{"REG_BANK_SEL"}; break;

			default: return std::string{"** Bank 1 - Reg ?? **"};
		}
	}
	// Bank 2
	else if ( bank == 2 )
	{
		switch(reg)
		{
			case 0x00: return std::string{"REG_GYRO_SMPLRT_DIV"}; break;
			case 0x01: return std::string{"REG_GYRO_CONFIG_1"}; break;
			case 0x02: return std::string{"REG_GYRO_CONFIG_2"}; break;
			case 0x03: return std::string{"REG_XG_OFFS_USRH"}; break;
			case 0x04: return std::string{"REG_XG_OFFS_USRL"}; break;
			case 0x05: return std::string{"REG_YG_OFFS_USRH"}; break;
			case 0x06: return std::string{"REG_YG_OFFS_USRL"}; break;
			case 0x07: return std::string{"REG_ZG_OFFS_USRH"}; break;
			case 0x08: return std::string{"REG_ZG_OFFS_USRL"}; break;
			case 0x10: return std::string{"REG_ACCEL_SMPLRT_DIV_1"}; break;
			case 0x11: return std::string{"REG_ACCEL_SMPLRT_DIV_2"}; break;
			case 0x14: return std::string{"REG_ACCEL_CONFIG"}; break;
			case 0x15: return std::string{"REG_ACCEL_CONFIG_2"}; break;
			case 0x20: return std::string{"REG_PRS_ODR_CONFIG"}; break;
			case 0x50: return std::string{"REG_PRGM_START_ADDRH"}; break;
			case 0x54: return std::string{"REG_MOD_CTRL_USR"}; break;
			case 0x7F: return std::string{"REG_BANK_SEL"}; break;

			default: return std::string{"** Bank 2 - Reg ?? **"};
		}
	}
	// Bank 3
	else if ( bank == 3 )
	{
		// Bank3 is used for I2C comms
		switch(reg)
		{
			case 0x00: return std::string{"REG_I2C_MST_ODR_CONFIG"}; break;
			case 0x01: return std::string{"REG_I2C_MST_CTRL"}; break;
			case 0x02: return std::string{"REG_I2C_MST_DELAY_CTRL"}; break;
			case 0x03: return std::string{"REG_I2C_SLV0_ADDR"}; break;
			case 0x04: return std::string{"REG_I2C_SLV0_REG"}; break;
			case 0x05: return std::string{"REG_I2C_SLV0_CTRL"}; break;
			case 0x06: return std::string{"REG_I2C_SLV0_DO"}; break;
			case 0x07: return std::string{"REG_I2C_SLV1_ADDR"}; break;
			case 0x08: return std::string{"REG_I2C_SLV1_REG"}; break;
			case 0x09: return std::string{"REG_I2C_SLV1_CTRL"}; break;
			case 0x0A: return std::string{"REG_I2C_SLV1_DO"}; break;
			case 0x0B: return std::string{"REG_I2C_SLV2_ADDR"}; break;
			case 0x0C: return std::string{"REG_I2C_SLV2_REG"}; break;
			case 0x0D: return std::string{"REG_I2C_SLV2_CTRL"}; break;
			case 0x0E: return std::string{"REG_I2C_SLV2_DO"}; break;
			case 0x0F: return std::string{"REG_I2C_SLV3_ADDR"}; break;
			case 0x10: return std::string{"REG_I2C_SLV3_REG"}; break;
			case 0x11: return std::string{"REG_I2C_SLV3_CTRL"}; break;
			case 0x12: return std::string{"REG_I2C_SLV3_DO"}; break;
			case 0x15: return std::string{"REG_I2C_SLV4_CTRL"}; break;

			case 0x7F: return std::string{"REG_BANK_SEL"}; break;

			default: return std::string{"** Bank 3 - Reg ?? **"};
		}
	}
	else
	{
		return std::string{"** Unknown Bank - ????? **"};
	}
}



#ifdef __cplusplus
}
#endif

