/*
 * InvMsg.h
 *
 *  Created on: Mar 28, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_DEBUGLOG_H_
#define SRC_PROJECT_DEBUGLOG_H_


#include <project.hpp>
#include "main.h"
#include "ICM20948.h"


#ifdef __cplusplus
extern "C"
{
#endif


void DBG_LOG_MESSAGE(const char* pData);
void DBG_LOG_RD_IMU( uint8_t reg, const uint8_t* pData, uint32_t size );
void DBG_LOG_WR_IMU( uint8_t reg, const uint8_t* pData, uint32_t size );


void DBG_QUATERNION_TO_JS_OBJECT(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id );
void DBG_QUATERNION_TO_JS_OBJECT_C(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id );
void DBG_QUATERNION_TO_FLOATS(float quat_w, float quat_x, float quat_y, float quat_z, uint8_t id );


#ifdef __cplusplus
}
#endif


#endif /* SRC_PROJECT_DEBUGLOG_H_ */
