/*
 * RegisterDescription.c
 *
 *  Created on: Apr 3, 2024
 *      Author: Michael.Oleksy
 */

#include "RegisterDescription.h"


//===========================================================
// Bank 0
//===========================================================
std::string Register_0x0003(uint8_t data)
{
	std::string ss = " ";

	// DMP Enabled
	if( data & 0x80 )
		ss += "DMP ON; ";

	// FIFO enabled
	if( data & 0x40 )
		ss += "FIFO ON; ";

	// Check I2C
	if( data & 0x20 )
		ss += "I2C ON; ";

	// Check I2C
	if( data & 0x10 )
		ss += "SPI ON; ";

	// DMP Reset
	if( data & 0x08 )
		ss += "DMP reset; ";

	// SRAM Reset
	if( data & 0x04 )
		ss += "SRAM reset; ";

	// I2C Reset
	if( data & 0x02 )
		ss += "I2C reset; ";

	return ss;
}


std::string Register_0x0006(uint8_t data)
{
	std::string ss = " ";

	// Check Device RESET
	if( data & 0x80 )
		ss += "Device Reset; ";

	// Check SLEEP
	if( data & 0x40 )
		ss += "Sleep Mode ON; ";

	// Check LP_EN
	if( data & 0x20 )
		ss += "Low power ON; ";

	// Check temperature Sensor
	if( data & 0x08 )
		ss += "Temperature Sensor ON; ";

	// Check clock
	switch(data & 0x07)
	{
		case 0:
		case 6: ss += "Internal 20Mhz; "; break;

		case 1:
		case 2:
		case 3:
		case 4:
		case 5: ss += "Auto Clock best available; "; break;
		case 7: ss += "Stop Clock; "; break;
	}

	return ss;
}


std::string Register_0x0007(uint8_t data)
{
	std::string ss = " ";

	// DMP Enabled
	if( data & 0x38 )
		ss += "Accelerometer disable (all axes); ";
	else
		ss += "Accelerometer on (all axes); ";

	// FIFO enabled
	if( data & 0x07 )
		ss += "Gyroscope disable (all axes); ";
	else
		ss += "Gyroscope on (all axes); ";

	return ss;
}


std::string Register_0x0010(uint8_t data)
{
	std::string ss = " ";

	// FSYNC
	if( data & 0x80 )
		ss += "Enable Wake-On-FSYNC interrupt; ";

	// Check I2C
	if( data & 0x08 )
		ss += "Enable Wake-On-Mmotion interrupt; ";

	// DMP Reset
	if( data & 0x04 )
		ss += "Enable PLL RDY interrupt; ";

	// SRAM Reset
	if( data & 0x02 )
		ss += "Enable DMP interrupt; ";

	// I2C Reset
	if( data & 0x01 )
		ss += "Enable I2C interrupt; ";

	return ss;
}



std::string Register_0x0011(uint8_t data)
{
	std::string ss = " ";

	if( data & 0x01 )
		ss += "Enable Raw-Data-Ready interrupt; ";

	return ss;
}


std::string Register_0x0012(uint8_t data)
{
	std::string ss = " ";

	if( data & 0x1F )
		ss += "Enable FIFO overflow interrupt; ";

	return ss;
}


std::string Register_0x0013(uint8_t data)
{
	std::string ss = " ";

	if( data & 0x1F )
		ss += "Enable FIFO watermark interrupt; ";

	return ss;
}



std::string Register_0x0019(uint8_t data)
{
	std::string ss = " ";

	// RFU
	if( data & 0xF0 )
		ss += "Reserved; ";

	if( data & 0x08 )
		ss += "Wake-On-Motion interrupt generated; ";

	if( data & 0x04 )
		ss += "PLL-RDY interrupt generated; ";

	if( data & 0x02 )
		ss += "DMP INT1 generated; ";

	if( data & 0x01 )
		ss += "I2C interrupt generated; ";

	return ss;
}




//===========================================================
// Bank 2
//===========================================================
std::string Register_0x0200(uint8_t data)
{
	std::string ss = "Sample rate Divider. (1.1 kHz/(1+GYRO_SMPLRT_DIV[7:0])";
	return ss;
}

std::string Register_0x0210(uint8_t data)
{
	std::string ss = "ACCL Sample rate Divider. (Bits [11:8])";
	return ss;
}

std::string Register_0x0211(uint8_t data)
{
	std::string ss = "ACCL Sample rate Divider. (Bits [7:0]. 1.125 kHz/(1+ACCEL_SMPLRT_DIV[11:0]))";
	return ss;
}



