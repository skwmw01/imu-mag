/*
 * RegisterDescription.h
 *
 *  Created on: Apr 3, 2024
 *      Author: Michael.Oleksy
 */

#ifndef _DEBUG_REGISTERDESCRIPTION_H_
#define _DEBUG_REGISTERDESCRIPTION_H_

#include <iostream>


#ifdef __cplusplus
extern "C"
{
#endif


// Bank 0
std::string Register_0x0003(uint8_t data);
std::string Register_0x0006(uint8_t data);
std::string Register_0x0007(uint8_t data);
std::string Register_0x0010(uint8_t data);
std::string Register_0x0011(uint8_t data);
std::string Register_0x0012(uint8_t data);
std::string Register_0x0013(uint8_t data);
std::string Register_0x0019(uint8_t data);


// Bank 2
std::string Register_0x0210(uint8_t data);
std::string Register_0x0211(uint8_t data);



#ifdef __cplusplus
}
#endif

#endif /* _REGISTERDESCRIPTION_H_ */
