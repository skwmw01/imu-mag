/*
 * system.h
 *
 *  Created on: Apr 5, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_ICM20948_DRIVER_SYSTEM_H_
#define SRC_PROJECT_ICM20948_DRIVER_SYSTEM_H_


/*
* Select communication between Atmel and INV device
*/
#define USE_SPI_NOT_I2C				0		/* Default configuration - I2C */

#define AK0991x_DEFAULT_I2C_ADDR	0x0C	/* The default I2C address for AK0991x Magnetometers */
#define AK0991x_SECONDARY_I2C_ADDR  0x0E	/* The secondary I2C address for AK0991x Magnetometers */

#define EXTERNAL_SENSOR				0		/* Default configuration is on-board sensor and this flag need not have to be changed */

#if (EXTERNAL_SENSOR == 1)
#define CHIP_SELECT					0
#else
#define CHIP_SELECT					1
#endif

#define ICM_I2C_ADDR_REVA			0x68 	/* I2C slave address for INV device on Rev A board */
#define ICM_I2C_ADDR_REVB			0x69 	/* I2C slave address for INV device on Rev B board */

/*
* Select communication between Atmel and INV device by setting 0/1 to one of the following defines
*/
#define SERIF_TYPE_SPI (USE_SPI_NOT_I2C)
#define SERIF_TYPE_I2C !(USE_SPI_NOT_I2C)





#endif /* SRC_PROJECT_ICM20948_DRIVER_SYSTEM_H_ */
