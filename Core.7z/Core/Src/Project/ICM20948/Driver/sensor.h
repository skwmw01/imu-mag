/*
 * sensor.h
 *
 *  Created on: Mar 27, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_ICM20948_DRIVER_SENSOR_H_
#define SRC_PROJECT_ICM20948_DRIVER_SENSOR_H_


#ifdef __cplusplus
extern "C"
{
#endif


#include "ICM20948.h"


#define DEF_ST_ACCEL_FS                 2
#define DEF_ST_GYRO_FS_DPS              250
#define DEF_ST_SCALE                    32768
#define DEF_SELFTEST_GYRO_SENS			(DEF_ST_SCALE / DEF_ST_GYRO_FS_DPS)
#define DEF_ST_ACCEL_FS_MG				2000

#ifndef INV20948_ABS
#define INV20948_ABS(x) (((x) < 0) ? -(x) : (x))
#endif

/* forward declaration */
//struct inv_icm20948;


/* Forward declaration */
int icm20948_sensor_setup(void);
//void iddwrapper_protocol_event_cb(enum DynProtocolEtype etype, enum DynProtocolEid eid, const DynProtocolEdata_t * edata, void * cookie);
//void iddwrapper_transport_event_cb(enum DynProTransportEvent e, union DynProTransportEventData data, void * cookie);
//void sensor_event(const inv_sensor_event_t * event, void * arg);
//int handle_command(enum DynProtocolEid eid, const DynProtocolEdata_t * edata, DynProtocolEdata_t * respdata);
int icm20948_run_selftest(void);
void inv_icm20948_get_st_bias(struct inv_icm20948 * s, int *gyro_bias, int *accel_bias, int * st_bias, int * unscaled);
//void InvEMDFrontEnd_busyWaitUsHook(uint32_t us);
int InvEMDFrontEnd_isHwFlowCtrlSupportedHook(void);
int InvEMDFrontEnd_putcharHook(int c);
//void build_sensor_event_data(void * context, uint8_t sensortype, uint64_t timestamp, const void * data, const void *arg);
void inv_icm20948_sleep(int ms);
int load_dmp3(void);
void check_rc(int rc, const char * msg_context);

//extern inv_icm20948_t icm_device;
//extern DynProtocol_t protocol;
//extern DynProTransportUart_t transport;


#ifdef __cplusplus
}
#endif


#endif /* SRC_PROJECT_ICM20948_DRIVER_SENSOR_H_ */
