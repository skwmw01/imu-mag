/*
 * sensor.c
 *
 *  Created on: Mar 27, 2024
 *      Author: Michael.Oleksy
 */

/* TDK Sensor */
#include <ICM20948/ICMRegisters.h>
#include "sensor.h"
#include "ICM20948/Driver/ICM20948LoadFirmware.h"
#include "ICM20948/Driver/ICM20948AuxCompassAkm.h"

#include "SensorTypes.h"
#include "ICM20948Defs.h"
#include "DebugLog.h"
#include "stdio.h"

// Needed for my settings
#include "ICM20948/Driver/ICM20948Dmp3Driver.h"
#include "ICM20948/Driver/ICM20948Transport.h"
#include "ICM20948/Driver/system.h"



#ifdef __cplusplus
extern "C"
{
#endif


// DMP image
static const uint8_t dmp3_image[] = {
	#include "icm20948_img.dmp3a.h"
};


/*
* Just a handy variable to handle the icm20948 object
*/
inv_icm20948_t icm_device;



static const uint8_t EXPECTED_WHOAMI[] = { 0xEA }; /* WHOAMI value for ICM20948 or derivative */
static int unscaled_bias[THREE_AXES * 2];

/* FSR configurations */
int32_t cfg_acc_fsr = 4; // Default = +/- 4g. Valid ranges: 2, 4, 8, 16
int32_t cfg_gyr_fsr = 2000; // Default = +/- 2000dps. Valid ranges: 250, 500, 1000, 2000


/*
* Mounting matrix configuration applied for Accel, Gyro and Mag
*/
static const float cfg_mounting_matrix[9]= {
	1.f, 0, 0,
	0, 1.f, 0,
	0, 0, 1.f
};


static uint8_t convert_to_generic_ids[INV_ICM20948_SENSOR_MAX] = {
	INV_SENSOR_TYPE_ACCELEROMETER,
	INV_SENSOR_TYPE_GYROSCOPE,
	INV_SENSOR_TYPE_RAW_ACCELEROMETER,
	INV_SENSOR_TYPE_RAW_GYROSCOPE,
	INV_SENSOR_TYPE_UNCAL_MAGNETOMETER,
	INV_SENSOR_TYPE_UNCAL_GYROSCOPE,
	INV_SENSOR_TYPE_BAC,
	INV_SENSOR_TYPE_STEP_DETECTOR,
	INV_SENSOR_TYPE_STEP_COUNTER,
	INV_SENSOR_TYPE_GAME_ROTATION_VECTOR,
	INV_SENSOR_TYPE_ROTATION_VECTOR,
	INV_SENSOR_TYPE_GEOMAG_ROTATION_VECTOR,
	INV_SENSOR_TYPE_MAGNETOMETER,
	INV_SENSOR_TYPE_SMD,
	INV_SENSOR_TYPE_PICK_UP_GESTURE,
	INV_SENSOR_TYPE_TILT_DETECTOR,
	INV_SENSOR_TYPE_GRAVITY,
	INV_SENSOR_TYPE_LINEAR_ACCELERATION,
	INV_SENSOR_TYPE_ORIENTATION,
	INV_SENSOR_TYPE_B2S
};





int load_dmp3(void)
{
	int rc = 0;
	//INV_MSG(INV_MSG_LEVEL_INFO, "Load DMP3 image");
	rc = inv_icm20948_load(&icm_device, dmp3_image, sizeof(dmp3_image));
	return rc;
}



void icm20948_apply_mounting_matrix(void)
{
	int ii;


	for (ii = 0; ii < INV_ICM20948_SENSOR_MAX; ii++)
	{
		char msg[30] = {0};
		sprintf(msg, "// SET MATRIX - iteration: %i", ii);
		//DBG_LOG_MESSAGE(msg);

		inv_icm20948_set_matrix(&icm_device, cfg_mounting_matrix, ii);
	}
}

void icm20948_set_fsr(void)
{
	//DBG_LOG_MESSAGE("//===== SET FSR : RAW ACCELLEROMETER ======");
	inv_icm20948_set_fsr(&icm_device, INV_ICM20948_SENSOR_RAW_ACCELEROMETER, (const void *)&cfg_acc_fsr);

	//DBG_LOG_MESSAGE("//===== SET FSR : ACCELLEROMETER ======");
	inv_icm20948_set_fsr(&icm_device, INV_ICM20948_SENSOR_ACCELEROMETER, (const void *)&cfg_acc_fsr);

	//DBG_LOG_MESSAGE("//===== SET FSR : RAW GYROSCOPE ======");
	inv_icm20948_set_fsr(&icm_device, INV_ICM20948_SENSOR_RAW_GYROSCOPE, (const void *)&cfg_gyr_fsr);

	//DBG_LOG_MESSAGE("//===== SET FSR : GYROSCOPE ======");
	inv_icm20948_set_fsr(&icm_device, INV_ICM20948_SENSOR_GYROSCOPE, (const void *)&cfg_gyr_fsr);

	//DBG_LOG_MESSAGE("//===== SET FSR : GYROSCOPE UNCALIBRATED ======");
	inv_icm20948_set_fsr(&icm_device, INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED, (const void *)&cfg_gyr_fsr);
}

//
//int icm20948_sensor_setup(void)
//{
//	int rc;
//	uint8_t whoami = 0xff;
//
//	// Issue WHO_AM_I
//	rc = inv_icm20948_get_whoami(&icm_device, &whoami);
//
////	if (interface_is_SPI() == 0)	{		// If we're using I2C
////		if (whoami == 0xff) {				// if whoami fails try the other I2C Address
////			switch_I2C_to_revA();
////			rc = inv_icm20948_get_whoami(&icm_device, &whoami);
////		}
////	}
//	//INV_MSG(INV_MSG_LEVEL_INFO, "ICM20948 WHOAMI value=0x%02x", whoami);
//
//	/*
//	* Check if WHOAMI value corresponds to any value from EXPECTED_WHOAMI array
//	*/
//	/*
//	for(i = 0; i < sizeof(EXPECTED_WHOAMI)/sizeof(EXPECTED_WHOAMI[0]); ++i) {
//		if(whoami == EXPECTED_WHOAMI[i]) {
//			break;
//		}
//	}
//
//	if(i == sizeof(EXPECTED_WHOAMI)/sizeof(EXPECTED_WHOAMI[0])) {
//		//INV_MSG(INV_MSG_LEVEL_ERROR, "Bad WHOAMI value. Got 0x%02x.", whoami);
//		return rc;
//	}
//	 */
//
//	/* Setup accel and gyro mounting matrix and associated angle for current board */
//	inv_icm20948_init_matrix(&icm_device);
//
//	/* set default power mode */
//	//INV_MSG(INV_MSG_LEVEL_VERBOSE, "Putting Icm20948 in sleep mode...");
//	rc = inv_icm20948_initialize(&icm_device, dmp3_image, sizeof(dmp3_image));
//	if (rc != 0) {
//		//INV_MSG(INV_MSG_LEVEL_ERROR, "Initialization failed. Error loading DMP3...");
//		return rc;
//	}
//
//	/*
//	* Configure and initialize the ICM20948 for normal use
//	*/
//	//INV_MSG(INV_MSG_LEVEL_INFO, "Booting up icm20948...");
//
//	/* Initialize auxiliary sensors */
//	DBG_LOG_MESSAGE("//===== AUX COMPASS ======");
//	inv_icm20948_register_aux_compass( &icm_device, INV_ICM20948_COMPASS_ID_AK09916, AK0991x_DEFAULT_I2C_ADDR);
//
//	DBG_LOG_MESSAGE("//===== INITIALISE AUXILARY ======");
//	rc = inv_icm20948_initialize_auxiliary(&icm_device);
//	if (rc == -1)
//	{
//		DBG_LOG_MESSAGE("Compass not detected...\r\n");
//		//INV_MSG(INV_MSG_LEVEL_ERROR, "Compass not detected...");
//	}
//
//	DBG_LOG_MESSAGE("//===== APPLY MOUNTING MATRIX ======");
//	icm20948_apply_mounting_matrix();
//
//	DBG_LOG_MESSAGE("//===== SET FSR ======");
//	icm20948_set_fsr();
//
//	DBG_LOG_MESSAGE("//===== RE-INIT BASE STATE DATA STRUCTURE =====");
//	/* re-initialize base state structure */
//	inv_icm20948_init_structure(&icm_device);
//
//	/* we should be good to go ! */
//	DBG_LOG_MESSAGE("//***** IMU SETUP COMPLETE *****");
//
//	//INV_MSG(INV_MSG_LEVEL_VERBOSE, "We're good to go !");
//
//	DBG_LOG_MESSAGE("//===================================");
//	DBG_LOG_MESSAGE("//===== ADDITIONAL IMU SETTINGS =====");
//	DBG_LOG_MESSAGE("//===================================");
//	dmp_icm20948_reset_control_registers(&icm_device);
//
//
//	DBG_LOG_MESSAGE("//===== REX ADDITIONAL IMU SETTINGS =====");
//
//	dmp_icm20948_rex_setup_quat_output(&icm_device);
//
//	// Enable DMP, FIFO, SPI mode
//	//icm_device.base_state.user_ctrl |= BIT_I2C_MST_EN | BIT_DMP_EN | BIT_FIFO_EN | BIT_I2C_IF_DIS;
//	//inv_icm20948_write_single_mems_reg(&icm_device, REG_USER_CTRL, icm_device.base_state.user_ctrl);
//
//
//	return 0;
//}

#ifdef __cplusplus
}
#endif

