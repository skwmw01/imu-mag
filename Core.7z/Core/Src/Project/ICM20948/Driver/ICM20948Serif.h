/*
 * ICM20948Serif.h
 *
 *  Created on: Mar 26, 2024
 *      Author: Michael.Oleksy
 */

#include <DebugLog.h>
#include "InvError.h"


static inline int inv_icm20948_serif_write_reg(struct inv_icm20948_serif* s, uint8_t reg, const uint8_t * buf, uint32_t len)
{
	assert(s);

	if(len > s->max_write)
	{
		uint8_t msg[] = "// !!!!! ERROR - WRITE LENGTH\r\n";
		DBG_LOG_WR_IMU(reg, msg, sizeof(msg));
		return INV_ERROR_SIZE;
	}

	if(s->write_reg(s->context, reg, buf, len) != 0)
	{
		uint8_t msg[] = "// !!!!! ERROR - WRITE_REG\r\n";
		DBG_LOG_WR_IMU(reg, msg, sizeof(msg));
		return INV_ERROR_TRANSPORT;
	}

	DBG_LOG_WR_IMU(reg, buf, len);
	return 0;
}


static inline int inv_icm20948_serif_read_reg(struct inv_icm20948_serif* s, uint8_t reg, uint8_t* buf, uint32_t len)
{
	assert(s);

	//if(len > s->max_read)
	//	return INV_ERROR_SIZE;

	// When reading using SPI, bit7 of Address must be set
	reg |= READ_BIT_MASK;

	if(s->read_reg(s->context, reg, buf, len) != 0)
		return INV_ERROR_TRANSPORT;

	DBG_LOG_RD_IMU(reg, buf, len);

	return 0;
}
