/*
 * IMU.h
 *
 *  Created on: Mar 13, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_IMU_H_
#define SRC_PROJECT_IMU_H_

#include "main.h"
#include "project.hpp"


struct IMUPort
{
private:
	UINT8			deviceID;

public:
	// Constructor
	IMUPort( GPIO_TypeDef* port, UINT16 pin, SPI_HandleTypeDef& _spiHandle )
		: GPIO_Port{port}
		, GPIO_Pin{pin}
		, spiHandle{_spiHandle} {}

	// Port and pin for CS
	GPIO_TypeDef* 		GPIO_Port;
	UINT16				GPIO_Pin;
	SPI_HandleTypeDef& 	spiHandle;
};


#endif /* SRC_PROJECT_IMU_H_ */
