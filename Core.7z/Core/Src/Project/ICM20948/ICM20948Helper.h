/*
 * ICM20948Helper.h
 *
 *  Created on: Apr 11, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_ICM20948_ICM20948HELPER_H_
#define SRC_PROJECT_ICM20948_ICM20948HELPER_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "project.hpp"
#include "main.h"
#include "ICM20948/Driver/ICM20948Setup.h"


int spi_master_tx(void* ctx, uint8_t reg_address, const uint8_t* pData, uint32_t len);
int spi_master_rx(void* ctx, uint8_t reg_address, uint8_t* pData, uint32_t len);
void build_sensor_event_data(void * context, enum inv_icm20948_sensor sensortype, uint64_t timestamp, const void * data, const void *arg);


int MyTaskExecute( ICM20948* imyDevice, struct inv_icm20948 * s, void * context,
			void (*handler)(void * context, enum inv_icm20948_sensor sensor, uint64_t timestamp, const void * data, const void *arg));


#ifdef __cplusplus
}
#endif


#endif /* SRC_PROJECT_ICM20948_ICM20948HELPER_H_ */
