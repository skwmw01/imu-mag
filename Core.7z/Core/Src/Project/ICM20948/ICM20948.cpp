/*
 * ICM20948.cpp
 *
 *  Created on: Mar 15, 2024
 *      Author: Michael.Oleksy
 */

#include <iostream>
#include <sstream>
#include <iomanip>


#include "ICM20948/ICM20948.hpp"

#include "ICM20948/ICM20948Helper.h"

// Inv Sensor Drivers
#include "ICM20948/Driver/ICM20948Defs.h"
#include "ICM20948/Driver/ICM20948AuxCompassAkm.h"
#include "ICM20948/Driver/ICM20948DataConverter.h"
#include "ICM20948/Driver/ICM20948DataBaseDriver.h"
#include "ICM20948/Driver/ICM20948DataBaseControl.h"
#include "ICM20948/Driver/ICM20948MPUFifoControl.h"
#include "ICM20948/Driver/ICM20948SelfTest.h"
#include "ICM20948/Driver/SensorTypes.h"


#include "system.h"
#include "ICM20948/Driver/ICM20948.h"




// Logger
#include "Debug/DebugLog.h"
extern bool __log_enabled;



// DMP image
static const uint8_t dmp3_image[] = {
	#include "icm20948_img.dmp3a.h"
};

#ifdef __cplusplus
extern "C" {
#endif


extern int dmp_reset_fifo(struct inv_icm20948 * s);




//================================================================
// Constructor
//================================================================
ICM20948::ICM20948(const IMUPort _imuPort, UINT16 _id)
	: id{_id}
	, imuPort{_imuPort}
	, cmdState{CommandState::STATE_CMD_IDLE}
{
	cmdManager = new CmdManager();

	// We're using pointers to structures because the GCC compiler issues warnings when
	// pushing an ICM20948 object that contains a structure variable to a vector.
	// Pointers to structures don't create this warning.
	icm_device = new inv_icm20948_t;
	icm20948_serif = new inv_icm20948_serif_t;

	// Initialize the structures
	icm20948_serif->context   = (void*)&imuPort;
	icm20948_serif->read_reg  = spi_master_rx;
	icm20948_serif->write_reg = spi_master_tx;
	icm20948_serif->max_read  = 1024*16; 	/* maximum number of bytes allowed per serial read */
	icm20948_serif->max_write = 1024*16; 	/* maximum number of bytes allowed per serial write */
	icm20948_serif->is_spi = interface_is_SPI();

	icm_device->lastBank = 0x7E;
	icm_device->lLastBankSelected = 0xFF;

	processed = false;

	accel_offset_x = accel_offset_y = accel_offset_z = 0.0f;
	prev_accel_x = prev_accel_y = prev_accel_z = 0.0f;

	sample_accel = false;
	sample_count = 0;

	// Enable logging to UART
	__log_enabled = true;
}


ICM20948::~ICM20948() {
	//delete cmdManager;
}


//================================================================
// Set/Reset the Chip Select (CS) pin for this IMU
// GPIO_PIN_SET   = set CS high (inactive)
// GPIO_PIN_RESET = set CS low (active)
//================================================================
void ICM20948::setCS(GPIO_PinState GPIO_state)
{
	// Remove const-ness from the variables
	GPIO_TypeDef* port = const_cast<GPIO_TypeDef*>(imuPort.GPIO_Port);
	uint16_t* pin = const_cast<uint16_t*>(&imuPort.GPIO_Pin);

	HAL_GPIO_WritePin( port, *pin, GPIO_state);
}


void ICM20948::addCommand(Command_t cmd) {
	cmdManager->addCommand(cmd);
	cmdState = CommandState::STATE_CMD_PENDING;
}

Command_t& ICM20948::getCmd() {
	return cmdManager->getCommand();
}


Command_t& ICM20948::getNextCmd() {
	return cmdManager->getNextCommand();
}


int ICM20948::load_dmp3()
{
	int rc = 0;
	rc = inv_icm20948_load(icm_device, dmp3_image, sizeof(dmp3_image));
	return rc;
}


void ICM20948::reset_dmp()
{
	dmp_reset_fifo(icm_device);
}




UINT16 ICM20948::construct_ASCII_IMU_Data_Packet(char** buffer)
{
	UINT16 offset = 0;


	if( settings()->enable_quaternion )
	{
		std::stringstream ss{};

		// Create a JSON object
		ss << "{" << std::setprecision(6);
		ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)getID() << "\"" << std::dec << ", ";
		ss << std::quoted("quat_w") << ":" << std::to_string(quat_w) << ", ";
		ss << std::quoted("quat_x") << ":" << std::to_string(quat_x) << ", ";
		ss << std::quoted("quat_y") << ":" << std::to_string(quat_y) << ", ";
		ss << std::quoted("quat_z") << ":" << std::to_string(quat_z) << "}\r\n";

		std::string s = ss.str();
		int len = s.length();

		memcpy( *buffer, s.c_str(), len );
		offset += len;

		*buffer += len;
	}

	if( settings()->enable_accelerometer )
	{
		std::stringstream ss{};

		// Create a JSON object
		ss << "{" << std::setprecision(6);
		ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)getID() << "\"" << std::dec << ", ";
		ss << std::quoted("accel_x") << ":" << std::to_string(accel_x) << ", ";
		ss << std::quoted("accel_y") << ":" << std::to_string(accel_y) << ", ";
		ss << std::quoted("accel_z") << ":" << std::to_string(accel_z) << "}\r\n";

		std::string s = ss.str();
		int len = s.length();

		memcpy( *buffer, s.c_str(), len );
		offset += len;

		*buffer += len;
	}

	if( settings()->enable_magnetometer )
	{
		std::stringstream ss{};

		// Create a JSON object
		ss << "{" << std::setprecision(6);
		ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)getID() << "\"" << std::dec << ", ";
		ss << std::quoted("mag_x") << ":" << std::to_string(mag_x) << ", ";
		ss << std::quoted("mag_y") << ":" << std::to_string(mag_y) << ", ";
		ss << std::quoted("mag_z") << ":" << std::to_string(mag_z) << "}\r\n";

		std::string s = ss.str();
		int len = s.length();

		memcpy( *buffer, s.c_str(), len );
		offset += len;

		*buffer += len;
	}

	return offset;
}



UINT16 ICM20948::construct_BINARY_IMU_Data_Packet(char** buffer)
{
	UINT16 offset = 0;
	static UINT32 packet_counter = 0;


	// Place the IMU data into the supplied buffer
	UINT16 id = getID();

	// Start Marker
	UINT16 marker = 0xA5A5;
	memcpy( *buffer+offset, &marker, 2);
	offset += 2;

	// IMU ID
	memcpy( *buffer+offset, &id, 2);
	offset += 2;

	// Packet counter
	packet_counter++;
	memcpy( *buffer+offset, &packet_counter, sizeof(UINT32));
	offset += sizeof(UINT32);


	if( settings()->enable_quaternion )
	{
		memcpy( *buffer+offset, &quat_w, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &quat_x, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &quat_y, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &quat_z, sizeof(float) );
		offset += sizeof(float);
	}


	if( settings()->enable_accelerometer )
	{
		memcpy( *buffer+offset, &accel_x, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &accel_y, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &accel_z, sizeof(float) );
		offset += sizeof(float);
	}

	if( settings()->enable_magnetometer )
	{
		memcpy( *buffer+offset, &mag_x, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &mag_y, sizeof(float) );
		offset += sizeof(float);

		memcpy( *buffer+offset, &mag_z, sizeof(float) );
		offset += sizeof(float);
	}

	memcpy( *buffer+offset, &marker, 2);
	offset += 2;

	//*(*buffer+offset) = '\n';
	//offset++;

	*buffer += offset;

	return offset;
}



//=====================================================================
// Initialize the ICM20948 device
//=====================================================================
int ICM20948::init()
{
	int rc = 0;
	char data[100] = {0};

	sprintf(data, "IMU [%04X] START\n", getID());
	DBG_LOG_MESSAGE(data);


	// Reset icm20948 driver states
	inv_icm20948_reset_states(icm_device, icm20948_serif);
	inv_icm20948_register_aux_compass(icm_device, INV_ICM20948_COMPASS_ID_AK09916, AK0991x_DEFAULT_I2C_ADDR);

	// Setup Serial
	inv_icm20948_set_serial_comm(icm_device, SMARTSENSOR_SERIAL_INTERFACE::SERIAL_INTERFACE_SPI);

	__log_enabled = false;

	// Setup the icm20948 device
	rc = icm20948_sensor_setup();

	// Self-test
	if (icm_device->selftest_done && !icm_device->offset_done)
	{
		// If we've run self test and not already set the offset.
	    inv_icm20948_set_offset(icm_device, unscaled_bias);
	    icm_device->offset_done = 1;
	}


	// Now that Icm20948 device is initialized, we can proceed with DMP image loading
	// This step is mandatory as DMP image is not stored in non volatile memory
	rc |= load_dmp3();
	if( rc ) {
		DBG_LOG_MESSAGE("// Error loading DMP...\r\n");
		return rc;
	}

	// The "sensor_setup" code above puts the sensor into low-power mode
	// We want it to be high-performance instead.
	inv_icm20948_set_lowpower_or_highperformance(icm_device, icm_settings.mode);

	// Set frequency
	rc = inv_icm20948_set_sensor_period(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_GAME_ROTATION_VECTOR), 1000 / icm_settings.quaternion_frequency);
	rc = inv_icm20948_set_sensor_period(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_GYROSCOPE), 1000 / icm_settings.gyroscope_frequency);
	rc = inv_icm20948_set_sensor_period(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_ACCELEROMETER), 1000 / icm_settings.accelerometer_frequency);
	rc = inv_icm20948_set_sensor_period(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_MAGNETOMETER), 1000 / icm_settings.magnetometer_frequency);

	// Enable / disable
	rc = inv_icm20948_enable_sensor(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_GYROSCOPE), icm_settings.enable_gyroscope);
	rc = inv_icm20948_enable_sensor(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_ACCELEROMETER), icm_settings.enable_accelerometer);
	rc = inv_icm20948_enable_sensor(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_GAME_ROTATION_VECTOR), icm_settings.enable_quaternion);
	rc = inv_icm20948_enable_sensor(icm_device, idd_sensortype_conversion(INV_SENSOR_TYPE_MAGNETOMETER), icm_settings.enable_magnetometer);

	/* we should be good to go ! */
	sprintf(data, "IMU [%04X] SETUP COMPLETE\n", getID());
	DBG_LOG_MESSAGE(data);

	return rc;
}




int ICM20948::icm20948_sensor_setup()
{
	int rc;
	char data[50] = {0};

	uint8_t whoami = 0xff;
	uint8_t i;



	inv_icm20948_soft_reset(icm_device);

	// Issue WHO_AM_I - respond with 0xEA
	rc = inv_icm20948_get_whoami(icm_device, &whoami);

	// Check if WHOAMI value corresponds to any value from EXPECTED_WHOAMI array
	for( i = 0; i < (sizeof(EXPECTED_WHOAMI) / sizeof(EXPECTED_WHOAMI[0])) ; ++i)
	{
		if (whoami == EXPECTED_WHOAMI[i])
	      break;
	}

	if( i == (sizeof(EXPECTED_WHOAMI) / sizeof(EXPECTED_WHOAMI[0])) )
	{
		sprintf(data, "WHOAMI = %i", whoami);

		DBG_LOG_MESSAGE("// Bad WHOAMI value\r\n");
		DBG_LOG_MESSAGE(data);

	    return rc;
	}

	//sprintf(data, "WHOAMI = %i", whoami);
	//DBG_LOG_MESSAGE(data);

	// Setup Accelerometer and Gyroscope mounting matrix and associated angle for current board
	inv_icm20948_init_matrix(icm_device);

	// Initialize Sensor Low-level settings
	rc = inv_icm20948_initialize(icm_device, dmp3_image, sizeof(dmp3_image));
	if (rc != 0)
	{
		DBG_LOG_MESSAGE("// ICM20948 Initialization failed.\r\n");
		return rc;
	}

	// Configure and initialize the ICM20948 for normal use

	// Initialize auxiliary sensors
	//DBG_LOG_MESSAGE("//===== AUX COMPASS ======");
	inv_icm20948_register_aux_compass( icm_device, INV_ICM20948_COMPASS_ID_AK09916, AK0991x_DEFAULT_I2C_ADDR);

	//DBG_LOG_MESSAGE("//===== INITIALISE AUXILARY ======");
	rc = inv_icm20948_initialize_auxiliary(icm_device);
	if (rc == -1) {
		DBG_LOG_MESSAGE("// Compass not detected...\r\n");
	}

	//DBG_LOG_MESSAGE("//===== APPLY MOUNTING MATRIX ======");
	icm20948_apply_mounting_matrix();

	//DBG_LOG_MESSAGE("//===== SET FSR ======");
	icm20948_set_fsr();

	/* re-initialize base state structure */
	inv_icm20948_init_structure(icm_device);

	return 0;
}


void ICM20948::icm20948_apply_mounting_matrix(void)
{
	int ii;


	for (ii = 0; ii < INV_ICM20948_SENSOR_MAX; ii++)
	{
		char msg[30] = {0};
		sprintf(msg, "// SET MATRIX - iteration: %i", ii);
		//DBG_LOG_MESSAGE(msg);

		inv_icm20948_set_matrix(icm_device, cfg_mounting_matrix, (enum inv_icm20948_sensor)ii);
	}
}

void ICM20948::icm20948_set_fsr(void)
{
	inv_icm20948_set_fsr(icm_device, INV_ICM20948_SENSOR_RAW_ACCELEROMETER, (const void *)&cfg_acc_fsr);
	inv_icm20948_set_fsr(icm_device, INV_ICM20948_SENSOR_ACCELEROMETER, (const void *)&cfg_acc_fsr);
	inv_icm20948_set_fsr(icm_device, INV_ICM20948_SENSOR_RAW_GYROSCOPE, (const void *)&cfg_gyr_fsr);
	inv_icm20948_set_fsr(icm_device, INV_ICM20948_SENSOR_GYROSCOPE, (const void *)&cfg_gyr_fsr);
	inv_icm20948_set_fsr(icm_device, INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED, (const void *)&cfg_gyr_fsr);
}


void ICM20948::GetOrientationQuat(uint8_t* data)
{
	// Set the bitmap indicating we've received data from the IMU



	//signed long  long_quat[3] = {0};    // Changed by M.O.
	uint16_t header;
	signed long  long_quat[4] = {0};
	float grv_float[4];
	long quat[3];

	/* Read 6 axis quaternion out of DMP FIFO in Q30 */
	//inv_icm20948_dmp_get_6quaternion(long_quat);

	/* and convert it from Q30 DMP format to Android format only if GRV sensor is enabled */
	//inv_icm20948_t* icm_device;
	memcpy( &header, (data+0), 2);
	memcpy( &long_quat[0], (data+2), 4);
	memcpy( &long_quat[1], (data+6), 4);
	memcpy( &long_quat[2], (data+10), 4);

	inv_decode_3_32bit_elements(&quat[0], (const unsigned char*)long_quat);

	inv_icm20948_convert_rotation_vector(icm_device, quat, grv_float);
	quat_w = grv_float[3];
	quat_x = grv_float[0];
	quat_y = grv_float[1];
	quat_z = grv_float[2];

	//s->timestamp[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR] += s->sensorlist[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR].odr_applied_us;
	//handler(context, INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR, s->timestamp[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR], ref_quat, 0);
	quat_data_ready = true;

	// Using C++ std::string to create object
	//DBG_QUATERNION_TO_JS_OBJECT(quat_w, quat_x, quat_y, quat_z, id );
	//DBG_QUATERNION_TO_FLOATS(quat_w, quat_x, quat_y, quat_z, id );
}


void ICM20948::task()
{
	__log_enabled = true;

	inv_icm20948_poll_sensor(icm_device, this, build_sensor_event_data);
}


void ICM20948::gatherAccelSamples()
{
	if( !sample_accel )
		return;

	if( !accel_data_ready )
		return;

	accel_offset_x += accel_x;
	accel_offset_y += accel_y;
	accel_offset_z += accel_z;

	sample_count++;

	if( sample_count == 100 )
	{
		accel_offset_x /= (float)sample_count;
		accel_offset_y /= (float)sample_count;
		accel_offset_z /= (float)sample_count;

	    pos_x = 0;
	    pos_y = 0;
	    pos_z = 0;

		sample_accel = false;
	}

	prev_accel_x = accel_x;
	prev_accel_y = accel_y;
	prev_accel_z = accel_z - gravity;
}

void ICM20948::applyAccelOffset()
{
//	accel_z -= gravity;
//	prev_accel_z -= gravity;
//
//	accel_x = accel_x - prev_accel_x; //- accel_offset_x;
//	accel_y = accel_y - prev_accel_y; //accel_offset_y;
//	accel_z = accel_z - prev_accel_z; //accel_offset_z;

	pos_x = accel_x + accel_offset_x;
	pos_y = accel_y - accel_offset_y;
	pos_z = accel_z - accel_offset_z;


	pos_x = accel_x;
	pos_y = accel_y;
	pos_z = accel_z;


}



void ICM20948::readGyroData(float *x, float *y, float *z)
{
	*x = gyro_x;
	*y = gyro_y;
	*z = gyro_z;
	gyro_data_ready = false;
}

void ICM20948::readAccelData(float *x, float *y, float *z)
{
	*x = accel_x;
	*y = accel_y;
	*z = accel_z;
	accel_data_ready = false;
}

void ICM20948::readMagData(float *x, float *y, float *z)
{
	*x = mag_x;
	*y = mag_y;
	*z = mag_z;
	mag_data_ready = false;
}

void ICM20948::readQuatData(float *w, float *x, float *y, float *z)
{
	*w = quat_w;
	*x = quat_x;
	*y = quat_y;
	*z = quat_z;
	quat_data_ready = false;
}



#ifdef __cplusplus
}
#endif



////========================================================
//// Calculates the IMU Temperature
//// Values taken from data sheet
////========================================================
//float ICM20948::CalculateTemperature(UINT16 sensorValue)
//{
//	const float TempSensitivity = 333.87f;
//	const float RoomTempOffset = 21.0f;
//
//	float tempInC = ((sensorValue - RoomTempOffset) / TempSensitivity) + 21.0f;
//
//	return tempInC;
//}
//
