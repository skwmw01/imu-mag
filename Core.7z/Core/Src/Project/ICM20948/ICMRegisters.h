/*
 * ICMConst.h
 *
 *  Created on: Mar 20, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_ICM20948_ICMREGISTERS_H_
#define SRC_PROJECT_ICM20948_ICMREGISTERS_H_

//
//#ifndef __cplusplus
//	#define max(a,b) (((a) > (b)) ? (a) : (b))
//	#define min(a,b) (((a) < (b)) ? (a) : (b))
//#endif
//



#define MIN_MST_ODR_CONFIG       4
#define THREE_AXES               3
#define NINE_ELEM                (THREE_AXES * THREE_AXES)
#define MPU_TEMP_SHIFT           16
#define SOFT_IRON_MATRIX_SIZE    (4 * 9)
#define DMP_DIVIDER              (BASE_SAMPLE_RATE / MPU_DEFAULT_DMP_FREQ)
#define MAX_5_BIT_VALUE          0x1F
#define BAD_COMPASS_DATA         0x7FFF
#define DEFAULT_BATCH_RATE       400
#define DEFAULT_BATCH_TIME    (MSEC_PER_SEC / DEFAULT_BATCH_RATE)
#define MAX_COMPASS_RATE         115
#define MAX_PRESSURE_RATE        30
#define MAX_ALS_RATE             5
#define DATA_AKM_99_BYTES_DMP  10
#define DATA_AKM_89_BYTES_DMP  9
#define DATA_ALS_BYTES_DMP     8
#define APDS9900_AILTL_REG      0x04
#define BMP280_DIG_T1_LSB_REG                0x88
#define COVARIANCE_SIZE          14
#define ACCEL_COVARIANCE_SIZE  (COVARIANCE_SIZE * sizeof(int))
#define COMPASS_COVARIANCE_SIZE  (COVARIANCE_SIZE * sizeof(int))
#define TEMPERATURE_SCALE  3340827L
#define TEMPERATURE_OFFSET 1376256L
#define SECONDARY_INIT_WAIT 60
#define MPU_SOFT_UPDT_ADDR               0x86
#define MPU_SOFT_UPTD_MASK               0x0F
#define AK99XX_SHIFT                    23
#define AK89XX_SHIFT                    22
#define OPERATE_GYRO_IN_DUTY_CYCLED_MODE       (1<<4)
#define OPERATE_ACCEL_IN_DUTY_CYCLED_MODE      (1<<5)
#define OPERATE_I2C_MASTER_IN_DUTY_CYCLED_MODE (1<<6)




#define READ_BIT_MASK			0x80
#define WRITE_BIT_MASK			0x7F

/** @brief Max size that can be read across I2C or SPI data lines */
#define INV_MAX_SERIAL_READ 16
/** @brief Max size that can be written across I2C or SPI data lines */
#define INV_MAX_SERIAL_WRITE 16

//enum SMARTSENSOR_SERIAL_INTERFACE {
//    SERIAL_INTERFACE_I2C = 1,
//    SERIAL_INTERFACE_SPI,
//    SERIAL_INTERFACE_INVALID
//};

#define DMP_LOAD_START 		0x90

#define CHIP_AWAKE          (0x01)
#define CHIP_LP_ENABLE      (0x02)

enum AccelRange
{
	ACCEL_RANGE_2G,
	ACCEL_RANGE_4G,
	ACCEL_RANGE_8G,
	ACCEL_RANGE_16G
};

enum AccelDlpfBandwidth
{
	ACCEL_DLPF_BANDWIDTH_1209HZ,
	ACCEL_DLPF_BANDWIDTH_246HZ,
	ACCEL_DLPF_BANDWIDTH_111HZ,
	ACCEL_DLPF_BANDWIDTH_50HZ,
	ACCEL_DLPF_BANDWIDTH_24HZ,
	ACCEL_DLPF_BANDWIDTH_12HZ,
	ACCEL_DLPF_BANDWIDTH_6HZ,
	ACCEL_DLPF_BANDWIDTH_473HZ
};

enum GyroRange
{
	GYRO_RANGE_250DPS,
	GYRO_RANGE_500DPS,
	GYRO_RANGE_1000DPS,
	GYRO_RANGE_2000DPS
};

// Gyro Low-Pass-Filter config
enum GyroDLPFBandwidth
{
	GYRO_DLPF_BANDWIDTH_12106HZ,
	GYRO_DLPF_BANDWIDTH_197HZ,
	GYRO_DLPF_BANDWIDTH_152HZ,
	GYRO_DLPF_BANDWIDTH_120HZ,
	GYRO_DLPF_BANDWIDTH_51HZ,
	GYRO_DLPF_BANDWIDTH_24HZ,
	GYRO_DLPF_BANDWIDTH_12HZ,
	GYRO_DLPF_BANDWIDTH_6HZ,
	GYRO_DLPF_BANDWIDTH_361HZ
};

enum LpAccelOdr
{
	LP_ACCEL_ODR_0_24HZ = 0,
	LP_ACCEL_ODR_0_49HZ = 1,
	LP_ACCEL_ODR_0_98HZ = 2,
	LP_ACCEL_ODR_1_95HZ = 3,
	LP_ACCEL_ODR_3_91HZ = 4,
	LP_ACCEL_ODR_7_81HZ = 5,
	LP_ACCEL_ODR_15_63HZ = 6,
	LP_ACCEL_ODR_31_25HZ = 7,
	LP_ACCEL_ODR_62_50HZ = 8,
	LP_ACCEL_ODR_125HZ = 9,
	LP_ACCEL_ODR_250HZ = 10,
	LP_ACCEL_ODR_500HZ = 11
};

enum UserBank
{
	USER_BANK_0 = 0x00,
	USER_BANK_1 = 0x10,
	USER_BANK_2 = 0x20,
	USER_BANK_3 = 0x30,
};


// Constants
#define	Gravity			9.807f;
#define	degToRad		3.14159265359f/180.0f

#define	accRawScaling	32767.5f		// =(2^16-1)/2 16 bit representation of acc value to cover +/- range
#define	gyroRawScaling	32767.5f		// =(2^16-1)/2 16 bit representation of gyro value to cover +/- range
#define	magRawScaling	32767.5f		// =(2^16-1)/2 16 bit representation of gyro value to cover +/- range

#define	_magScale		4912.0f / magRawScaling 	// micro Tesla, measurement range is +/- 4912 uT.

// ICM20948 constants
#define	ICM20948_WHO_AM_I	0xEA
#define	ICM20948_READ_OP	0x80		// Bit 7 set
#define	ICM20948_WRITE_OP	0x00		// Bit 7 clear

#define BANK_0                  (0 << 7)
#define BANK_1                  (1 << 7)
#define BANK_2                  (2 << 7)
#define BANK_3                  (3 << 7)


// compass chip list
#define HW_AK8963 0x20
#define HW_AK8975 0x21
#define HW_AK8972 0x22
#define HW_AK09911 0x23
#define HW_AK09912 0x24
#define HW_AK09916 0x25

#define HW_ICM20648 0x01
#define HW_ICM20948 0x02

#define USE_ICM20948 1

#if defined USE_ICM20648
#define MEMS_CHIP  HW_ICM20648
#endif

#if defined USE_ICM20948
#define MEMS_CHIP  HW_ICM20948
#endif

#if !defined(MEMS_CHIP)
    #error "MEMS_CHIP is not defined"
#elif MEMS_CHIP != HW_ICM20648 \
        && MEMS_CHIP != HW_ICM20948
    #error "Unknown value for MEMS_CHIP"
#endif

#define DMP_LOAD_START 0x90

#define MPU_SUCCESS (0)
#define MPU_COMPASS_NOT_FOUND (int)0x00ABCDEF

#define MSEC_PER_SEC 1000
#define NSEC_PER_MSEC 1000000
#define NSEC_PER_SEC NSEC_PER_MSEC * MSEC_PER_SEC

#define FIFO_DIVIDER 19

#define REG_BANK_0 0x00
#define REG_BANK_1 0x01

#define DIAMOND_I2C_ADDRESS     0x68
#define BANK_0                  (0 << 7)
#define BANK_1                  (1 << 7)
#define BANK_2                  (2 << 7)
#define BANK_3                  (3 << 7)

/*register and associated bit definition*/
/* bank 0 register map */
#define REG_USER_CTRL           (BANK_0 | 0x03)
#define BIT_DMP_EN                      0x80
#define BIT_FIFO_EN                     0x40
#define BIT_I2C_MST_EN                  0x20
#define BIT_I2C_IF_DIS                  0x10
#define BIT_DMP_RST                     0x08
#define BIT_DIAMOND_DMP_RST			    0x04

#define REG_LP_CONFIG           (BANK_0 | 0x05)
#define BIT_I2C_MST_CYCLE               0x40
#define BIT_ACCEL_CYCLE                 0x20
#define BIT_GYRO_CYCLE                  0x10

#define REG_PWR_MGMT_2          (BANK_0 | 0x07)
#define BIT_PWR_PRESSURE_STBY           0x40
#define BIT_PWR_ACCEL_STBY              0x38
#define BIT_PWR_GYRO_STBY               0x07
#define BIT_PWR_ALL_OFF                 0x7f

#define REG_INT_PIN_CFG         (BANK_0 | 0x0F)
#define BIT_INT_LATCH_EN                0x20
#define BIT_BYPASS_EN                   0x02

#define REG_INT_ENABLE          (BANK_0 | 0x10)
#define BIT_DMP_INT_EN                  0x02

#define REG_INT_ENABLE_1        (BANK_0 | 0x11)
#define BIT_DATA_RDY_3_EN               0x08
#define BIT_DATA_RDY_2_EN               0x04
#define BIT_DATA_RDY_1_EN               0x02
#define BIT_DATA_RDY_0_EN               0x01

#define REG_INT_ENABLE_2        (BANK_0 | 0x12)
#define BIT_FIFO_OVERFLOW_EN_0          0x1

#define REG_INT_ENABLE_3        (BANK_0 | 0x13)

#define REG_DMP_INT_STATUS      (BANK_0 | 0x18)
#define BIT_WAKE_ON_MOTION_INT          0x08
#define BIT_MSG_DMP_INT                 0x0002
#define BIT_MSG_DMP_INT_0               0x0100  // CI Command

#define BIT_MSG_DMP_INT_2               0x0200  // CIM Command - SMD
#define BIT_MSG_DMP_INT_3               0x0400  // CIM Command - Pedometer

#define BIT_MSG_DMP_INT_4               0x1000  // CIM Command - Pedometer binning
#define BIT_MSG_DMP_INT_5               0x2000  // CIM Command - Bring To See Gesture
#define BIT_MSG_DMP_INT_6               0x4000  // CIM Command - Look To See Gesture

#define REG_INT_STATUS          (BANK_0 | 0x19)
#define BIT_DMP_INT                     0x02

#define REG_INT_STATUS_1        (BANK_0 | 0x1A)
#define REG_INT_STATUS_2        (BANK_0 | 0x1B)

#define REG_SINGLE_FIFO_PRIORITY_SEL        (BANK_0 | 0x26)

#define REG_GYRO_XOUT_H_SH      (BANK_0 | 0x33)

#define REG_TEMPERATURE         (BANK_0 | 0x39)
#define REG_TEMP_CONFIG         (BANK_0 | 0x53)

#define REG_EXT_SLV_SENS_DATA_00 (BANK_0 | 0x3B)
#define REG_EXT_SLV_SENS_DATA_08 (BANK_0 | 0x43)
#define REG_EXT_SLV_SENS_DATA_09 (BANK_0 | 0x44)
#define REG_EXT_SLV_SENS_DATA_10 (BANK_0 | 0x45)

#define REG_FIFO_EN             (BANK_0 | 0x66)
#define BIT_SLV_0_FIFO_EN               0x01

#define REG_FIFO_EN_2           (BANK_0 | 0x67)
#define BIT_PRS_FIFO_EN                 0x20
#define BIT_ACCEL_FIFO_EN               0x10
#define BITS_GYRO_FIFO_EN               0x0E

#define REG_FIFO_RST            (BANK_0 | 0x68)

#define REG_FIFO_COUNT_H        (BANK_0 | 0x70)
#define REG_FIFO_COUNT_L        (BANK_0 | 0x71)
#define REG_FIFO_R_W            (BANK_0 | 0x72)

#define REG_HW_FIX_DISABLE      (BANK_0 | 0x75)

#define REG_FIFO_CFG            (BANK_0 | 0x76)
#define BIT_MULTI_FIFO_CFG              0x01
#define BIT_SINGLE_FIFO_CFG             0x00

#define REG_ACCEL_XOUT_H_SH     (BANK_0 | 0x2D)
#define REG_ACCEL_XOUT_L_SH     (BANK_0 | 0x2E)
#define REG_ACCEL_YOUT_H_SH     (BANK_0 | 0x2F)
#define REG_ACCEL_YOUT_L_SH     (BANK_0 | 0x30)
#define REG_ACCEL_ZOUT_H_SH     (BANK_0 | 0x31)
#define REG_ACCEL_ZOUT_L_SH     (BANK_0 | 0x32)

#define REG_MEM_START_ADDR      (BANK_0 | 0x7C)
#define REG_MEM_R_W             (BANK_0 | 0x7D)
#define REG_MEM_BANK_SEL        (BANK_0 | 0x7E)

/* bank 1 register map */
#define REG_TIMEBASE_CORRECTION_PLL   (BANK_1 | 0x28)
#define REG_TIMEBASE_CORRECTION_RCOSC (BANK_1 | 0x29)
#define REG_SELF_TEST1                (BANK_1 | 0x02)
#define REG_SELF_TEST2                (BANK_1 | 0x03)
#define REG_SELF_TEST3                (BANK_1 | 0x04)
#define REG_SELF_TEST4                (BANK_1 | 0x0E)
#define REG_SELF_TEST5                (BANK_1 | 0x0F)
#define REG_SELF_TEST6                (BANK_1 | 0x10)

#define REG_XA_OFFS_H                 (BANK_1 | 0x14)
#define REG_XA_OFFS_L                 (BANK_1 | 0x15)
#define REG_YA_OFFS_H                 (BANK_1 | 0x17)
#define REG_YA_OFFS_L                 (BANK_1 | 0x18)
#define REG_ZA_OFFS_H                 (BANK_1 | 0x1A)
#define REG_ZA_OFFS_L                 (BANK_1 | 0x1B)

/* bank 2 register map */
#define REG_GYRO_SMPLRT_DIV     (BANK_2 | 0x00)

#define REG_GYRO_CONFIG_1       (BANK_2 | 0x01)
#define SHIFT_GYRO_FS_SEL               1
#define SHIFT_GYRO_DLPCFG               3

#define REG_GYRO_CONFIG_2       (BANK_2 | 0x02)
#define BIT_GYRO_CTEN                   0x38

#define REG_XG_OFFS_USRH        (BANK_2 | 0x03)
#define REG_XG_OFFS_USRL        (BANK_2 | 0x04)
#define REG_YG_OFFS_USRH        (BANK_2 | 0x05)
#define REG_YG_OFFS_USRL        (BANK_2 | 0x06)
#define REG_ZG_OFFS_USRH        (BANK_2 | 0x07)
#define REG_ZG_OFFS_USRL        (BANK_2 | 0x08)

#define REG_ACCEL_SMPLRT_DIV_1  (BANK_2 | 0x10)
#define REG_ACCEL_SMPLRT_DIV_2  (BANK_2 | 0x11)

#define REG_ACCEL_CONFIG        (BANK_2 | 0x14)
#define SHIFT_ACCEL_FS                  1

#define REG_ACCEL_CONFIG_2      (BANK_2 | 0x15)
#define BIT_ACCEL_CTEN                  0x1C

#define REG_PRS_ODR_CONFIG      (BANK_2 | 0x20)
#define REG_PRGM_START_ADDRH    (BANK_2 | 0x50)

#define REG_MOD_CTRL_USR        (BANK_2 | 0x54)
#define BIT_ODR_SYNC                    0x7

/* bank 3 register map */
#define REG_I2C_MST_ODR_CONFIG  (BANK_3 | 0x0)

#define REG_I2C_MST_CTRL        (BANK_3 | 0x01)
#define BIT_I2C_MST_P_NSR               0x10

#define REG_I2C_MST_DELAY_CTRL  (BANK_3 | 0x02)
#define BIT_SLV0_DLY_EN                 0x01
#define BIT_SLV1_DLY_EN                 0x02
#define BIT_SLV2_DLY_EN                 0x04
#define BIT_SLV3_DLY_EN                 0x08

#define REG_I2C_SLV0_ADDR       (BANK_3 | 0x03)
#define REG_I2C_SLV0_REG        (BANK_3 | 0x04)
#define REG_I2C_SLV0_CTRL       (BANK_3 | 0x05)
#define REG_I2C_SLV0_DO         (BANK_3 | 0x06)

#define REG_I2C_SLV1_ADDR       (BANK_3 | 0x07)
#define REG_I2C_SLV1_REG        (BANK_3 | 0x08)
#define REG_I2C_SLV1_CTRL       (BANK_3 | 0x09)
#define REG_I2C_SLV1_DO         (BANK_3 | 0x0A)

#define REG_I2C_SLV2_ADDR       (BANK_3 | 0x0B)
#define REG_I2C_SLV2_REG        (BANK_3 | 0x0C)
#define REG_I2C_SLV2_CTRL       (BANK_3 | 0x0D)
#define REG_I2C_SLV2_DO         (BANK_3 | 0x0E)

#define REG_I2C_SLV3_ADDR       (BANK_3 | 0x0F)
#define REG_I2C_SLV3_REG        (BANK_3 | 0x10)
#define REG_I2C_SLV3_CTRL       (BANK_3 | 0x11)
#define REG_I2C_SLV3_DO         (BANK_3 | 0x12)

#define REG_I2C_SLV4_CTRL       (BANK_3 | 0x15)

#define INV_MPU_BIT_SLV_EN      0x80
#define INV_MPU_BIT_BYTE_SW     0x40
#define INV_MPU_BIT_REG_DIS     0x20
#define INV_MPU_BIT_GRP         0x10
#define INV_MPU_BIT_I2C_READ    0x80

/* register for all banks */
#define REG_BANK_SEL            0x7F

    /* data definitions */
#define BYTES_PER_SENSOR         6
#define FIFO_COUNT_BYTE          2
#define HARDWARE_FIFO_SIZE       1024

#define FIFO_SIZE                (HARDWARE_FIFO_SIZE * 7 / 8)
#define POWER_UP_TIME            100
#define REG_UP_TIME_USEC         100
#define DMP_RESET_TIME           20
#define GYRO_ENGINE_UP_TIME      50
#define MPU_MEM_BANK_SIZE        256
#define IIO_BUFFER_BYTES         8
#define HEADERED_NORMAL_BYTES    8
#define HEADERED_Q_BYTES         16
#define LEFT_OVER_BYTES          128
#define BASE_SAMPLE_RATE         1125

#ifdef FREQ_225
#define MPU_DEFAULT_DMP_FREQ     225
#define PEDOMETER_FREQ           (MPU_DEFAULT_DMP_FREQ >> 2)
#define DEFAULT_ACCEL_GAIN       (33554432L * 5 / 11)
#else
#define MPU_DEFAULT_DMP_FREQ     102
#define PEDOMETER_FREQ           (MPU_DEFAULT_DMP_FREQ >> 1)
#define DEFAULT_ACCEL_GAIN       33554432L
#endif
#define PED_ACCEL_GAIN           67108864L
#define ALPHA_FILL_PED           858993459
#define A_FILL_PED               214748365

#define MIN_MST_ODR_CONFIG       4
#define THREE_AXES               3
#define NINE_ELEM                (THREE_AXES * THREE_AXES)
#define MPU_TEMP_SHIFT           16
#define SOFT_IRON_MATRIX_SIZE    (4 * 9)
#define DMP_DIVIDER              (BASE_SAMPLE_RATE / MPU_DEFAULT_DMP_FREQ)
#define MAX_5_BIT_VALUE          0x1F
#define BAD_COMPASS_DATA         0x7FFF
#define DEFAULT_BATCH_RATE       400
#define DEFAULT_BATCH_TIME    (MSEC_PER_SEC / DEFAULT_BATCH_RATE)
#define MAX_COMPASS_RATE         115
#define MAX_PRESSURE_RATE        30
#define MAX_ALS_RATE             5
#define DATA_AKM_99_BYTES_DMP  10
#define DATA_AKM_89_BYTES_DMP  9
#define DATA_ALS_BYTES_DMP     8
#define APDS9900_AILTL_REG      0x04
#define BMP280_DIG_T1_LSB_REG                0x88
#define COVARIANCE_SIZE          14
#define ACCEL_COVARIANCE_SIZE  (COVARIANCE_SIZE * sizeof(int))
#define COMPASS_COVARIANCE_SIZE  (COVARIANCE_SIZE * sizeof(int))
#define TEMPERATURE_SCALE  3340827L
#define TEMPERATURE_OFFSET 1376256L
#define SECONDARY_INIT_WAIT 60
#define MPU_SOFT_UPDT_ADDR               0x86
#define MPU_SOFT_UPTD_MASK               0x0F
#define AK99XX_SHIFT                    23
#define AK89XX_SHIFT                    22
#define OPERATE_GYRO_IN_DUTY_CYCLED_MODE       (1<<4)
#define OPERATE_ACCEL_IN_DUTY_CYCLED_MODE      (1<<5)
#define OPERATE_I2C_MASTER_IN_DUTY_CYCLED_MODE (1<<6)

/* this is derived from 1000 divided by 55, which is the pedometer
   running frequency */
#define MS_PER_PED_TICKS         18

/* data limit definitions */
#define MIN_FIFO_RATE            4
#define MAX_FIFO_RATE            MPU_DEFAULT_DMP_FREQ
#define MAX_DMP_OUTPUT_RATE      MPU_DEFAULT_DMP_FREQ
#define MAX_READ_SIZE            128
#define MAX_MPU_MEM              8192
#define MAX_PRS_RATE             281

/* data header defines */
#define PRESSURE_HDR             0x8000
#define ACCEL_HDR                0x4000
#define ACCEL_ACCURACY_HDR       0x4080
#define GYRO_HDR                 0x2000
#define GYRO_ACCURACY_HDR        0x2080
#define COMPASS_HDR              0x1000
#define COMPASS_HDR_2            0x1800
#define CPASS_ACCURACY_HDR       0x1080
#define ALS_HDR                  0x0800
#define SIXQUAT_HDR              0x0400
#define PEDQUAT_HDR              0x0200
#define STEP_DETECTOR_HDR        0x0100

#define COMPASS_CALIB_HDR        0x0080
#define GYRO_CALIB_HDR           0x0040
#define EMPTY_MARKER             0x0020
#define END_MARKER               0x0010
#define NINEQUAT_HDR             0x0008
#define LPQ_HDR                  0x0004

#define STEP_INDICATOR_MASK      0x000f

/* init parameters */
#define MPU_INIT_SMD_THLD        1500
#define MPU_INIT_SENSOR_RATE     5
#define MPU_INIT_GYRO_SCALE      3
#define MPU_INIT_ACCEL_SCALE     0
#define MPU_INIT_PED_INT_THRESH  2
#define MPU_INIT_PED_STEP_THRESH 6
#define COMPASS_SLAVEADDR_AKM_BASE      0x0C
#define COMPASS_SLAVEADDR_AKM           0x0E

#define BIT(x) ( 1 << x )

//#define ENABLE  1
//#define DISABLE 0

// interrupt configurations related to HW register
#define FSYNC_INT   BIT(7)
#define MOTION_INT  BIT(3)
#define PLL_INT     BIT(2)
#define DMP_INT     BIT(1)
#define I2C_INT     BIT(0)

#define CHIP_AWAKE          (0x01)
#define CHIP_LP_ENABLE      (0x02)

//ACC_REQUESTED_FREQ
#define DMP_ALGO_FREQ_56 56
#define DMP_ALGO_FREQ_112 112
#define DMP_ALGO_FREQ_225 225
#define DMP_ALGO_FREQ_450 450
#define DMP_ALGO_FREQ_900 900







// ICM20948 registers
//====================================================
// USER BANK 0
//====================================================
#define REG_WHO_AM_I            (BANK_0 | 0x00)
#define REG_LPF                 (BANK_0 | 0x01)

#define	UB0_WHO_AM_I 						0x00

#define REG_USER_CTRL           (BANK_0 | 0x03)
#define BIT_DMP_EN                      0x80
#define BIT_FIFO_EN                     0x40
#define BIT_I2C_MST_EN                  0x20
#define BIT_I2C_IF_DIS                  0x10
#define BIT_DMP_RST                     0x08
#define BIT_DIAMOND_DMP_RST			    0x04


#define	UB0_USER_CTRL						0x03
#define	UB0_USER_CTRL_DMP_EN				0x80
#define	UB0_USER_CTRL_FIFO_EN				0x40
#define	UB0_USER_CTRL_I2C_MST_EN			0x20
#define	UB0_USER_CTRL_SPI_EN				0x10
#define	UB0_USER_CTRL_DMP_RST				0x08

#define REG_LP_CONFIG           (BANK_0 | 0x05)
#define BIT_I2C_MST_CYCLE               0x40
#define BIT_ACCEL_CYCLE                 0x20
#define BIT_GYRO_CYCLE                  0x10

#define REG_LP_CONFIG           	(BANK_0 | 0x05)
#define	UB0_LP_CONFIG 						0x05
#define	UB0_LP_CONFIG_ACCL_CYCLE			0x20
#define	UB0_LP_CONFIG_GYRO_CYCLE			0x10

#define	UB0_PWR_MGMNT_1						0x06
#define	UB0_PWR_MGMNT_1_DEV_RESET			0x80
#define	UB0_PWR_MGMNT_1_WAKE_UP				0x00
#define	UB0_PWR_MGMNT_1_CLOCK_SEL_AUTO		0x01

#define	UB0_PWR_MGMNT_2						0x07
#define	UB0_PWR_MGMNT_2_DISABLE_ACCEL		0x38
#define	UB0_PWR_MGMNT_2_DISABLE_GYRO		0x07


#define	UB0_INT_PIN_CFG						0x0F
#define	UB0_INT_PIN_CFG_HIGH_50US			0x00

#define	UB0_INT_ENABLE_1					0x11
#define	UB0_INT_ENABLE_1_RAW_RDY_EN			0x01
#define	UB0_INT_ENABLE_1_DIS				0x00


#define REG_FIFO_EN             (BANK_0 | 0x66)
#define BIT_SLV_0_FIFO_EN               0x01

#define REG_FIFO_EN_2           (BANK_0 | 0x67)
#define BIT_PRS_FIFO_EN                 0x20
#define BIT_ACCEL_FIFO_EN               0x10
#define BITS_GYRO_FIFO_EN               0x0E
#define BIT_TEMP_FIFO_EN               	0x01

#define	UB0_FIFO_ENABLE_2					0x67
#define	UB0_FIFO_ENABLE_2_ACCEL_FIFO_EN		0x10
#define	UB0_FIFO_ENABLE_2_GYRO_Z_FIFO_EN	0x08
#define	UB0_FIFO_ENABLE_2_GYRO_Y_FIFO_EN	0x04
#define	UB0_FIFO_ENABLE_2_GYRO_X_FIFO_EN	0x02
//
#define	UB0_FIFO_ENABLE_2_TEMP_FIFO_EN		0x01



// Select User Bank
#define	REG_BANK_SEL		0x7F

//#define REG_MEM_START_ADDR      			0x7C
//#define REG_MEM_R_W             			0x7D
//#define REG_MEM_BANK_SEL        			0x7E

#define REG_MEM_START_ADDR      (BANK_0 | 0x7C)
#define REG_MEM_R_W             (BANK_0 | 0x7D)
#define REG_MEM_BANK_SEL        (BANK_0 | 0x7E)


#define REG_INT_STATUS          (BANK_0 | 0x19)
#define BIT_DMP_INT                     0x02

#define REG_INT_STATUS_1        (BANK_0 | 0x1A)
#define REG_INT_STATUS_2        (BANK_0 | 0x1B)


#define REG_SINGLE_FIFO_PRIORITY_SEL        (BANK_0 | 0x26)



#define REG_GYRO_XOUT_H_SH      (BANK_0 | 0x33)

#define REG_TEMPERATURE         (BANK_0 | 0x39)
#define REG_TEMP_CONFIG         (BANK_0 | 0x53)

#define REG_EXT_SLV_SENS_DATA_00 (BANK_0 | 0x3B)
#define REG_EXT_SLV_SENS_DATA_08 (BANK_0 | 0x43)
#define REG_EXT_SLV_SENS_DATA_09 (BANK_0 | 0x44)
#define REG_EXT_SLV_SENS_DATA_10 (BANK_0 | 0x45)

#define REG_FIFO_EN             (BANK_0 | 0x66)
#define BIT_SLV_0_FIFO_EN               0x01

#define REG_FIFO_EN_2           (BANK_0 | 0x67)
#define BIT_PRS_FIFO_EN                 0x20
#define BIT_ACCEL_FIFO_EN               0x10
#define BITS_GYRO_FIFO_EN               0x0E

#define REG_FIFO_RST            (BANK_0 | 0x68)

#define FIFO_DIVIDER 			19

#define REG_ACCEL_XOUT_H_SH     (BANK_0 | 0x2D)
#define REG_ACCEL_XOUT_L_SH     (BANK_0 | 0x2E)
#define REG_ACCEL_YOUT_H_SH     (BANK_0 | 0x2F)
#define REG_ACCEL_YOUT_L_SH     (BANK_0 | 0x30)
#define REG_ACCEL_ZOUT_H_SH     (BANK_0 | 0x31)
#define REG_ACCEL_ZOUT_L_SH     (BANK_0 | 0x32)


#define REG_FIFO_COUNT_H        (BANK_0 | 0x70)
#define REG_FIFO_COUNT_L        (BANK_0 | 0x71)
#define REG_FIFO_R_W            (BANK_0 | 0x72)

#define REG_HW_FIX_DISABLE      (BANK_0 | 0x75)


#define REG_FIFO_CFG            (BANK_0 | 0x76)
#define BIT_MULTI_FIFO_CFG              0x01
#define BIT_SINGLE_FIFO_CFG             0x00

// Accelerometer registers
#define	UB0_ACCEL_XOUT_H 			0x2D
#define	UB0_ACCEL_XOUT_L			0x2E
#define	UB0_ACCEL_YOUT_H			0x2F
#define	UB0_ACCEL_YOUT_L			0x30
#define	UB0_ACCEL_ZOUT_H			0x31
#define	UB0_ACCEL_ZOUT_L			0x32

// Gyroscope registers
#define	UB0_GYRO_XOUT_H				0x33
#define	UB0_GYRO_XOUT_L				0x34
#define	UB0_GYRO_YOUT_H				0x35
#define	UB0_GYRO_YOUT_L				0x36
#define	UB0_GYRO_ZOUT_H				0x37
#define	UB0_GYRO_ZOUT_L				0x38

// Temperature registers
#define	UB0_TEMPERATURE_ZOUT_H		0x39
#define	UB0_TEMPERATURE_ZOUT_L		0x3A

// Temperature registers
#define	UB0_FIFO_COUNT_H			0x70
#define	UB0_FIFO_COUNT_L			0x71

//ACC_REQUESTED_FREQ
#define DMP_ALGO_FREQ_56 56
#define DMP_ALGO_FREQ_112 112
#define DMP_ALGO_FREQ_225 225
#define DMP_ALGO_FREQ_450 450
#define DMP_ALGO_FREQ_900 900


//====================================================
// USER BANK 1
//====================================================
#define REG_TIMEBASE_CORRECTION_PLL   (BANK_1 | 0x28)
#define REG_TIMEBASE_CORRECTION_RCOSC (BANK_1 | 0x29)
#define REG_SELF_TEST1                (BANK_1 | 0x02)
#define REG_SELF_TEST2                (BANK_1 | 0x03)
#define REG_SELF_TEST3                (BANK_1 | 0x04)
#define REG_SELF_TEST4                (BANK_1 | 0x0E)
#define REG_SELF_TEST5                (BANK_1 | 0x0F)
#define REG_SELF_TEST6                (BANK_1 | 0x10)

#define REG_XA_OFFS_H                 (BANK_1 | 0x14)
#define REG_XA_OFFS_L                 (BANK_1 | 0x15)
#define REG_YA_OFFS_H                 (BANK_1 | 0x17)
#define REG_YA_OFFS_L                 (BANK_1 | 0x18)
#define REG_ZA_OFFS_H                 (BANK_1 | 0x1A)
#define REG_ZA_OFFS_L                 (BANK_1 | 0x1B)



//====================================================
// USER BANK 2
//====================================================
#define	UB2_GYRO_SMPLRT_DIV	0x00

#define	UB2_GYRO_CONFIG_1	0x01
#define	UB2_GYRO_CONFIG_1_FS_SEL_250DPS		0x00
#define	UB2_GYRO_CONFIG_1_FS_SEL_500DPS		0x02
#define	UB2_GYRO_CONFIG_1_FS_SEL_1000DPS	0x04
#define	UB2_GYRO_CONFIG_1_FS_SEL_2000DPS	0x06
#define	UB2_GYRO_CONFIG_1_DLPFCFG_12106HZ	0x00


// In the following registers, bit0 is set
#define	UB2_GYRO_CONFIG_1_DLPFCFG_197HZ		0x00 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_152HZ		0b00001000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_120HZ		0b00010000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_51HZ		0b00011000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_24HZ		0b00100000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_12HZ		0b00101000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_6HZ		0b00110000 | 0x01
#define	UB2_GYRO_CONFIG_1_DLPFCFG_361HZ		0b00111000 | 0x01

#define	UB2_ACCEL_SMPLRT_DIV_1	0x10		// Sample Rate Divider 1
#define	UB2_ACCEL_SMPLRT_DIV_2	0x11		// Sample Rate Divider 2

#define	UB2_ACCEL_CONFIG 	0x14
#define	UB2_ACCEL_CONFIG_FS_SEL_2G	0x00
#define	UB2_ACCEL_CONFIG_FS_SEL_4G	0x02
#define	UB2_ACCEL_CONFIG_FS_SEL_8G	0x04
#define	UB2_ACCEL_CONFIG_FS_SEL_16G	0x06
#define	UB2_ACCEL_CONFIG_DLPFCFG_1209HZ	0x00 | 0x00
#define	UB2_ACCEL_CONFIG_DLPFCFG_246HZ	0x00 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_111HZ	0b00010000 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_50HZ	0b00011000 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_24HZ 	0b00100000 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_12HZ 	0b00101000 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_6HZ	0b00110000 | 0x01
#define	UB2_ACCEL_CONFIG_DLPFCFG_473HZ	0b00111000 | 0x01

/* bank 2 register map */
#define REG_GYRO_SMPLRT_DIV     (BANK_2 | 0x00)

#define REG_GYRO_CONFIG_1       (BANK_2 | 0x01)
#define SHIFT_GYRO_FS_SEL               1
#define SHIFT_GYRO_DLPCFG               3

#define REG_GYRO_CONFIG_2       (BANK_2 | 0x02)
#define BIT_GYRO_CTEN                   0x38

#define REG_XG_OFFS_USRH        (BANK_2 | 0x03)
#define REG_XG_OFFS_USRL        (BANK_2 | 0x04)
#define REG_YG_OFFS_USRH        (BANK_2 | 0x05)
#define REG_YG_OFFS_USRL        (BANK_2 | 0x06)
#define REG_ZG_OFFS_USRH        (BANK_2 | 0x07)
#define REG_ZG_OFFS_USRL        (BANK_2 | 0x08)


#define REG_ACCEL_SMPLRT_DIV_1  (BANK_2 | 0x10)
#define REG_ACCEL_SMPLRT_DIV_2  (BANK_2 | 0x11)

#define REG_ACCEL_CONFIG        (BANK_2 | 0x14)
#define SHIFT_ACCEL_FS                  1

#define REG_ACCEL_CONFIG_2      (BANK_2 | 0x15)
#define BIT_ACCEL_CTEN                  0x1C

#define REG_MOD_CTRL_USR        (BANK_2 | 0x54)
#define BIT_ODR_SYNC                    0x7

//====================================================
// USER BANK 3
//====================================================
/* bank 3 register map */
#define REG_I2C_MST_ODR_CONFIG  (BANK_3 | 0x0)


#define	UB3_I2C_MST_CTRL			0x01
#define	UB3_I2C_MST_CTRL_CLK_400KHZ	0x07	// Gives 345.6kHz and is recommended to achieve max 400kHz

#define	UB3_I2C_SLV0_ADDR			0x03
#define	UB3_I2C_SLV0_ADDR_READ_FLAG	0x80

#define	UB3_I2C_SLV0_REG			0x04

#define	UB3_I2C_SLV0_CTRL			0x05
#define	UB3_I2C_SLV0_CTRL_EN		0x80

#define	UB3_I2C_SLV0_DO				0x06

// Magnetometer constants
#define	MAG_AK09916_I2C_ADDR = 0x0C;
#define	MAG_AK09916_WHO_AM_I = 0x4809;
#define	MAG_DATA_LENGTH = 8; // Bytes

// Magnetometer (AK09916) registers
#define	MAG_WHO_AM_I = 0x00;

#define	MAG_HXL = 0x11;

#define	MAG_CNTL2 = 0x31;
#define	MAG_CNTL2_POWER_DOWN = 0x00;
#define	MAG_CNTL2_MODE_10HZ = 0x02;
#define	MAG_CNTL2_MODE_50HZ = 0x06;
#define	MAG_CNTL2_MODE_100HZ = 0x08;

#define	MAG_CNTL3 = 0x32;
#define	MAG_CNTL3_RESET = 0x01;


#endif /* SRC_PROJECT_ICM20948_ICMREGISTERS_H_ */
