/*
 * ICM20948Helper.c
 *
 *  Created on: Apr 11, 2024
 *      Author: Michael.Oleksy
 */

#include "ICM20948.hpp"

#ifdef __cplusplus
extern "C" {
#endif

#include "ICM20948Helper.h"
#include "IMUPort.h"


// Sensors
#include "ICM20948/Driver/SensorTypes.h"
#include "Icm20948MPUFifoControl.h"


#include <stdint.h>
#include "ICM20948Transport.h"
#include <ICM20948/ICMRegisters.h>
#include "ICM20948Setup.h"

#include "ICM20948.h"
#include "ICM20948Defs.h"
#include "ICM20948/Driver/ICM20948DataConverter.h"
#include "ICM20948/Driver/ICM20948DataBaseControl.h"
#include "ICM20948/Driver/ICM20948Augmented.h"
#include "ICM20948/Driver/ICM20948Dmp3Driver.h"
#include "ICM20948/Driver/ICM20948LoadFirmware.h"
#include "ICM20948/Driver/ICM20948MPUFifoControl.h"
#include "ICM20948/Driver/SensorTypes.h"


#include "Debug/DebugLog.h"

// Helper code for our task method...
// NB!!, these are also defined elsewhere, so change both :(

/** @brief Conversion from DMP units to float format for compass scale */
#define DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION      (1/(float)(1UL<<16))
//! Convert the \a value from QN value to float. \ingroup invn_macro
#define INVN_FXP_TO_FLT(value, shift)	( (float)  (int32_t)(value) / (float)(1ULL << (shift)) )

/** @brief Set of flags for BAC state */
#define BAC_DRIVE   0x01
#define BAC_WALK    0x02
#define BAC_RUN     0x04
#define BAC_BIKE    0x08
#define BAC_TILT    0x10
#define BAC_STILL   0x20

extern int skip_sensor(struct inv_icm20948 * s, unsigned char androidSensor);
extern uint8_t inv_icm20948_updateTs(struct inv_icm20948 * s, int * data_left_in_fifo, unsigned short * total_sample_cnt, uint64_t * lastIrqTimeUs);




// STM32 SPI handle
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef hspi3;


UINT16 fifo_offset;


//===============================================================================
// Perform a blocking read from SPI
//===============================================================================
int spi_master_rx(void* ctx, uint8_t reg_address, uint8_t* pData, uint32_t len)
{
	IMUPort* port = (IMUPort*)ctx;


	// Set CS low (active)
	HAL_GPIO_WritePin(port->GPIO_Port, port->GPIO_Pin, GPIO_PIN_RESET);

	// Write the CMD/REG address
	HAL_SPI_Transmit(&port->spiHandle, (uint8_t*)&reg_address, 1, 1000);

	// Now read the data from SPI (Master must generate CLK)
	if( len > 0 )
	{
		pData[0] = 0x00;
		HAL_SPI_Receive(&port->spiHandle, (uint8_t*)pData, (uint16_t)len, 1000);
	}

	// CS goes high (inactive) at the end of transmission.
	HAL_GPIO_WritePin(port->GPIO_Port, port->GPIO_Pin, GPIO_PIN_SET);

	return 0;
}


//===============================================================================
// Perform a blocking write to SPI
//===============================================================================
int spi_master_tx(void* ctx, uint8_t reg_address, const uint8_t* pData, uint32_t len)
{
	IMUPort* port = (IMUPort*)ctx;

	// CS goes low (active) at the start of transmission and goes back high (inactive) at the end.
	HAL_GPIO_WritePin(port->GPIO_Port, port->GPIO_Pin, GPIO_PIN_RESET);

	// Write the CMD/REG address
	HAL_SPI_Transmit(&port->spiHandle, (uint8_t*)&reg_address, 1, 1000);

	// Now transmit the data
	if( len > 0 )
	{
		HAL_SPI_Transmit(&port->spiHandle, (uint8_t*)pData, (uint16_t)len, 1000);
	}

	// CS goes high (inactive) at the end of transmission.
	HAL_GPIO_WritePin(port->GPIO_Port, port->GPIO_Pin, GPIO_PIN_SET);

	return 0;
}




static uint8_t convert_to_generic_ids[INV_ICM20948_SENSOR_MAX] = {
  INV_SENSOR_TYPE_ACCELEROMETER,
  INV_SENSOR_TYPE_GYROSCOPE,
  INV_SENSOR_TYPE_RAW_ACCELEROMETER,
  INV_SENSOR_TYPE_RAW_GYROSCOPE,
  INV_SENSOR_TYPE_UNCAL_MAGNETOMETER,
  INV_SENSOR_TYPE_UNCAL_GYROSCOPE,
  INV_SENSOR_TYPE_BAC,
  INV_SENSOR_TYPE_STEP_DETECTOR,
  INV_SENSOR_TYPE_STEP_COUNTER,
  INV_SENSOR_TYPE_GAME_ROTATION_VECTOR,
  INV_SENSOR_TYPE_ROTATION_VECTOR,
  INV_SENSOR_TYPE_GEOMAG_ROTATION_VECTOR,
  INV_SENSOR_TYPE_MAGNETOMETER,
  INV_SENSOR_TYPE_SMD,
  INV_SENSOR_TYPE_PICK_UP_GESTURE,
  INV_SENSOR_TYPE_TILT_DETECTOR,
  INV_SENSOR_TYPE_GRAVITY,
  INV_SENSOR_TYPE_LINEAR_ACCELERATION,
  INV_SENSOR_TYPE_ORIENTATION,
  INV_SENSOR_TYPE_B2S
};


void setSPIHandle(SPI_HandleTypeDef& _spiHandle)
{

}


static uint8_t icm20948_get_grv_accuracy(void)
{
  uint8_t accel_accuracy;
  uint8_t gyro_accuracy;

  accel_accuracy = (uint8_t)inv_icm20948_get_accel_accuracy();
  gyro_accuracy = (uint8_t)inv_icm20948_get_gyro_accuracy();
  return (min(accel_accuracy, gyro_accuracy));
}


void build_sensor_event_data(void * context, enum inv_icm20948_sensor sensortype, uint64_t timestamp, const void * data, const void *arg)
{
	float raw_bias_data[6];
	inv_sensor_event_t event;
	//(void)context;
	ICM20948* pRexICM20948 = static_cast<ICM20948*>(context);

	uint8_t sensor_id = convert_to_generic_ids[sensortype];

	memset((void *)&event, 0, sizeof(event));
	event.sensor = sensor_id;
	event.timestamp = timestamp;
	switch (sensor_id)
	{
  	  case INV_SENSOR_TYPE_UNCAL_GYROSCOPE:
  		  memcpy(raw_bias_data, data, sizeof(raw_bias_data));
  		  memcpy(event.data.gyr.vect, &raw_bias_data[0], sizeof(event.data.gyr.vect));
  		  memcpy(event.data.gyr.bias, &raw_bias_data[3], sizeof(event.data.gyr.bias));
  		  memcpy(&(event.data.gyr.accuracy_flag), arg, sizeof(event.data.gyr.accuracy_flag));
  		  break;

  	  case INV_SENSOR_TYPE_UNCAL_MAGNETOMETER:
  		  memcpy(raw_bias_data, data, sizeof(raw_bias_data));
  		  memcpy(event.data.mag.vect, &raw_bias_data[0], sizeof(event.data.mag.vect));
  		  memcpy(event.data.mag.bias, &raw_bias_data[3], sizeof(event.data.mag.bias));
  		  memcpy(&(event.data.gyr.accuracy_flag), arg, sizeof(event.data.gyr.accuracy_flag));
  		  break;

  	  case INV_SENSOR_TYPE_GYROSCOPE:
  		  memcpy(event.data.gyr.vect, data, sizeof(event.data.gyr.vect));
  		  memcpy(&(event.data.gyr.accuracy_flag), arg, sizeof(event.data.gyr.accuracy_flag));

  		  // WE WANT THIS
  		  pRexICM20948->gyro_x = event.data.gyr.vect[0];
  		  pRexICM20948->gyro_y = event.data.gyr.vect[1];
  		  pRexICM20948->gyro_z = event.data.gyr.vect[2];
  		  pRexICM20948->gyro_data_ready = true;
  		  break;

  	  case INV_SENSOR_TYPE_GRAVITY:
  		  memcpy(event.data.acc.vect, data, sizeof(event.data.acc.vect));
  		  event.data.acc.accuracy_flag = inv_icm20948_get_accel_accuracy();
  		  break;

  	  case INV_SENSOR_TYPE_LINEAR_ACCELERATION:
  	  case INV_SENSOR_TYPE_ACCELEROMETER:
  		  memcpy(event.data.acc.vect, data, sizeof(event.data.acc.vect));
  		  memcpy(&(event.data.acc.accuracy_flag), arg, sizeof(event.data.acc.accuracy_flag));

  		  // WE WANT THIS
  		  pRexICM20948->accel_x = event.data.acc.vect[0];
  		  pRexICM20948->accel_y = event.data.acc.vect[1];
  		  pRexICM20948->accel_z = event.data.acc.vect[2];
  		  pRexICM20948->accel_data_ready = true;
  		  break;

  	  case INV_SENSOR_TYPE_MAGNETOMETER:
  		  memcpy(event.data.mag.vect, data, sizeof(event.data.mag.vect));
  		  memcpy(&(event.data.mag.accuracy_flag), arg, sizeof(event.data.mag.accuracy_flag));

  		  // WE WANT THIS
  		  pRexICM20948->mag_x = event.data.mag.vect[0];
  		  pRexICM20948->mag_y = event.data.mag.vect[1];
  		  pRexICM20948->mag_z = event.data.mag.vect[2];
  		  pRexICM20948->mag_data_ready = true;
  		  break;

  	  case INV_SENSOR_TYPE_GEOMAG_ROTATION_VECTOR:
  	  case INV_SENSOR_TYPE_ROTATION_VECTOR:
  		  memcpy(&(event.data.quaternion.accuracy), arg, sizeof(event.data.quaternion.accuracy));
  		  memcpy(event.data.quaternion.quat, data, sizeof(event.data.quaternion.quat));
  		  break;

  	  case INV_SENSOR_TYPE_GAME_ROTATION_VECTOR:
  		  memcpy(event.data.quaternion.quat, data, sizeof(event.data.quaternion.quat));
  		  event.data.quaternion.accuracy_flag = icm20948_get_grv_accuracy();

  		  // WE WANT THIS
  		  pRexICM20948->quat_w = event.data.quaternion.quat[0];
  		  pRexICM20948->quat_x = event.data.quaternion.quat[1];
  		  pRexICM20948->quat_y = event.data.quaternion.quat[2];
  		  pRexICM20948->quat_z = event.data.quaternion.quat[3];
  		  pRexICM20948->quat_data_ready = true;
  		  break;

  	  case INV_SENSOR_TYPE_BAC:
  		  memcpy(&(event.data.bac.event), data, sizeof(event.data.bac.event));
  		  break;

  	  case INV_SENSOR_TYPE_PICK_UP_GESTURE:
  	  case INV_SENSOR_TYPE_TILT_DETECTOR:
  	  case INV_SENSOR_TYPE_STEP_DETECTOR:
  	  case INV_SENSOR_TYPE_SMD:
  		  event.data.event = true;
  		  break;

  	  case INV_SENSOR_TYPE_B2S:
  		  event.data.event = true;
  		  memcpy(&(event.data.b2s.direction), data, sizeof(event.data.b2s.direction));
  		  break;

  	  case INV_SENSOR_TYPE_STEP_COUNTER:
  		  memcpy(&(event.data.step.count), data, sizeof(event.data.step.count));
  		  break;

  	  case INV_SENSOR_TYPE_ORIENTATION:
  		  //we just want to copy x,y,z from orientation data
  		  memcpy(&(event.data.orientation), data, 3 * sizeof(float));
  		  break;

  	  case INV_SENSOR_TYPE_RAW_ACCELEROMETER:
  	  case INV_SENSOR_TYPE_RAW_GYROSCOPE:
  		  memcpy(event.data.raw3d.vect, data, sizeof(event.data.raw3d.vect));
  		  break;

    default:
      return;
  }
}



int MyTaskExecute( ICM20948* imyDevice, struct inv_icm20948 * s, void * context,
			void (*handler)(void * context, enum inv_icm20948_sensor sensor, uint64_t timestamp, const void * data, const void *arg))
{
	//s = icm_device;
	short int_read_back=0;
	unsigned short header=0, header2 = 0;
	int data_left_in_fifo=0;
	short short_data[3] = {0};
	signed long  long_data[3] = {0};

	//signed long  long_quat[3] = {0};    // Changed by M.O.
	signed long  long_quat[4] = {0};


	float gyro_raw_float[3];
	float gyro_bias_float[3];
	int gyro_accuracy = 0;
	int dummy_accuracy = 0;
	int accel_accuracy = 0;
	int compass_accuracy = 0;
	float rv_accuracy = 0;
	float gmrv_accuracy = 0;
	float accel_float[3];
	float grv_float[4];
	float gyro_float[3];
	float compass_float[3] = {0};
	float compass_raw_float[3];
	float rv_float[4];
	float gmrv_float[4];
	uint16_t pickup_state = 0;
	uint64_t lastIrqTimeUs;

	bool quat_result = false;
	bool accel_result = false;


	//inv_icm20948_identify_interrupt(s, &int_read_back);

	//if (int_read_back & (BIT_MSG_DMP_INT | BIT_MSG_DMP_INT_0))
	{
		lastIrqTimeUs = inv_icm20948_get_time_us();

		do
		{
			unsigned short total_sample_cnt = 0;

			//DBG_LOG_MESSAGE("RS");

			/* Mirror FIFO contents and stop processing FIFO if an error was detected*/
			if(inv_icm20948_updateTs(s, &data_left_in_fifo, &total_sample_cnt, &lastIrqTimeUs))
				break;

			//DBG_LOG_MESSAGE("RE");

			fifo_offset = 0;

			while(total_sample_cnt--)
			{
				/* Read FIFO contents and parse it, and stop processing FIFO if an error was detected*/
				if (inv_icm20948_fifo_pop(s, &header, &header2, &data_left_in_fifo))
					break;

//				if( quat_result && accel_result )
//				{
//					total_sample_cnt = 0;
//					data_left_in_fifo = 0;
//					break;
//				}


				/* Gyro sample available from DMP FIFO */
				if (header & GYRO_SET) {
					float lScaleDeg = (1 << inv_icm20948_get_gyro_fullscale(s)) * 250.f; // From raw to dps to degree per seconds
					float lScaleDeg_bias = 2000.f; // Gyro bias from FIFO is always in 2^20 = 2000 dps regardless of fullscale
					signed long  lRawGyroQ15[3] = {0};
					signed long  lBiasGyroQ20[3] = {0};

					/* Read raw gyro out of DMP FIFO and convert it from Q15 raw data format to radian per seconds in Android format */
					inv_icm20948_dmp_get_raw_gyro(short_data);
					lRawGyroQ15[0] = (long) short_data[0];
					lRawGyroQ15[1] = (long) short_data[1];
					lRawGyroQ15[2] = (long) short_data[2];
					inv_icm20948_convert_dmp3_to_body(s, lRawGyroQ15, lScaleDeg/(1L<<15), gyro_raw_float);

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_RAW_GYROSCOPE) && !skip_sensor(s, ANDROID_SENSOR_RAW_GYROSCOPE)) {
						long out[3];
						inv_icm20948_convert_quat_rotate_fxp(s->s_quat_chip_to_body, lRawGyroQ15, out);
						s->timestamp[INV_ICM20948_SENSOR_RAW_GYROSCOPE] += s->sensorlist[INV_ICM20948_SENSOR_RAW_GYROSCOPE].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_RAW_GYROSCOPE, s->timestamp[INV_ICM20948_SENSOR_RAW_GYROSCOPE], out, &dummy_accuracy);
					}

					/* Read bias gyro out of DMP FIFO and convert it from Q20 raw data format to radian per seconds in Android format */
					inv_icm20948_dmp_get_gyro_bias(short_data);
					lBiasGyroQ20[0] = (long) short_data[0];
					lBiasGyroQ20[1] = (long) short_data[1];
					lBiasGyroQ20[2] = (long) short_data[2];
					inv_icm20948_convert_dmp3_to_body(s, lBiasGyroQ20, lScaleDeg_bias/(1L<<20), gyro_bias_float);

					/* Extract accuracy and calibrated gyro data based on raw/bias data if calibrated gyro sensor is enabled */
					gyro_accuracy = inv_icm20948_get_gyro_accuracy();
					/* If accuracy has changed previously we update the new accuracy the same time as bias*/
					if(s->set_accuracy){
						s->set_accuracy = 0;
						s->new_accuracy = gyro_accuracy;
					}
					/* gyro accuracy has changed, we will notify it the next time*/
					if(gyro_accuracy != s->new_accuracy){
						s->set_accuracy = 1;
					}

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GYROSCOPE) && !skip_sensor(s, ANDROID_SENSOR_GYROSCOPE)) {
						// shift to Q20 to do all calibrated gyrometer operations in Q20
						// Gyro bias from FIFO is always in 2^20 = 2000 dps regardless of fullscale
						// Raw gyro from FIFO is in 2^15 = gyro fsr (250/500/1000/2000).
						lRawGyroQ15[0] <<= 5 - (MPU_FS_2000dps - inv_icm20948_get_gyro_fullscale(s));
						lRawGyroQ15[1] <<= 5 - (MPU_FS_2000dps - inv_icm20948_get_gyro_fullscale(s));
						lRawGyroQ15[2] <<= 5 - (MPU_FS_2000dps - inv_icm20948_get_gyro_fullscale(s));
						/* Compute calibrated gyro data based on raw and bias gyro data and convert it from Q20 raw data format to radian per seconds in Android format */
						inv_icm20948_dmp_get_calibrated_gyro(long_data, lRawGyroQ15, lBiasGyroQ20);
						inv_icm20948_convert_dmp3_to_body(s, long_data, lScaleDeg_bias/(1L<<20), gyro_float);
						s->timestamp[INV_ICM20948_SENSOR_GYROSCOPE] += s->sensorlist[INV_ICM20948_SENSOR_GYROSCOPE].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_GYROSCOPE, s->timestamp[INV_ICM20948_SENSOR_GYROSCOPE], gyro_float, &s->new_accuracy);
					}

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GYROSCOPE_UNCALIBRATED)  && !skip_sensor(s, ANDROID_SENSOR_GYROSCOPE_UNCALIBRATED)) {
						float raw_bias_gyr[6];
						raw_bias_gyr[0] = gyro_raw_float[0];
						raw_bias_gyr[1] = gyro_raw_float[1];
						raw_bias_gyr[2] = gyro_raw_float[2];
						raw_bias_gyr[3] = gyro_bias_float[0];
						raw_bias_gyr[4] = gyro_bias_float[1];
						raw_bias_gyr[5] = gyro_bias_float[2];
						s->timestamp[INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED] += s->sensorlist[INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED].odr_applied_us;
						/* send raw float and bias for uncal gyr*/
						handler(context, INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED, s->timestamp[INV_ICM20948_SENSOR_GYROSCOPE_UNCALIBRATED], raw_bias_gyr, &s->new_accuracy);
					}
				}

				/* Calibrated accel sample available from DMP FIFO */
				if (header & ACCEL_SET) {
					float scale;
					/* Read calibrated accel out of DMP FIFO and convert it from Q25 raw data format to m/s² in Android format */
					inv_icm20948_dmp_get_accel(long_data);

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_RAW_ACCELEROMETER) && !skip_sensor(s, ANDROID_SENSOR_RAW_ACCELEROMETER)) {
						long out[3];
						inv_icm20948_convert_quat_rotate_fxp(s->s_quat_chip_to_body, long_data, out);

						/* convert to raw data format to Q12/Q11/Q10/Q9 depending on full scale applied,
						so that it fits on 16bits so that it can go through any protocol, even the one which have raw data on 16b */
						out[0] = out[0] >> 15;
						out[1] = out[1] >> 15;
						out[2] = out[2] >> 15;
						s->timestamp[INV_ICM20948_SENSOR_RAW_ACCELEROMETER] += s->sensorlist[INV_ICM20948_SENSOR_RAW_ACCELEROMETER].odr_applied_us;
							handler(context, INV_ICM20948_SENSOR_RAW_ACCELEROMETER, s->timestamp[INV_ICM20948_SENSOR_RAW_ACCELEROMETER], out, &dummy_accuracy);
					}
					if((inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_ACCELEROMETER) && !skip_sensor(s, ANDROID_SENSOR_ACCELEROMETER)) ||
						(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_LINEAR_ACCELERATION))) {
							accel_accuracy = inv_icm20948_get_accel_accuracy();
							scale = (1 << inv_icm20948_get_accel_fullscale(s)) * 2.f / (1L<<30); // Convert from raw units to g's

							inv_icm20948_convert_dmp3_to_body(s, long_data, scale, accel_float);

							if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_ACCELEROMETER)) {
								s->timestamp[INV_ICM20948_SENSOR_ACCELEROMETER] += s->sensorlist[INV_ICM20948_SENSOR_ACCELEROMETER].odr_applied_us;
								handler(context, INV_ICM20948_SENSOR_ACCELEROMETER, s->timestamp[INV_ICM20948_SENSOR_ACCELEROMETER], accel_float, &accel_accuracy);

								// M.O. optimisation
								// Only need one accelerometer...
								accel_result = true;
								//break;
							}
					}
				}

				/* Calibrated compass sample available from DMP FIFO */
				if (header & CPASS_CALIBR_SET) {
					float scale;

					/* Read calibrated compass out of DMP FIFO and convert it from Q16 raw data format to µT in Android format */
					inv_icm20948_dmp_get_calibrated_compass(long_data);

					compass_accuracy = inv_icm20948_get_mag_accuracy();
					scale = DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
					inv_icm20948_convert_dmp3_to_body(s, long_data, scale, compass_float);
					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GEOMAGNETIC_FIELD) && !skip_sensor(s, ANDROID_SENSOR_GEOMAGNETIC_FIELD)) {
						s->timestamp[INV_ICM20948_SENSOR_GEOMAGNETIC_FIELD] += s->sensorlist[INV_ICM20948_SENSOR_GEOMAGNETIC_FIELD].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_GEOMAGNETIC_FIELD, s->timestamp[INV_ICM20948_SENSOR_GEOMAGNETIC_FIELD], compass_float, &compass_accuracy);
					}
				}

				/* Raw compass sample available from DMP FIFO */
				if (header & CPASS_SET) {
					/* Read calibrated compass out of DMP FIFO and convert it from Q16 raw data format to µT in Android format */
					inv_icm20948_dmp_get_raw_compass(long_data);
					compass_raw_float[0] = long_data[0] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
					compass_raw_float[1] = long_data[1] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
					compass_raw_float[2] = long_data[2] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_MAGNETIC_FIELD_UNCALIBRATED) && !skip_sensor(s, ANDROID_SENSOR_MAGNETIC_FIELD_UNCALIBRATED)) {
						float raw_bias_mag[6];
						int mag_bias[3];

						raw_bias_mag[0] = compass_raw_float[0];
						raw_bias_mag[1] = compass_raw_float[1];
						raw_bias_mag[2] = compass_raw_float[2];
						inv_icm20948_ctrl_get_mag_bias(s, mag_bias);
						//calculate bias
						raw_bias_mag[3] = mag_bias[0] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
						raw_bias_mag[4] = mag_bias[1] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;
						raw_bias_mag[5] = mag_bias[2] * DMP_UNIT_TO_FLOAT_COMPASS_CONVERSION;

						compass_accuracy = inv_icm20948_get_mag_accuracy();
						s->timestamp[INV_ICM20948_SENSOR_MAGNETIC_FIELD_UNCALIBRATED] += s->sensorlist[INV_ICM20948_SENSOR_MAGNETIC_FIELD_UNCALIBRATED].odr_applied_us;
						/* send raw float and bias for uncal mag*/
						handler(context, INV_ICM20948_SENSOR_MAGNETIC_FIELD_UNCALIBRATED, s->timestamp[INV_ICM20948_SENSOR_MAGNETIC_FIELD_UNCALIBRATED],
							raw_bias_mag, &compass_accuracy);
					}
				}

				/* 6axis AG orientation quaternion sample available from DMP FIFO */
				if (header & QUAT6_SET) {
					long gravityQ16[3];
					float ref_quat[4];

					/* Read 6 axis quaternion out of DMP FIFO in Q30 */
					inv_icm20948_dmp_get_6quaternion(long_quat);
					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GAME_ROTATION_VECTOR) && !skip_sensor(s, ANDROID_SENSOR_GAME_ROTATION_VECTOR)) {
						/* and convert it from Q30 DMP format to Android format only if GRV sensor is enabled */
						inv_icm20948_convert_rotation_vector(s, long_quat, grv_float);
						ref_quat[0] = grv_float[3];
						ref_quat[1] = grv_float[0];
						ref_quat[2] = grv_float[1];
						ref_quat[3] = grv_float[2];
						s->timestamp[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR] += s->sensorlist[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR, s->timestamp[INV_ICM20948_SENSOR_GAME_ROTATION_VECTOR], ref_quat, 0);


						// M.O. optimisation
						// We only need ine quaternion ...
						quat_result = true;
						//break;
					}

					/* Compute gravity sensor data in Q16 in g based on 6 axis quaternion in Q30 DMP format */
					inv_icm20948_augmented_sensors_get_gravity(s, gravityQ16, long_quat);
					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GRAVITY) && !skip_sensor(s, ANDROID_SENSOR_GRAVITY)) {
						float gravity_float[3];
						/* Convert gravity data from Q16 to float format in g */
						gravity_float[0] = INVN_FXP_TO_FLT(gravityQ16[0], 16);
						gravity_float[1] = INVN_FXP_TO_FLT(gravityQ16[1], 16);
						gravity_float[2] = INVN_FXP_TO_FLT(gravityQ16[2], 16);
						s->timestamp[INV_ICM20948_SENSOR_GRAVITY] += s->sensorlist[INV_ICM20948_SENSOR_GRAVITY].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_GRAVITY, s->timestamp[INV_ICM20948_SENSOR_GRAVITY], gravity_float, &accel_accuracy);
					}

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_LINEAR_ACCELERATION) && !skip_sensor(s, ANDROID_SENSOR_LINEAR_ACCELERATION)) {
						float linacc_float[3];
						long linAccQ16[3];
						long accelQ16[3];

						/* Compute linear acceleration data based on accelerometer data in Q16 g and on gravity data in Q16 g */
						accelQ16[0] = (int32_t)  ((float)(accel_float[0])*(1ULL << 16) + ( (accel_float[0]>=0)-0.5f ));
						accelQ16[1] = (int32_t)  ((float)(accel_float[1])*(1ULL << 16) + ( (accel_float[1]>=0)-0.5f ));
						accelQ16[2] = (int32_t)  ((float)(accel_float[2])*(1ULL << 16) + ( (accel_float[2]>=0)-0.5f ));

						inv_icm20948_augmented_sensors_get_linearacceleration(linAccQ16, gravityQ16, accelQ16);
						linacc_float[0] = INVN_FXP_TO_FLT(linAccQ16[0], 16);
						linacc_float[1] = INVN_FXP_TO_FLT(linAccQ16[1], 16);
						linacc_float[2] = INVN_FXP_TO_FLT(linAccQ16[2], 16);
						s->timestamp[INV_ICM20948_SENSOR_LINEAR_ACCELERATION] += s->sensorlist[INV_ICM20948_SENSOR_LINEAR_ACCELERATION].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_LINEAR_ACCELERATION, s->timestamp[INV_ICM20948_SENSOR_LINEAR_ACCELERATION], linacc_float, &accel_accuracy);
					}
				}

				/* 9axis orientation quaternion sample available from DMP FIFO */
				if (header & QUAT9_SET) {
					float ref_quat[4];
					/* Read 9 axis quaternion out of DMP FIFO in Q30 */
					inv_icm20948_dmp_get_9quaternion(long_quat);

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_ROTATION_VECTOR) && !skip_sensor(s, ANDROID_SENSOR_ROTATION_VECTOR)) {
						/* and convert it from Q30 DMP format to Android format only if RV sensor is enabled */
						inv_icm20948_convert_rotation_vector(s, long_quat, rv_float);
						/* Read rotation vector heading accuracy out of DMP FIFO in Q29*/
						{
							float rv_accur = inv_icm20948_get_rv_accuracy();
							rv_accuracy = rv_accur/(float)(1ULL << (29));
						}
						ref_quat[0] = rv_float[3];
						ref_quat[1] = rv_float[0];
						ref_quat[2] = rv_float[1];
						ref_quat[3] = rv_float[2];
						s->timestamp[INV_ICM20948_SENSOR_ROTATION_VECTOR] += s->sensorlist[INV_ICM20948_SENSOR_ROTATION_VECTOR].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_ROTATION_VECTOR, s->timestamp[INV_ICM20948_SENSOR_ROTATION_VECTOR], ref_quat, &rv_accuracy);
					}

					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_ORIENTATION) && !skip_sensor(s, ANDROID_SENSOR_ORIENTATION)) {
						long orientationQ16[3];
						float orientation_float[3];
						/* Compute Android-orientation sensor data based on rotation vector data in Q30 */
						inv_icm20948_augmented_sensors_get_orientation(orientationQ16, long_quat);
						orientation_float[0] = INVN_FXP_TO_FLT(orientationQ16[0], 16);
						orientation_float[1] = INVN_FXP_TO_FLT(orientationQ16[1], 16);
						orientation_float[2] = INVN_FXP_TO_FLT(orientationQ16[2], 16);
						s->timestamp[INV_ICM20948_SENSOR_ORIENTATION] += s->sensorlist[INV_ICM20948_SENSOR_ORIENTATION].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_ORIENTATION, s->timestamp[INV_ICM20948_SENSOR_ORIENTATION], orientation_float, 0);
					}
				}

				/* 6axis AM orientation quaternion sample available from DMP FIFO */
				if (header & GEOMAG_SET) {
					float ref_quat[4];
					/* Read 6 axis quaternion out of DMP FIFO in Q30 and convert it to Android format */
					inv_icm20948_dmp_get_gmrvquaternion(long_quat);
					if(inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_GEOMAGNETIC_ROTATION_VECTOR) && !skip_sensor(s, ANDROID_SENSOR_GEOMAGNETIC_ROTATION_VECTOR)) {
						inv_icm20948_convert_rotation_vector(s, long_quat, gmrv_float);
						/* Read geomagnetic rotation vector heading accuracy out of DMP FIFO in Q29*/
						{
							float gmrv_acc = inv_icm20948_get_gmrv_accuracy();
							gmrv_accuracy = gmrv_acc/(float)(1ULL << (29));
						}
						ref_quat[0] = gmrv_float[3];
						ref_quat[1] = gmrv_float[0];
						ref_quat[2] = gmrv_float[1];
						ref_quat[3] = gmrv_float[2];
						s->timestamp[INV_ICM20948_SENSOR_GEOMAGNETIC_ROTATION_VECTOR] += s->sensorlist[INV_ICM20948_SENSOR_GEOMAGNETIC_ROTATION_VECTOR].odr_applied_us;
						handler(context, INV_ICM20948_SENSOR_GEOMAGNETIC_ROTATION_VECTOR, s->timestamp[INV_ICM20948_SENSOR_GEOMAGNETIC_ROTATION_VECTOR],
							ref_quat, &gmrv_accuracy);
					}
				}

				/* Activity recognition sample available from DMP FIFO */
				if (header2 & ACT_RECOG_SET) {
					uint16_t bac_state = 0;
					long bac_ts = 0;
					int bac_event = 0;
					struct bac_map{
						uint8_t act_id;
						enum inv_sensor_bac_event sensor_bac;
					} map[] = {
						{ BAC_DRIVE, INV_SENSOR_BAC_EVENT_ACT_IN_VEHICLE_BEGIN},
						{ BAC_WALK, INV_SENSOR_BAC_EVENT_ACT_WALKING_BEGIN},
						{ BAC_RUN, INV_SENSOR_BAC_EVENT_ACT_RUNNING_BEGIN},
						{ BAC_BIKE, INV_SENSOR_BAC_EVENT_ACT_ON_BICYCLE_BEGIN},
						{ BAC_STILL, INV_SENSOR_BAC_EVENT_ACT_STILL_BEGIN},
						{ BAC_TILT, INV_SENSOR_BAC_EVENT_ACT_TILT_BEGIN},
					};
					int i = 0;
					/* Read activity type and associated timestamp out of DMP FIFO
					activity type is a set of 2 bytes :
					- high byte indicates activity start
					- low byte indicates activity end */
					inv_icm20948_dmp_get_bac_state(&bac_state);
					inv_icm20948_dmp_get_bac_ts(&bac_ts);
					//Map according to dmp bac events
					for(i = 0; i < 6; i++) {
						if ((bac_state >> 8) & map[i].act_id){
							//Check if BAC is enabled
							if (inv_icm20948_ctrl_get_activitiy_classifier_on_flag(s)) {
								/* Start detected */
								bac_event = map[i].sensor_bac;
								handler(context, INV_ICM20948_SENSOR_ACTIVITY_CLASSIFICATON, s->timestamp[INV_ICM20948_SENSOR_ACTIVITY_CLASSIFICATON], &bac_event, 0);
							}
							//build event TILT only if enabled
							if((map[i].act_id == BAC_TILT) && inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_WAKEUP_TILT_DETECTOR))
								handler(context, INV_ICM20948_SENSOR_WAKEUP_TILT_DETECTOR, s->timestamp[INV_ICM20948_SENSOR_WAKEUP_TILT_DETECTOR], 0, 0);
						}
						/* Check if bit tilt is set for activity end byte */
						else if (bac_state & map[i].act_id) {
							//Check if BAC is enabled
							if (inv_icm20948_ctrl_get_activitiy_classifier_on_flag(s)) {
								/* End detected */
								bac_event = -map[i].sensor_bac;
								handler(context, INV_ICM20948_SENSOR_ACTIVITY_CLASSIFICATON, s->timestamp[INV_ICM20948_SENSOR_ACTIVITY_CLASSIFICATON], &bac_event, 0);
							}
						}
					}
				}

				/* Pickup sample available from DMP FIFO */
				if (header2 & FLIP_PICKUP_SET) {
					/* Read pickup type and associated timestamp out of DMP FIFO */
					inv_icm20948_dmp_get_flip_pickup_state(&pickup_state);
					handler(context, INV_ICM20948_SENSOR_FLIP_PICKUP, s->timestamp[INV_ICM20948_SENSOR_FLIP_PICKUP], &pickup_state, 0);
				}

				/* Step detector available from DMP FIFO and step counter sensor is enabled*/
				// If step detector enabled => step counter started too
				// So don't watch the step counter data if the user doesn't start the sensor
				if((header & PED_STEPDET_SET) && (inv_icm20948_ctrl_androidSensor_enabled(s, ANDROID_SENSOR_STEP_COUNTER))) {
					unsigned long steps;
					unsigned long lsteps;
					uint64_t stepc = 0;
					/* Read amount of steps counted out of DMP FIFO and notify them only if updated */
					dmp_icm20948_get_pedometer_num_of_steps(s, &lsteps);
					// need to subtract the steps accumulated while Step Counter sensor is not active.
					steps = lsteps - s->sStepCounterToBeSubtracted;
					stepc = steps;
					if(stepc != s->sOldSteps) {
						s->sOldSteps = steps;
						handler(context, INV_ICM20948_SENSOR_STEP_COUNTER, s->timestamp[INV_ICM20948_SENSOR_STEP_COUNTER], &stepc, 0);
					}
				}
			}
		} while(data_left_in_fifo);

		/* SMD detected by DMP */
		if (int_read_back & BIT_MSG_DMP_INT_2) {
			uint8_t event = 0;
			handler(context, INV_ICM20948_SENSOR_WAKEUP_SIGNIFICANT_MOTION, s->timestamp[INV_ICM20948_SENSOR_WAKEUP_SIGNIFICANT_MOTION], &event, 0);
		}

		/* Step detector triggered by DMP */
		if (int_read_back & BIT_MSG_DMP_INT_3) {
			uint8_t event = 0;
			handler(context, INV_ICM20948_SENSOR_STEP_DETECTOR, s->timestamp[INV_ICM20948_SENSOR_STEP_DETECTOR], &event, 0);
		}

		/* Bring to see detected by DMP */
		if (int_read_back & BIT_MSG_DMP_INT_5) {
			uint8_t event = 0;
			handler(context, INV_ICM20948_SENSOR_B2S, s->timestamp[INV_ICM20948_SENSOR_B2S], &event, 0);
		}
	}

	/* Sometimes, the chip can be put in sleep mode even if there is data in the FIFO. If we poll at this moment, the transport layer will wake-up the chip, but never put it back in sleep. */
	if (s->mems_put_to_sleep) {
		DBG_LOG_MESSAGE("Sleep1");
		inv_icm20948_sleep_mems(s);
		DBG_LOG_MESSAGE("Sleep2");

	}

	return 0;
}


#ifdef __cplusplus
}
#endif

