/*
 * ICM20948.h
 *
 *  Created on: Mar 15, 2024
 *      Author: Michael.Oleksy
 */

#ifndef _ICM20948_HPP_
#define _ICM20948_HPP_

// C++ includes
#include <iostream>
#include <memory>

#include <main.h>
#include "project.hpp"
#include "ICM20948/IMUPort.h"
#include "IMU/CmdManager.h"
#include "IMU/CommandState.h"

#include "ICM20948.h"
//#include "ICM20948/Driver/ICM20948MPUFifoControl.h"




#ifdef __cplusplus
extern "C" {
#endif

//#include "ICM20948/Driver/ICM20948MPUFifoControl.h"



typedef struct {
  int mode;							// 0 = low power mode, 1 = high performance mode
  bool enable_gyroscope;			// Enables gyroscope output
  bool enable_accelerometer;		// Enables accelerometer output
  bool enable_magnetometer;			// Enables magnetometer output
  bool enable_quaternion;			// Enables quaternion output
  int gyroscope_frequency;			// Max frequency = 225, min frequency = 1
  int accelerometer_frequency;		// Max frequency = 225, min frequency = 1
  int magnetometer_frequency;		// Max frequency = 70, min frequency = 1
  int quaternion_frequency;			// Max frequency = 225, min frequency = 50
} ICM20948Settings_t;

#define THREE_AXES 3
const uint8_t EXPECTED_WHOAMI[] = { 0xEA }; /* WHOAMI value for ICM20948 or derivative */



//=======================================================================
// Class Definition
//=======================================================================
class ICM20948
{
public:
	ICM20948(const IMUPort imuPort, UINT16 id );

	// Prevent compiler from generating the assignment operator and copy constructor
	ICM20948& operator=(const ICM20948&) = delete;

	// We need to create a proper copy constructor!!
	// We are referencing heap objects, so simple copy will not suffice if original object is destroyed.
	ICM20948(const ICM20948&) = default;

	virtual ~ICM20948();


	//===========================================
	// Raw Sensor Section
	//===========================================
	// Set/Reset the Chip Select (CS) pin for this ICM20948
	void setCS(GPIO_PinState state);

	/* Command Manager */
	// Add a command to the list of commands for this device
	void addCommand(Command_t cmd);

	// Command execution
	CommandState getCmdState(void) { return cmdState; }
	Command_t& getCmd();
	Command_t& getNextCmd();

	void reset_dmp();

	bool interface_is_SPI(){ return true; }
	UINT16 construct_BINARY_IMU_Data_Packet(char** buffer);
	UINT16 construct_ASCII_IMU_Data_Packet(char** buffer);


	// Indicates the IMU has responded with data for the current iteration
    inline void setProcessed(bool value) { processed = value; }
    inline bool isProcessed() { return processed; }

	//===========================================
	// DMP Section
	//===========================================
    int  init();
    int  load_dmp3();

    void task();
    void GetOrientationQuat(uint8_t* data);
    UINT16 getID() { return id; }

    void gatherAccelSamples();
    void applyAccelOffset();

    bool gyroDataIsReady() { return gyro_data_ready; }
    bool accelDataIsReady() { return accel_data_ready; }
    bool magDataIsReady() { return mag_data_ready; }
    bool quatDataIsReady() { return quat_data_ready; }

    void readGyroData(float *x, float *y, float *z);
    void readAccelData(float *x, float *y, float *z);
    void readMagData(float *x, float *y, float *z);
    void readQuatData(float *w, float *x, float *y, float *z);

    int icm20948_sensor_setup();
	void icm20948_apply_mounting_matrix();
	void icm20948_set_fsr();


public:
	float const gravity = 9.834 / 10.0f;

    float gyro_x, gyro_y, gyro_z;

    // Acceleration values
    float accel_x, accel_y, accel_z;
    float prev_accel_x, prev_accel_y, prev_accel_z;

    float accel_offset_x, accel_offset_y, accel_offset_z;
    bool  sample_accel;
    UINT32	sample_count;

    // Position values
    float pos_x, pos_y, pos_z;

    float mag_x, mag_y, mag_z;
    float quat_w, quat_x, quat_y, quat_z;


    bool gyro_data_ready = false;
    bool accel_data_ready = false;
    bool mag_data_ready = false;
    bool quat_data_ready = false;


    int unscaled_bias[THREE_AXES * 2];

    const ICM20948Settings_t* settings() {return &icm_settings;}

    UINT16 id;
	inv_icm20948_t* icm_device;

private:
    typedef struct inv_icm20948_serif inv_icm20948_serif_t;


    // DMP Settings used by DMP engine
    static constexpr ICM20948Settings_t icm_settings =
    {
      .mode = 1,                    		// 0 = low power mode, 1 = high performance mode
      .enable_gyroscope = false,	      	// Enables gyroscope output
      .enable_accelerometer = true,  		// Enables accelerometer output
      .enable_magnetometer = true,   		// Enables magnetometer output
      .enable_quaternion = true,     		// Enables quaternion output
      .gyroscope_frequency = 1,      		// Max frequency = 225, min frequency = 1
      .accelerometer_frequency = 100,  		// Max frequency = 225, min frequency = 1
      .magnetometer_frequency = 1,   		// Max frequency = 70, min frequency = 1
      .quaternion_frequency = 100,	   		// Max frequency = 225, min frequency = 50
    };


	IMUPort				imuPort;
	enum CommandState	cmdState;			// Needed ??
	bool processed;

	// Manager for raw commands
	CmdManager* cmdManager;

	// Collection of Device settings
	//inv_icm20948_t* icm_device;
	inv_icm20948_serif_t* icm20948_serif;

	/* FSR configurations */
	int32_t cfg_acc_fsr = 4; 		// Default = +/- 4g. Valid ranges: 2, 4, 8, 16
	int32_t cfg_gyr_fsr = 2000;		 // Default = +/- 2000dps. Valid ranges: 250, 500, 1000, 2000

	// Mounting matrix configuration applied for Accel, Gyro and Mag
	const float cfg_mounting_matrix[9]= {
		1.f, 0, 0,
		0, 1.f, 0,
		0, 0, 1.f
	};
};

#ifdef __cplusplus
}
#endif

#endif /* _ICM20948_HPP_ */
