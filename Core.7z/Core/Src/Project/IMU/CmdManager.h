/*
 * CmdManager.h
 *
 *  Created on: Mar 20, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_IMU_CMDMANAGER_H_
#define SRC_PROJECT_IMU_CMDMANAGER_H_

#include <ICM20948/ICMRegisters.h>
#include <vector>
#include <iostream>

#include "project.hpp"


typedef struct IMUCommands
{
	uint8_t	repeat;			// 0 => no repeats
							// 1 => repeat current command
							// 2 => go back 1 command

	UINT8	address;		// IMU address
	UINT8	data;
	UINT8	TxDataLen;
	UINT8	RxDataLen;
}Command_t;



class CmdManager
{
public:
	CmdManager() : cmdIdx{0}, firstRun{true} {};
	virtual ~CmdManager(){};


	// Add Commands to the Command Manager
	void addCommand(const Command_t cmd) {
		commands.push_back(cmd);
	}

	// Get number of commands for this device
	int numberOfCommands() {
		return commands.size();
	}

	// Gets the current command from the list of commands
	Command_t& getCommand()	{
		return commands[cmdIdx];
	}

	// Gets the next command from the list of commands
	// 0 = No repeats
	// 1 = Repeat current command
	// 2 = Go back 1 command and continue down the list
	// 3 = Go back 2 command and continue down the list..., etc
	Command_t& getNextCommand()
	{
		Command_t& cmd = commands[cmdIdx];
		if( cmd.repeat )
		{
			cmdIdx = cmdIdx - cmd.repeat + 1;
			return commands[cmdIdx];
		}

		if( firstRun )
		{
			firstRun = false;
			return cmd;
		}

		cmdIdx++;

		if( (size_t)cmdIdx >= commands.size() )
			cmdIdx = 0;

		return commands[cmdIdx];
	}


	// Commands
	static const Command_t WhoAmI(uint8_t repeat);
	static const Command_t ChangeBank(UserBank bank, uint8_t repeat);
	static const Command_t ReadChangeBank(uint8_t repeat);

	static const Command_t WakeUpIMU(uint8_t);
	static const Command_t ReadRawTemperatureValue(uint8_t repeat);

	static const Command_t ReadFIFOCounter(uint8_t repeat);
	static const Command_t StoreTemperatureValueInFIFO(uint8_t repeat);


	static const Command_t SetIMUConfig(uint8_t repeat);
	static const Command_t ReadIMUConfig(uint8_t repeat);

	static const Command_t SelectAutoClockSource(uint8_t);
	static const Command_t GyroSampleRateDivider(UINT8 srd, uint8_t repeat);
	static const Command_t GyroConfiguration(GyroRange range, GyroDLPFBandwidth bandwidth, uint8_t repeat );

	static const Command_t ReadAccelGyroValues(uint8_t repeat);
	static const Command_t ReadAccelValues(uint8_t repeat);
	static const Command_t ReadGyroValues(uint8_t repeat);

	// DMP commands
	static const Command_t ReadRegInterrupt(uint8_t repeat);
	static const Command_t ReadRegDMPInterrupt(uint8_t repeat);



private:
	int		cmdIdx;
	bool 	firstRun;
	std::vector<Command_t>	commands;

};

#endif /* SRC_PROJECT_IMU_CMDMANAGER_H_ */

