/*
 * ICMManager.cpp
 *
 *  Created on: Apr 16, 2024
 *      Author: Michael.Oleksy
 */

#include "ICMManager.h"
#include <project.hpp>
#include "main.h"

#include <iostream>
#include <sstream>
#include <iomanip>
#include <stdio.h>

extern UART_HandleTypeDef 	huart3;
#define UART_PORT			huart3


char output_data[4096];


//========================================================================================
// Output Quaternion data, either in binary or JSON object
//========================================================================================
void ICMManager::Output_Quaternion_Data(bool ascii_output)
{
	if( ascii_output )
	{
		std::stringstream ss{};

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			// Create a JSON object
			ss << "{" << std::setprecision(6);
			ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)pIMU.getID() << "\"" << std::dec << ", ";
			ss << std::quoted("quat_w") << ":" << std::to_string(pIMU.quat_w) << ", ";
			ss << std::quoted("quat_x") << ":" << std::to_string(pIMU.quat_x) << ", ";
			ss << std::quoted("quat_y") << ":" << std::to_string(pIMU.quat_y) << ", ";
			ss << std::quoted("quat_z") << ":" << std::to_string(pIMU.quat_z) << "}" << "\r\n";
		}

		std::string s = ss.str();
		int len = s.length();

		HAL_StatusTypeDef rc = HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), len, 5000);
		if( rc != HAL_OK )
			rc = HAL_ERROR;
	}
	else
	{
		UINT16 offset = 0;

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			UINT16 id = pIMU.getID();

			memcpy( &output_data[offset], &id, 2);
			offset += 2;

			memcpy( &output_data[offset], &pIMU.quat_w, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.quat_x, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.quat_y, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.quat_z, sizeof(float) );
			offset += sizeof(float);
		}

		output_data[offset++] = '\r';

	   	// Need for UART1 - M.O.
	   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)output_data, offset, 1000);
	}
}


//========================================================================================
// Output Accelerometer data, either in binary or JSON object
//========================================================================================
void ICMManager::Output_Accel_Data(bool ascii_output)
{
	if( ascii_output )
	{
		std::stringstream ss;

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			// Create a JSON object
			ss << "{" << std::setprecision(6);
			ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)pIMU.getID() << "\"" << std::dec << ", ";
			ss << std::quoted("accel_x") << ":" << std::to_string(pIMU.accel_x) << ", ";
			ss << std::quoted("accel_y") << ":" << std::to_string(pIMU.accel_y) << ", ";
			ss << std::quoted("accel_z") << ":" << std::to_string(pIMU.accel_z) << "}\r\n";
		}

		std::string s = ss.str();
	   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);

	}
	else
	{
		UINT16 offset = 0;

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			UINT16 id = pIMU.getID();

			memcpy( &output_data[offset], &id, 2);
			offset += 2;

			memcpy( &output_data[offset], &pIMU.accel_x, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.accel_y, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.accel_z, sizeof(float) );
			offset += sizeof(float);
		}

		output_data[offset++] = '\r';
	   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)output_data, offset, 1000);
	}
}


//========================================================================================
// Output Mag data, either in binary or JSON object
//========================================================================================
void ICMManager::Output_Mag_Data(bool ascii_output)
{
	if( ascii_output )
	{
		std::stringstream ss;

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			// Create a JSON object
			ss << "{" << std::setprecision(6);
			ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)pIMU.getID() << "\"" << std::dec << ", ";
			ss << std::quoted("mag_x") << ":" << std::to_string(pIMU.mag_x) << ", ";
			ss << std::quoted("mag_y") << ":" << std::to_string(pIMU.mag_y) << ", ";
			ss << std::quoted("mag_z") << ":" << std::to_string(pIMU.mag_z) << "}\r\n";
		}

		std::string s = ss.str();
	   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);

	}
	else
	{
		UINT16 offset = 0;

		// Loop through all the devices
		for( auto& pIMU : devices )
		{
			UINT16 id = pIMU.getID();

			memcpy( &output_data[offset], &id, 2);
			offset += 2;

			memcpy( &output_data[offset], &pIMU.mag_x, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.mag_y, sizeof(float) );
			offset += sizeof(float);

			memcpy( &output_data[offset], &pIMU.mag_z, sizeof(float) );
			offset += sizeof(float);
		}

		output_data[offset++] = '\r';
	   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)output_data, offset, 1000);
	}
}


void ICMManager::ASCIIOutput_Position()
{
	std::stringstream ss;

	// Loop through all the devices
	for( auto& pIMU : devices )
	{
		// Create a JSON object
		ss << "{" << std::setprecision(6);
		ss << std::quoted("id") << ":" << "\"" << std::hex << std::setfill('0') << std::setw(4) << std::uppercase << (int)pIMU.getID() << "\"" << std::dec << ", ";
		ss << std::quoted("pos_x") << ":" << std::to_string(pIMU.pos_x) << ", ";
		ss << std::quoted("pos_y") << ":" << std::to_string(pIMU.pos_y) << ", ";
		ss << std::quoted("pos_z") << ":" << std::to_string(pIMU.pos_z) << "}\r";
	}

	std::string s = ss.str();
   	HAL_UART_Transmit(&UART_PORT, (uint8_t*)s.c_str(), s.length(), 1000);
}



