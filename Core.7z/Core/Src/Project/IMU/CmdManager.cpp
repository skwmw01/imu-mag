/*
 * CmdManager.cpp
 *
 *  Created on: Mar 20, 2024
 *      Author: Michael.Oleksy
 */

#include <ICM20948/ICMRegisters.h>
#include "CmdManager.h"


const Command_t CmdManager::ReadRegInterrupt(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = REG_INT_STATUS | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 1,
	};

	return cmd;
}

const Command_t CmdManager::ReadRegDMPInterrupt(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = REG_DMP_INT_STATUS | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 1,
	};

	return cmd;
}


//================================================================
// WHO_AM_I responds with the ICM20948 Identity byte 0xEA
//================================================================
const Command_t CmdManager::WhoAmI(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_WHO_AM_I | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 1,
	};

	return cmd;
}


//================================================================
// Set the IMU configuration
//================================================================
const Command_t CmdManager::SetIMUConfig(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_USER_CTRL,
		.data = UB0_USER_CTRL_DMP_EN | UB0_USER_CTRL_FIFO_EN | UB0_USER_CTRL_SPI_EN,
		.TxDataLen = 2,
		.RxDataLen = 0,
	};

	return cmd;
}


//================================================================
// Read the IMU configuration
//================================================================
const Command_t CmdManager::ReadIMUConfig(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_USER_CTRL | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 1,
	};

	return cmd;
}


const Command_t CmdManager::StoreTemperatureValueInFIFO(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_FIFO_ENABLE_2,
		.data = UB0_FIFO_ENABLE_2_TEMP_FIFO_EN,
		.TxDataLen = 2,
		.RxDataLen = 0,
	};

	return cmd;
}


const Command_t CmdManager::ReadFIFOCounter(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_FIFO_COUNT_H | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 2,
	};

	return cmd;
}



const Command_t CmdManager::WakeUpIMU(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_PWR_MGMNT_1,
		.data = UB0_PWR_MGMNT_1_WAKE_UP,
		.TxDataLen = 2,
		.RxDataLen = 0,
	};

	return cmd;
}

//================================================================
// Change user Bank
//================================================================
const Command_t CmdManager::ChangeBank(UserBank userBank, uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = REG_BANK_SEL,
		.data = static_cast<UINT8>(userBank),
		.TxDataLen = 2,
		.RxDataLen = 0,
	};

	return cmd;
}

//================================================================
// Change user Bank
//================================================================
const Command_t CmdManager::ReadChangeBank(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = REG_BANK_SEL | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 1,
	};

	return cmd;
}



//================================================================
// Select auto clock source
//================================================================
const Command_t CmdManager::SelectAutoClockSource(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_PWR_MGMNT_1,
		.data = UB0_PWR_MGMNT_1_WAKE_UP | UB0_PWR_MGMNT_1_CLOCK_SEL_AUTO,
		.TxDataLen = 2,
		.RxDataLen = 0,
	};

	return cmd;
}

//==================================================================
// sample rate divider - default is 0
// 1.1 kHz/(1+SRD)
//==================================================================
const Command_t CmdManager::GyroSampleRateDivider(UINT8 srd, uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB2_GYRO_SMPLRT_DIV,
		.data = srd,
		.TxDataLen = 2,
		.RxDataLen = 0,
	};
	return cmd;
}

//==================================================================
//==================================================================
const Command_t CmdManager::GyroConfiguration(GyroRange range, GyroDLPFBandwidth bandwidth, uint8_t repeat )
{
	UINT8 gyroConfigRegValue = 0x00;
	float gyroScale = 0;

	switch(range)
	{
		case GyroRange::GYRO_RANGE_250DPS: {
			gyroConfigRegValue = UB2_GYRO_CONFIG_1_FS_SEL_250DPS;
			gyroScale = 250.0f / gyroRawScaling * degToRad;	 	// setting the gyro scale to 250DPS
			break;
	    }

	    case GyroRange::GYRO_RANGE_500DPS: {
	    	gyroConfigRegValue = UB2_GYRO_CONFIG_1_FS_SEL_500DPS;
	    	gyroScale = 500.0f / gyroRawScaling * degToRad; 	// setting the gyro scale to 500DPS
	    	break;
	    }

	    case GyroRange::GYRO_RANGE_1000DPS: {
	    	gyroConfigRegValue = UB2_GYRO_CONFIG_1_FS_SEL_1000DPS;
	    	gyroScale = 1000.0f/gyroRawScaling * degToRad; 		// setting the gyro scale to 1000DPS
	    	break;
	    }

	    case GyroRange::GYRO_RANGE_2000DPS: {
	    	gyroConfigRegValue = UB2_GYRO_CONFIG_1_FS_SEL_2000DPS;
	    	gyroScale = 2000.0f/gyroRawScaling * degToRad; 		// setting the gyro scale to 2000DPS
	    	break;
	    }
	}

	UINT8 DLPFRegValue = 0x00;

	switch(bandwidth)
	{
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_12106HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_12106HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_197HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_197HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_152HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_152HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_120HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_120HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_51HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_51HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_24HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_24HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_12HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_12HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_6HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_6HZ; break;
		case GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_361HZ: DLPFRegValue = UB2_GYRO_CONFIG_1_DLPFCFG_361HZ; break;
	}

	const Command_t cmd = {
		.repeat = repeat,
		.address = UB2_GYRO_CONFIG_1,
		.data = (UINT8)(gyroConfigRegValue | DLPFRegValue),
		.TxDataLen = 2,
		.RxDataLen = 0,
	};
	return cmd;

	//_gyroScale = gyroScale;
	//_gyroRange = range;
	//_gyroBandwidth = bandwidth;
}


//==================================================================
// Read Accelerometer and Gyro values
//==================================================================
const Command_t CmdManager::ReadAccelGyroValues(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_ACCEL_XOUT_H | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 12,
	};
	return cmd;
}

//==================================================================
// Read Accelerometer values
// Accel: X[16].Y[16].Z[16]
//==================================================================
const Command_t CmdManager::ReadAccelValues(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_ACCEL_XOUT_H | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 6,
	};

	return cmd;
}


//==================================================================
// Read Gyro values
//==================================================================
const Command_t CmdManager::ReadGyroValues(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_GYRO_XOUT_H | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 6,
	};

	return cmd;
}


//==================================================================
// Read Temperature value
//==================================================================
const Command_t CmdManager::ReadRawTemperatureValue(uint8_t repeat)
{
	const Command_t cmd = {
		.repeat = repeat,
		.address = UB0_TEMPERATURE_ZOUT_H | ICM20948_READ_OP,
		.data = 0,
		.TxDataLen = 1,
		.RxDataLen = 2,
	};

	return cmd;
}


//imu1->addCommand( CmdManager::WakeUpIMU(false) );
//imu1->addCommand( CmdManager::SetIMUConfig(false) );
//imu1->addCommand( CmdManager::SelectAutoClockSource(false) );

//imu1->addCommand( CmdManager::ChangeBank(UserBank::USER_BANK_2, false) );
//imu1->addCommand( CmdManager::GyroSampleRateDivider(0, false) );
//imu1->addCommand( CmdManager::GyroConfiguration(GyroRange::GYRO_RANGE_2000DPS, GyroDLPFBandwidth::GYRO_DLPF_BANDWIDTH_197HZ, false) );

//imu1->addCommand( CmdManager::ChangeBank(UserBank::USER_BANK_0, false) );
//imu1->addCommand( CmdManager::ReadGyroValues(false) );
//imu1->addCommand( CmdManager::ReadRawTemperatureValue(true) );

//imu1->addCommand( CmdManager::StoreTemperatureValueInFIFO(false) );
//imu1->addCommand( CmdManager::ReadFIFOCounter(true) );


