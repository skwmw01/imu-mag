/*
 * CommandState.h
 *
 *  Created on: Apr 10, 2024
 *      Author: Michael.Oleksy
 */

#ifndef _COMMANDSTATE_H_
#define _COMMANDSTATE_H_


enum class CommandState {
	STATE_CMD_IDLE,
	STATE_CMD_PENDING,
	STATE_CMD_PROCESSING,
	STATE_CMD_COMPLETE,
};


#endif /* _COMMANDSTATE_H_ */
