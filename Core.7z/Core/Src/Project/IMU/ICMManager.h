/*
 * IMUDevices.h
 *
 *  Created on: Mar 13, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_IMUMANAGER_H_
#define SRC_PROJECT_IMUMANAGER_H_

#include <vector>
#include <iostream>


#include "project.hpp"
#include "ICM20948/ICM20948.hpp"



class ICMManager
{
private:
	UINT8					currentIdx;
	std::vector<ICM20948>	devices;


public:
	ICMManager() : currentIdx{0} {}
	~ICMManager() {}

	// Concatenate output from all IMUs
	void Output_Quaternion_Data(bool ascii_output);
	void Output_Accel_Data(bool ascii_output);
	void Output_Mag_Data(bool ascii_output);

	void ASCIIOutput_Position();


	// Return a reference to an IMU based on given ID
	ICM20948* getIMUusingID(UINT16 id)
	{
		for( UINT8 i=0 ; i<devices.size() ; i++ )
		{
			if( devices[i].getID() == id )
				return &devices[i];
		}
		return nullptr;
	}

	// Return a reference to an IMU based on given ID
	ICM20948* getIMUusingIndex(UINT8 idx)
	{
		return &devices[idx];
	}

	// Add ICM's to the Manager
	void addIMU(ICM20948* imu) {
		devices.push_back(*imu);
	}

	// Get a reference to the IMU array
	std::vector<ICM20948>& getDevices() {
		return devices;
	}

	// Get number of devices
	int numberOfDevices() {
		return devices.size();
	}

	// Set processed as false on all IMUs
	inline void clearProcessFlag()
	{
		for( UINT8 i=0 ; i<devices.size() ; i++ )
		{
			devices[i].setProcessed(false);
		}
	}

	// Set index.
	// This is needed because once we start outputting data, we will cycle through the devices.
	void setIndex(int index) {
		currentIdx = index;
	}

	// Set device index
	ICM20948* getIMUatIndex(int index)
	{
		if( index < 0 || index >= (int)devices.size() )
			currentIdx = 0;
		else
			currentIdx = index;

		return &devices[currentIdx];
	}

	// This method gets the next IMU from the list of IMUs
	ICM20948* getNextIMU(void)
	{
		currentIdx++;

		if( currentIdx >= devices.size() )
			currentIdx = 0;

		return &devices[currentIdx];
	}

	// This method gets the current IMU from the list of IMUs
	ICM20948* getCurrentIMU(void)
	{
		return &devices[currentIdx];
	}
};



#endif /* SRC_PROJECT_IMUMANAGER_H_ */
