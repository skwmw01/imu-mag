/*
 * MyMain.cpp
 *
 *  Created on: Mar 7, 2024
 *      Author: Michael.Oleksy
 */
#include <IMU/ICMManager.h>
#include <iostream>
#include <vector>
#include <memory>

#include "main.h"



#include <SPIBlock.hpp>
#include <SPIInt.hpp>
#include "SPIComms/SPIPort.h"
#include "Debug/DebugLog.h"

#include "ICM20948.h"
#include "ICM20948LoadFirmware.h"
#include "ICM20948AuxCompassAkm.h"
#include "ICM20948Defs.h"
#include "system.h"
#include "sensor.h"
#include "SPIComms/SPImain.h"

#include "IMU/ICMManager.h"

using namespace std;

// STM32 SPI handle
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef hspi3;

extern UART_HandleTypeDef huart3;
extern TIM_HandleTypeDef htim16;
extern TIM_HandleTypeDef htim2;



//__SPI_HandleTypeDef* SPIDevice::instances[1] = {&hspi1};

// We need to call the MyMain.cpp file from the STM32CubeIDE generated main.c file.
// We need to ensure the C++ file does not get name mangled, so we use 'extern "C"'.
// This way, MyMain function can get called from C, and we can use C++ code.
#ifdef __cplusplus
extern "C" {
#endif

#include "sensor.h"

#include "SPIManager.h"
#include "Timer.h"
#include "SystemTicker.h"


// Wireless
#include "wireless_detect.h"
#include "wireless_imu.h"


UINT32 system_millisecond_ticker = 0;

// Global SPI ports
std::vector<SPIPort*> SPIPorts;

// From SPIManager
extern UINT8 NUMBER_OF_SPI_PORTS;

extern char output_data[];


extern int spi_write_block(void* ctx, uint8_t reg_address, const uint8_t* pData, uint32_t len);
extern int spi_read_block(void* ctx, uint8_t reg_address, uint8_t* pData, uint32_t len);


bool __log_enabled;



void MyMainCPP()
{
	Timer::resetTimer();
	Timer::sleep_ms(2000);

	// Setup the ESP32 wireless comms
	Wireless_IMUScript();

	// Setup and configure the IMUs
	SPIManager_SPIManager();
	Timer::sleep_ms(500);


	bool use_5_grouping = true;
	bool use_spi_grouping = false;

	// Raw commands
	if( use_spi_grouping )
	{
		while(true)
		{
			for( UINT8 port=0 ; port<NUMBER_OF_SPI_PORTS ; port++ )
				SPIPorts[port]->Execute_SPI_Ports();
		}
	}



	if( use_5_grouping )
	{
		while(true)
		{
			UINT16 currentBitmap = 0;

			for( UINT8 port=0 ; port<NUMBER_OF_SPI_PORTS ; port++ )
			{
				SPIPorts[port]->Execute_Group_Of_Five();
				currentBitmap |= SPIPorts[port]->getBitmap();
			}


			for( UINT8 port=0 ; port<NUMBER_OF_SPI_PORTS ; port++ )
			{
				if( (currentBitmap & imuBitmapGrouping[port]) == imuBitmapGrouping[port] )
				{
					UINT16 len = 0;
					char* ptrBuffer = &output_data[0];

					// Get data from 5 IMUs
					for( UINT8 i=0 ; i<IMUS_IN_GROUP ; i++ )
					{
						imuHardwareGroup_t* ptr = &imuHardwareGrouping[port][i];
						ICM20948* imu = SPIPorts[ptr->spiIndex]->IMUManager().getIMUusingIndex(ptr->imuIndex);

						// Outpus binary data
						len += imu->construct_BINARY_IMU_Data_Packet( &ptrBuffer );

						// Outputs ASCII data
						//len += imu->construct_ASCII_IMU_Data_Packet( &ptrBuffer );

						SPIPorts[ptr->spiIndex]->clearBitmap(~ptr->id);
						imu->setProcessed(false);
					}
					HAL_UART_Transmit(&huart3, (uint8_t*)output_data, len, 1000);
				}
			}
		}
	}
}

#ifdef __cplusplus
}
#endif

