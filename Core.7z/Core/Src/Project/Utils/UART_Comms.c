/*
 * UART_Comms.c
 *
 *  Created on: May 10, 2024
 *      Author: Michael.Oleksy
 */


#include "UART_Comms.h"

char data[100];

// Called whenever the UART TX has completed
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	//HAL_UART_Transmit(&huart3, (const uint8_t*)"--\r\n", 4, 500);

	HAL_UART_Receive_IT(&huart3, (uint8_t *)data, 30);
}


// Called whenever the UART RX has completed
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	HAL_UART_Transmit(&huart3, (const uint8_t*)"RCV", 3, 500);
	//UARTPort.receive_buffer_length += huart->RxXferCount;
}
