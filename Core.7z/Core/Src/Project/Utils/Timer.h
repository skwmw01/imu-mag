/*
 * Timer.h
 *
 *  Created on: May 9, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_UTILS_TIMER_H_
#define SRC_PROJECT_UTILS_TIMER_H_

#include "project.hpp"

//#ifdef __cplusplus
//extern "C" {
//#endif
//


// This Timer is setup in hardware to tick every 1us (1000 times every 1ms)
class Timer
{
public:
	//this is a singleton
	static Timer* Instance();
	virtual ~Timer(){};

	// Do not want these constructors
	Timer(const Timer&) = delete;
	Timer& operator=(const Timer&) = delete;

	static void resetTimer();
	static UINT32 getCurrentTick();
	static void setCurrentTick(UINT32 value);

	static void sleep_us(UINT32 value_in_ms);
	static void sleep_ms(UINT32 value_in_ms);


private:
	Timer() {}
};

//#ifdef __cplusplus
//}
//#endif


#endif /* SRC_PROJECT_UTILS_TIMER_H_ */
