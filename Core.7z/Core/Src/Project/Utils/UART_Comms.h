/*
 * UART_Comms.h
 *
 *  Created on: May 10, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_UTILS_UART_COMMS_H_
#define SRC_PROJECT_UTILS_UART_COMMS_H_

#include "project.hpp"
#include "main.h"


extern UART_HandleTypeDef huart3;



UINT8	uart_tx_buffer[512];
UINT8	uart_rx_buffer[512];


typedef struct bus_buffer_configuration_s
{
	UINT8* 	transmit_buffer;
	UINT16	transmit_buffer_length;
	UINT8* 	receive_buffer;
	UINT16	receive_buffer_length;
} bus_buffer_config_t;


typedef struct cdi_usart_full_duplex_configuration_item_s
{
	UINT8* 	transmit_buffer;
	UINT16	transmit_buffer_length;
	UINT8* 	receive_buffer;
	UINT16	receive_buffer_length;
} CDI_UART_ITEM_t;


CDI_UART_ITEM_t UARTPort =
{
	uart_tx_buffer, 0, uart_rx_buffer, 0
};







#endif /* SRC_PROJECT_UTILS_UART_COMMS_H_ */
