/*
 * SystemTicker.c
 *
 *  Created on: May 10, 2024
 *      Author: Michael.Oleksy
 */
#include "project.hpp"


extern UINT32 system_millisecond_ticker;



//extern __IO uint32_t uwTick;
//

/**
  * @brief 	This function is called to increment a global variable "uwTick" used as application time base.
  * @note 	In the default implementation, this variable is incremented each 1ms in SysTick ISR.
 * @note This function is declared as __weak to be overwritten in case of other
  *      implementations in user file.
  * @retval None
  */
//void HAL_IncTick(void)
//{
//  uwTick += (uint32_t)uwTickFreq;
//  system_millisecond_ticker++;
//}
