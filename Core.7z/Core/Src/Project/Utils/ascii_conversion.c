//============================================================================================
//
//  Rex Bionics
//
//  Author  :  Michael Oleksy
//  Created :  6 December 2023
//
//============================================================================================
#include <Utils/ascii_conversion.h>
#include "project.hpp"


static UINT8 convertToASCII(UINT8 c)
{
	// Check for number [0..9]
	if( c >= 0 && c <= 9 )
		return c + 0x30;

	// Check for character [A..F] or [a..f]
	if( c >= 10 && c <= 15 )
		return c - 10 + 'A';

	// This should not happen
	return 0;
}



//=================================================================================================================
// HEXToASCII
//
// HEX = 9F.7A.42...
// ASCII = 39.46.37.41.34.32... = "9F7A42..."
// - Converts hex bytes into a displayable ASCII string
//
// Note: Destination buffer must be twice as big as the Source buffer.
//=================================================================================================================
void HEXToASCII( UINT8* ptrSrc, UINT16 srcLen, UINT8* ptrDst, UINT16* dstLen )
{
	UINT8	c;
	UINT16	dstIndex = 0;


	for( UINT16 i=0 ; i<srcLen ; i++ )
	{
		c = *(ptrSrc + i) >> 4;
		*(ptrDst + dstIndex++) = convertToASCII(c);

		c = *(ptrSrc + i) & 0x0F;
		*(ptrDst + dstIndex++) = convertToASCII(c);
	}
	*dstLen = dstIndex;
}


