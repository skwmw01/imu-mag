#include "sha1.h"

#define LITTLE_ENDIAN


//************************************************************************
// CASTS
//************************************************************************
#define CAST_UINT8(x)  ((UINT8) ((x) & 0xFF))
#define CAST_UINT16(x) ((UINT16)((x) & 0xFFFF))
#define CAST_UINT32(x) ((UINT32)((x) & 0xFFFFFFFF))

#define ENDIAN_SWAP_32(_x_) CAST_UINT32( ((_x_)>>24) |		\
    (((_x_) << 8) & 0x00FF0000) | 	\
    (((_x_) >> 8) & 0x0000FF00) | 	\
    ((_x_) << 24))


#if defined(CFG_OPTIMIZE_FOR_SPEED) && !defined(LITTLE_ENDIAN)
    #define ConfigureBigEndian(x,y)
#else
    // No Need to call this for Big Endain platforms as this won't do anything
    // but will still loop thru the entire buffer.
    static void ConfigureBigEndian(UINT32* buf, UINT8 buf_len)
    {
        for (UINT8 i = 0; i<buf_len; i++)
            buf[i] = ENDIAN_SWAP_32(buf[i]);
    }
#endif



static UINT32 Transform(UINT32* w)
{
	UINT32 w_expand;

    w_expand = S1(w[13]^w[8]^w[2]^w[0]);
    memcpy((void*)&w[0], (void*)&w[1], (SHA_BLOCKSIZE-4));
    w[15] = w_expand;

    return w_expand;
}

#ifdef CFG_FAST_SHA

#define DoRest()            \
e = d;                      \
d = c;                      \
c = S30(b);                 \
b = a;                      \
a = temp;

#endif

static void ProcessMessageBlock(SHA1_Type* context)
{
    UINT8 i = 0;
#ifndef CFG_FAST_SHA
    UINT8 j;
#endif
    UINT32* w;
    UINT32 temp = 0;
    UINT32 a, b, c, d, e;

    a = context->digest[0];
    b = context->digest[1];
    c = context->digest[2];
    d = context->digest[3];
    e = context->digest[4];

    w = (UINT32*)context->buf;
    ConfigureBigEndian(w, SHA_BLOCKSIZE/4);

#ifdef CFG_FAST_SHA
    // removes unnessary IF and SWITCH checks for each itteration

    for(; i < 16; i++)
    {
        temp = w[i];
        temp = S5(a) + F1(b, c, d) + e + temp + K1;
        DoRest();
    }

    for (; i < 20; i++)
    {
        temp = Transform(w);
        temp = S5(a) + F1(b, c, d) + e + temp + K1;
        DoRest();
    }

    for (; i < 40; i++)
    {
        temp = Transform(w);
        temp = S5(a) + F2(b, c, d) + e + temp + K2;
        DoRest();
    }

    for (; i < 60; i++)
    {
        temp = Transform(w);
        temp = S5(a) + F3(b, c, d) + e + temp + K3;
        DoRest();
    }

    for (; i < 80; i++)
    {
        temp = Transform(w);
        temp = S5(a) + F4(b, c, d) + e + temp + K4;
        DoRest();
    }
#else
    for (i=0; i<80; i++)
    {
        if (i<16)
            temp = w[i];
        else
            temp = Transform(w);

        j = i/20;
        switch (j)
        {
            case 0:
                temp = S5(a) + F1(b,c,d) + e + temp + K1;
                break;

            case 1:
                temp = S5(a) + F2(b,c,d) + e + temp + K2;
                break;

            case 2:
                temp = S5(a) + F3(b,c,d) + e + temp + K3;
                break;

            case 3:
                temp = S5(a) + F4(b,c,d) + e + temp + K4;
                break;
        }

        e = d;
        d = c;
        c = S30(b);
        b = a;
        a = temp;
    }
#endif

    context->digest[0] += a;
    context->digest[1] += b;
    context->digest[2] += c;
    context->digest[3] += d;
    context->digest[4] += e;
}

//========================================================================
// SHA1_Init
//========================================================================
void SHA1_Init(SHA1_Type* context)
{
    context->digest[0] = H0;
    context->digest[1] = H1;
    context->digest[2] = H2;
    context->digest[3] = H3;
    context->digest[4] = H4;
    context->count = 0;
    memset(context->buf, 0, SHA_BLOCKSIZE);
}


//========================================================================
// SHA1_Update
//========================================================================
void SHA1_Update(SHA1_Type* context, const UINT8* message, UINT32 message_len)
{
    UINT8 offset;
    UINT32 i;

    offset = context->count & 0x3F;
    context->count += message_len;

    for (i=0; i<message_len; i++)
    {
        context->buf[offset++] = message[i];
        if (offset == SHA_BLOCKSIZE)
        {
            ProcessMessageBlock(context);
            offset = 0;
        }
    }
}

//========================================================================
// SHA1_GenerateHash
//========================================================================
void SHA1_GenerateHash(SHA1_Type* context, UINT8* hash)
{
    UINT8 pad_count;
    UINT32 total_bytes = context->count;
#ifndef CFG_FAST_SHA
    UINT8 i;
    UINT32 block;
#endif

    pad_count = total_bytes & 0x3F;
    context->buf[pad_count++] = 0x80;

    if (pad_count > 56)
    {
        memset(context->buf + pad_count, 0x00, (SHA_BLOCKSIZE - pad_count));
        ProcessMessageBlock(context);
        pad_count = 0;
    }

    memset(context->buf + pad_count, 0x00, (SHA_BLOCKSIZE - pad_count));
    // append the bit length
    total_bytes = ENDIAN_SWAP_32(total_bytes * 8);
    memcpy(context->buf + SHA_BLOCKSIZE - sizeof(total_bytes), &total_bytes, sizeof(total_bytes));

    ProcessMessageBlock(context);

#ifndef CFG_FAST_SHA
	for (i = 0; i < 5; i++)
    {
        block = context->digest[i];
        hash[4 * i]     = CAST_UINT8(block >> 24);
        hash[4 * i + 1] = CAST_UINT8(block >> 16);
        hash[4 * i + 2] = CAST_UINT8(block >> 8);
        hash[4 * i + 3] = CAST_UINT8(block);
    }
#else
    #ifdef LITTLE_ENDIAN
        BUF_WRITE_UINT32((UINT8*)(((UINT32*)hash) + 0), 0, context->digest[0]);
        BUF_WRITE_UINT32((UINT8*)(((UINT32*)hash) + 1), 0, context->digest[1]);
        BUF_WRITE_UINT32((UINT8*)(((UINT32*)hash) + 2), 0, context->digest[2]);
        BUF_WRITE_UINT32((UINT8*)(((UINT32*)hash) + 3), 0, context->digest[3]);
        BUF_WRITE_UINT32((UINT8*)(((UINT32*)hash) + 4), 0, context->digest[4]);
    #else
        ((UINT32*)hash)[0] = context->digest[0];
        ((UINT32*)hash)[1] = context->digest[1];
        ((UINT32*)hash)[2] = context->digest[2];
        ((UINT32*)hash)[3] = context->digest[3];
        ((UINT32*)hash)[4] = context->digest[4];
    #endif
#endif
}

