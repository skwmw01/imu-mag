// Rex Bionics Ltd (c) Copyright 2015
#ifndef __UTILS_H
#define __UTILS_H

#include "project.hpp"

// Converts a hex binary buffer into displayable ASCII
void HEXToASCII( UINT8* ptrSrc, UINT16 srcLen, UINT8* ptrDst, UINT16* dstLen );


#endif
