/*
 * Timer.cpp
 *
 *  Created on: May 9, 2024
 *      Author: Michael.Oleksy
 */

#include <Timer.h>
#include "main.h"

extern TIM_HandleTypeDef htim16;
extern TIM_HandleTypeDef htim2;

#ifdef __cplusplus
extern "C" {
#endif


//===================================================================
// Wrapper functions
//===================================================================
uint64_t wrapper_Timer_get_us()
{
	return (uint64_t)(Timer::getCurrentTick());
}

void wrapper_Timer_sleep_us(int us)
{
	Timer::sleep_us((UINT32)us);
}







//===================================================================
// Timer Singleton
//===================================================================
Timer* Timer::Instance()
{
	static Timer instance;
	return &instance;
}

void Timer::resetTimer()
{
	__HAL_TIM_SET_COUNTER(&htim2, 0);
}

// Timer is setup to tick every 1us.
UINT32 Timer::getCurrentTick()
{
	return __HAL_TIM_GET_COUNTER(&htim2);
}


void Timer::setCurrentTick(UINT32 value)
{
	__HAL_TIM_SET_COUNTER(&htim2, value);
}


void Timer::sleep_us(UINT32 value_in_us)
{
	UINT32 start_time = __HAL_TIM_GET_COUNTER(&htim2);
	UINT32 end_time = value_in_us;

	// Wait for duration
	while(1)
	{
		if (__HAL_TIM_GET_COUNTER(&htim2) - start_time >= end_time)
			break;
	}
}

// This Timer is setup in hardware to tick every 1us (1000 times every 1ms)
// So 1s = 1,000,000 ticks.  Multiply value by 1000 to get ms duration.
void Timer::sleep_ms(UINT32 value_in_ms)
{
	UINT32 start_time = __HAL_TIM_GET_COUNTER(&htim2);
	UINT32 end_time = value_in_ms * 1000;

	while(!(__HAL_TIM_GET_COUNTER(&htim2) - start_time >= end_time));
}


#ifdef __cplusplus
}
#endif
