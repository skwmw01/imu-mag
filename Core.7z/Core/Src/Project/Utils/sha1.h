#ifndef SHA1_H
#define SHA1_H


//#include "logging.h"
#include <string.h>
#include "project.hpp"
// typedef uint8_t		UINT8;
// typedef uint16_t	UINT16;
// typedef uint32_t	UINT32;


/**
 * @file sha1.h
 * @brief SHA1 hash support.
 *
 * Used for calculating SHA1 hashes.
 */

// Rotate left and right macros
#define ROTL(X,N)    (((X) << N) | ((X) >> (32-N)))
#define ROTR(X,N)    (((X) >> N) | ((X) << (32-N)))

// Circular shift marcos
#define  S1(X)    ROTL(X,1)
#define  S5(X)    ROTL(X,5)
#define  S30(X)    ROTR(X,2)

// The SHS functions
#define  F1(X,Y,Z)    ((X & Y) | ((~X) & Z))            // Rounds  0-19
#define  F2(X,Y,Z)    (X ^ Y ^ Z)                        // Rounds 20-39
#define  F3(X,Y,Z)    ((X & Y) | (X & Z) | (Y & Z))    // Rounds 40-59
#define  F4(X,Y,Z)    (X ^ Y ^ Z)                        // Rounds 60-79

// The SHS Constants
#define K1 0x5A827999    // Rounds    0-19
#define K2 0x6ED9EBA1    // Rounds   20-39
#define K3 0x8F1BBCDC    // Rounds   40-59
#define K4 0xCA62C1D6    // Rounds   60-79

// The initial hash values
#define H0 0x67452301L
#define H1 0xEFCDAB89L
#define H2 0x98BADCFEL
#define H3 0x10325476L
#define H4 0xC3D2E1F0L

// The SHA block size and message digest sizes, in bytes
#define SHA_BLOCKSIZE       64U
#define SHA_DIGESTSIZE      20U

/**
* @brief The SHA1 context.
*/
typedef struct
{
    UINT32 digest[SHA_DIGESTSIZE/4];    /**< Message digest, (160 bit digest size divided by 4) */
    UINT8  buf[SHA_BLOCKSIZE];          /**< SHA data buffer, (512 bit message block) */
    UINT32 count;                       /**< Total byte count */
} SHA1_Type;


/**
 * @brief Initialise SHA1 operation.
 *
 * Reset the message digest and load the initial hash values.
 *
 * @param[out] context - Reference to the initial hash context.
 *
 * @return void
 */
void SHA1_Init(SHA1_Type* context);

/**
 * @brief Update the current SHA1 message digest.
 *
 * Add the hash of more message data to the current message digest.
 *
 * @param[in,out] context - Reference to the context of the current hash operation.
 * @param[in] message - Reference to the data to add to the current hash.
 * @param[in] message_len  - Length of the data.
 *
 * @return void
 */
void SHA1_Update(SHA1_Type* context, const UINT8* message, UINT32 message_len);

/**
 * @brief Generate the SHA1 hash.
 *
 * Finalises the message digest by hashing the remaining data given.
 *
 * @param[in,out] context - Reference to the context of the current hash operation.
 * @param[out] hash - Reference to the generated SHA1 hash.
 *
 * @return void
 */
void SHA1_GenerateHash(SHA1_Type* context, UINT8* hash);



#endif

