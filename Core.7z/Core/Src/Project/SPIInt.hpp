/*
 * SPIInt.hpp
 *
 *  Created on: Mar 8, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_SPIINT_HPP_
#define SRC_PROJECT_SPIINT_HPP_

#include <project.hpp>
#include "main.h"


// When using SPI with interrupts, remember to enable the Interrupt setting in the .ioc file
class SPIInt
{
public:
	SPIInt(SPI_HandleTypeDef hspi);
	virtual ~SPIInt();

	int SendData(UINT8* srcBuffer, UINT16 len);
	int ReceiveData(UINT8* dstBuffer, UINT16 len);

	void setCSHigh();
	void setCSLow();

private:
	SPI_HandleTypeDef spiHandle;
};


#endif /* SRC_PROJECT_SPIINT_HPP_ */
