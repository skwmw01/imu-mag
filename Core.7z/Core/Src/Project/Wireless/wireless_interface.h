// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_INTERFACE_H
#define __WIRELESS_INTERFACE_H

#include "wireless_detect.h"
//#include "rexlink/manager_pc_comms.h"
//#include "rexlink/pcc_data_fetcher.h"
//#include "forward.h"


//=======================================================================================================
//
// This will setup the wireless interface module.
//
//=======================================================================================================

// What wireless interface is being used by the hardware module
typedef enum
{
	INTERFACE_NONE,
	INTERFACE_BT,
	INTERFACE_ESP32_BT,
	INTERFACE_ESP32_WIFI,
} PACK active_interface_t;


//=====================================================
// Active Interface (BT or WiFi)
//=====================================================
bool Wireless_isInterface(active_interface_t usingInterface);
void Wireless_setActive(active_interface_t usingInterface);
bool Wireless_isActive(active_interface_t usingInterface);


#endif
