// Rex Bionics Ltd (c) Copyright 2023
//#include "cool_typedefs.h"
//#include "managers/manager_user_interface.h"
#include "wireless_bt_mac.h"
#include <string.h>


// SSID storage buffers
static UINT8 BT_Name[BT_BASE_NAME_LEN] = {0};
static UINT8 BT_Code[BT_BASE_CODE_LEN] = {0};
static bool BT_valid = false;


// Creates the text that is displayed on the UI
void Wireless_getBT_UI_Message(char* store)
{
	// Store the new code in m_ui
	memcpy( &store[0], BT_CODE_UI_MSG, BT_CODE_UI_MSG_LEN );
	memcpy( &store[BT_CODE_UI_MSG_LEN], Wireless_getBTCode(), BT_BASE_CODE_LEN );
	store[BT_UI_MESSAGE_LEN-1] = 0;
}


// Set the Bluetooth name
void Wireless_setBTName(UINT8* ssid) {
	memcpy( &BT_Name[0], ssid, BT_BASE_NAME_LEN );
}


// Return pointer to the full Bluetooth name
UINT8* Wireless_getBTName(void) {
	return &BT_Name[0];
}


// Getter and Setter for BT code
void Wireless_setBTCode(UINT8* code)
{
	memcpy( &BT_Code[0], code, BT_BASE_CODE_LEN );

	// Capitalise the code
	for( int i=0 ; i<BT_BASE_CODE_LEN ; i++)
		BT_Code[i] = (BT_Code[i] >= 0x61 && BT_Code[i] <= 0x66) ? (BT_Code[i] - 0x20) : BT_Code[i];
}


UINT8* Wireless_getBTCode(void) {
	return BT_Code;
}


// Sets valid to true if the BT Name and Code has been created
// It is set to false when wireless module is powered on.
bool Wireless_isBTValid(void) {
	return BT_valid;
}

void Wireless_setBTValid(bool value) {
	BT_valid = value;
}


