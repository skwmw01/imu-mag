/*
 * wireless_imu.c
 *
 *  Created on: May 10, 2024
 *      Author: Michael.Oleksy
 */

#include "wireless_lib.h"


void Wireless_IMUScript()
{
	// Hangup
	Wireless_setBlockingTimeOut(10);
	Wireless_SendATCommand("+++");
	Wireless_setBlockingTimeOut(10);

	// AT
	for( int i=0 ; i<3 ; i++ )
	{
		Wireless_SendATCommand("AT\r\n");
		Wireless_setBlockingTimeOut(200);
	}

	// Reset ESP32
	Wireless_SendATCommand("AT+RST\r\n");
	Wireless_setBlockingTimeOut(1500);

	// Setup ESP32 wireless as SoftAP
	Wireless_SendATCommand("AT+CWMODE=2,0\r\n");
	Wireless_setBlockingTimeOut(70);

	// Set the module IP address
	Wireless_SendATCommand("AT+CIPAP=\"192.168.10.1\"\r\n");
	Wireless_setBlockingTimeOut(70);

	// SSID, no password, channel, encryption (0=no encryption), max-conn, Broadcasting (0=broadcasting SSID, 1 = not broadcasting)
	Wireless_SendATCommand("AT+CWSAP=\"IMU SYSTEM V1.0.1\",\"\",5,0,1,0\r\n");
	Wireless_setBlockingTimeOut(70);

	// Remote IP, Remote Port, Local Port, Keep Alive
	Wireless_SendATCommand("AT+CIPSTART=\"UDP\",\"192.168.10.2\",49200,49300,0\r\n");
	Wireless_setBlockingTimeOut(70);

	// Enter the UART Wi-Fi Passthrough Receiving Mode.
	Wireless_SendATCommand("AT+CIPMODE=1\r\n");
	Wireless_setBlockingTimeOut(70);

	// Enter the UART Wi-Fi Passthrough Receiving Mode.
	Wireless_SendATCommand("AT+CIPSEND\r\n");
	Wireless_setBlockingTimeOut(70);
}
