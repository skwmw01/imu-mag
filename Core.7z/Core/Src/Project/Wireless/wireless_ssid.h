// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_SSID_H
#define __WIRELESS_SSID_H

//#include "rexlink/manager_pc_comms.h"
//#include "forward.h"
#include "project.hpp"


// Sets the name of the WiFi device
#define WIFI_BASE_SSID_NAME		"REX-WIFI-XXXX"		// 13
#define WIFI_SSID_NAME_LEN		13					// Length of WIFI_BASE_SSID_NAME
#define WIFI_SSID_CODE_OFFSET	9					// The offset in WIFI_BASE_SSID_NAME where the code starts
#define WIFI_SSID_CODE_LEN		4					// XXXX - any 4-nibble hexadecimal number

// Message displayed on UI: 'WIFI CODE: xxxx"
#define WIFI_CODE_UI_MSG 		"WIFI CODE: "
#define WIFI_CODE_UI_MSG_LEN 	11

// Used to create buffer storage space in UI struct
#define WIFI_UI_MESSAGE_LEN		WIFI_CODE_UI_MSG_LEN + WIFI_SSID_CODE_LEN + 1


void 	Wireless_createUniqueSSID(void);

void	Wireless_getWiFi_UI_Message(char*);
bool	Wireless_isSSIDValid(void);
void	Wireless_setSSIDValid(bool value);

void	Wireless_setSSIDName(UINT8* ssidName);
UINT8* 	Wireless_getSSIDName(void);

void 	Wireless_setSSIDCode(UINT8* code);
UINT8* 	Wireless_getSSIDCode(void);


#endif
