// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_CONFIG_H
#define __WIRELESS_CONFIG_H

//===========================================================================================================
// The class will determine which module is connected to the Rex by issuing a 'version' command.
// Once the module type is known (ESP32 or BT740), the module will be initialised and configured.
//
// The modules need to be queried.
// - In order to achieve this, we need the ability to send AT-commands to the module and be able to
//   receive responses from it.  When the Rex powers up, the default setup of the UART communicating
//   with the module is to send and receive message packets. It does not cater for AT-commands.
//
// - It is therefore necessary to be able to stop message packets from being sent when AT commands
//   need to be issued, as the two will intefere with each other.
//
//===========================================================================================================
//#include "rexlink/manager_pc_comms.h"
//#include "rexlink/pcc_data_fetcher.h"
//#include "forward.h"
#include "project.hpp"

#ifdef __cplusplus
extern "C" {
#endif


// Response from module after sending an AT-command
typedef enum module_response_e
{
	RESP_OK = 1,			// 'OK' response from module
	RESP_ERROR,				// 'ERROR' response from module
	RESP_CONNECT,			// 'CONNECT' response from module
	RESP_READY,				// 'ready' response from module (after module reset)
	RESP_UNKNOWN,			// Unknown response from module
	RESP_NEXT,				// Not a response from the wireless module. This is an indicator to proceed to next command in script.
	RESP_RUN_CODE,			// Not a response from the wireless module. This is an indicator to execute some specific code (like hangup)
	RESP_NULL,
}module_response_t;


// Available Wireless Hardware Modules
typedef enum wireless_hardware_e
{
	HARDWARE_NONE		= 0,
	HARDWARE_ESP32		= 1 << 1,
	HARDWARE_BT740		= 1 << 2,
} wireless_hardware_t;


typedef enum wireless_uart_config_e
{
	UART_CONFIG_AT_CMD,
	UART_CONFIG_MSG,
} wireless_uart_config_t;


// Prototypes
wireless_hardware_t Wireless_GetWirelessHardwareType(void);
bool Wireless_DetermineModuleType(void);
void Wireless_ResetModuleType(void);

#ifdef __cplusplus
}
#endif


#endif

