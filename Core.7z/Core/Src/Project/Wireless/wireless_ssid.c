// Rex Bionics Ltd (c) Copyright 2023
//#include "cool_typedefs.h"

#include "project.hpp"
//#include "managers/manager_user_interface.h"
#include "wireless_ssid.h"
#include "../Utils/sha1.h"
#include "../Utils/ascii_conversion.h"

extern UINT32 system_millisecond_ticker;


// SSID storage buffers
static UINT8 WiFi_SSID_Name[WIFI_SSID_NAME_LEN] = {0};
static UINT8 WiFi_SSID_Code[WIFI_SSID_CODE_LEN] = {0};
static UINT8 WiFi_SSID_Valid = false;


//===================================================================
// Create a unique SSID for Wi-Fi
// Append a SHA1(time-stamp) to the WiFi name to make it unique
//===================================================================
void Wireless_createUniqueSSID(void)
{
	SHA1_Type ctxSHA;
	UINT8 hash[20];
	UINT8 data[20];
	UINT16 resultLen;

	// Get random time from system
	for( UINT8 i=0 ; i<5 ; i++) {
		long_time_ms_t currentTime = system_millisecond_ticker;
		memcpy(data+4*i, &currentTime, 4);
	}

	// Compute a SHA on this data
	SHA1_Init(&ctxSHA);
	SHA1_Update(&ctxSHA, (UINT8*)data, 20);
	SHA1_GenerateHash(&ctxSHA, hash);

	// Convert the first 2 bytes into displayable ASCII
	// Displayable value is stored in 'data'
	HEXToASCII( hash, 2, data, &resultLen );

	// The SSID is 13 characters long: "REX-WIFI-XXXX"
	UINT8 temp_ssid[] = WIFI_BASE_SSID_NAME; // "REX-WIFI-xxxx\0";
	memcpy(&temp_ssid[WIFI_SSID_CODE_OFFSET], &data[0], WIFI_SSID_CODE_LEN);


	// for( UINT8 i=0 ; i<WIFI_SSID_CODE_LEN ; i++ )
	// 	temp_ssid[WIFI_SSID_CODE_OFFSET+i] = data[i];

	// Copy created data into storage buffers
	Wireless_setSSIDName(temp_ssid);
	Wireless_setSSIDCode(data);

	Wireless_setSSIDValid(true);
}


// Creates the text that is displayed on the UI
void Wireless_getWiFi_UI_Message(char* store)
{
	// Store the new code in m_ui
	memcpy( &store[0], WIFI_CODE_UI_MSG, WIFI_CODE_UI_MSG_LEN );
	memcpy( &store[WIFI_CODE_UI_MSG_LEN], Wireless_getSSIDCode(), WIFI_SSID_CODE_LEN );
	store[WIFI_UI_MESSAGE_LEN-1] = 0;
}



// Set the SSID name
void Wireless_setSSIDName(UINT8* ssid) {
	memcpy( &WiFi_SSID_Name[0], ssid, WIFI_SSID_NAME_LEN );
}

// Return pointer to the full SSID name
UINT8* Wireless_getSSIDName(void) {
	return &WiFi_SSID_Name[0];
}

// Getter and Setter for SSID code
void Wireless_setSSIDCode(UINT8* code) {
	memcpy( &WiFi_SSID_Code[0], code, WIFI_SSID_CODE_LEN );
}

UINT8* Wireless_getSSIDCode(void) {
	return &WiFi_SSID_Code[0];
}

// Sets valid to true if the SSID has been created
// It is set to false when wireless module is powered on.
bool Wireless_isSSIDValid(void) {
	return WiFi_SSID_Valid;
}

void Wireless_setSSIDValid(bool value) {
	WiFi_SSID_Valid = value;
}
