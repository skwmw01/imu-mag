// Rex Bionics Ltd (c) Copyright 2015
#include "wireless_interface.h"
#include "wireless_lib.h"



// Indicates which wireless interface is being used (BT or WiFi)
static active_interface_t wirelessActiveInterface = INTERFACE_NONE;


//=============================================================================
// Active Interface
// Returns what type of interface is being used (WiFi or BT)
//=============================================================================
bool Wireless_isActive(active_interface_t usingInterface) {
	return (wirelessActiveInterface == usingInterface) ? true : false;
}

bool Wireless_isInterface(active_interface_t interface) {
	return interface == wirelessActiveInterface;
}

void Wireless_setActive(active_interface_t usingInterface) {
	wirelessActiveInterface = usingInterface;
}

