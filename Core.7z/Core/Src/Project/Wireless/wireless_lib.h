// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_LIB_H
#define __WIRELESS_LIB_H

#include "wireless_detect.h"
//#include "rexlink/manager_pc_comms.h"
//#include "rexlink/pcc_data_fetcher.h"
//#include "forward.h"
#include "project.hpp"

#ifdef __cplusplus
extern "C" {
#endif

// Prototypes
uint8_t* Wireless_GetTransmitBuffer(void);
void Wireless_SendATCommand(const char* cmd);
void SetupUARTConfig(wireless_uart_config_t setting);
void resetReceptionBuffer(void);
void Wireless_setBlockingTimeOut(long_time_ms_t timeOut);


module_response_t 	Wireless_SearchResponseData(void);
long_time_ms_t 		Wireless_QueryRemainingTime( sint32_t timer );

#ifdef __cplusplus
}
#endif

#endif
