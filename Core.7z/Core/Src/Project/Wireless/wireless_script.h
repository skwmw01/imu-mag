// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_SCRIPT_H
#define __WIRELESS_SCRIPT_H

//#include "rexlink/manager_pc_comms.h"
#include "project.hpp"
//#include "forward.h"

// States when running a Script
typedef enum
{
	SCRIPT_IDLE,
	SCRIPT_BEGIN,
	SCRIPT_SEND_AT_CMD,
	SCRIPT_WAIT_RESPONSE,
	SCRIPT_SUCCESS,
	SCRIPT_ERROR,
} script_state_t;


typedef enum script_id_e {
	// ESP32 Access Point MAC Address
	SCRIPT_ID_ESP32_GET_MAC_ADDRESS,

	// ESP32 BT Discovery
	SCRIPT_ID_ESP32_BT_DISCOVERY_ON,
	SCRIPT_ID_ESP32_BT_DISCOVERY_OFF,

	// ESP32 BT Connect/Disconncet
	SCRIPT_ID_ESP32_BT_CONNECT,
	SCRIPT_ID_ESP32_BT_DISCONNECT_ACTIVE,		// Disconnect when BT has an active connection
	SCRIPT_ID_ESP32_BT_DISCONNECT_INACTIVE,		// Disconnect when BT does not have an active connection

	// ESP32 WiFi Connect/Disconncet
	SCRIPT_ID_ESP32_WIFI_ON,
	SCRIPT_ID_ESP32_WIFI_OFF,
	SCRIPT_ID_ESP32_WIFI_DISCONNECT_ACTIVE,		// Disconnect when WiFi has an active connection
	SCRIPT_ID_ESP32_WIFI_DISCONNECT_INACTIVE,	// Disconnect when WiFi does not have an active connection

	// BT740 BT Discovery
	SCRIPT_ID_BT740_BT_DISCOVERY_ON,
	SCRIPT_ID_BT740_BT_DISCOVERY_OFF,
} script_id_t;

bool Wireless_isScriptComplete(void);

bool Wireless_isBTScriptSuccessful(void);
bool Wireless_isWiFiScriptSuccessful(void);

script_state_t Wireless_GetScriptState(void);
void Wireless_SetScriptState(script_state_t newState);

void Wireless_SetScriptToRun(script_id_t scriptID);
script_state_t Wireless_RunScript( void );

#endif
