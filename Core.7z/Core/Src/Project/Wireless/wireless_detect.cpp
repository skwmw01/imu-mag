// Rex Bionics Ltd (c) Copyright 2015
#include "wireless_interface.h"
#include "wireless_lib.h"
#include "wireless_detect.h"

#include "Timer.h"
#include "SystemTicker.h"

#define WIRELESS_DETECT_TIMEOUT			70			// 70ms to get a complete response from module when issuing AT command


#ifdef __cplusplus
extern "C" {
#endif



// Wireless Module Configuration state machine
typedef enum wirelessConfigState_e
{
	DETECT_UNKNOWN,
	DETECT_WAIT_READY,				// Wait for the module to power-up
	DETECT_READY_OK,				// Send AT until we receive an OK
	DETECT_SETUP_UART,
	DETECT_CHECK_IF_ESP32,
	DETECT_CHECK_IF_BT740,
	DETECT_IS_ESP32,
	DETECT_IS_BT740,
	DETECT_FAIL,
	DETECT_SUCCESS,
	DETECT_COMPLETE,
} wirelessConfigState_t;
static wirelessConfigState_t wirelessConfigState = DETECT_UNKNOWN;

// Indicates which wireless module is present
wireless_hardware_t wirelessHardwareType = HARDWARE_NONE;



//=================================================================================================================
// Wireless_GetWirelessHardwareType
//
// Return the type of wireless hardware that is connected to the Rex
//=================================================================================================================
wireless_hardware_t Wireless_GetWirelessHardwareType() {
	return wirelessHardwareType;
}


//=================================================================================================================
// Wireless_ResetModuleType
//
// This resets the settings of the wireless module, so if it is enabled again, the entire process of
// determining which module is connected to the device must be run through again.
//=================================================================================================================
void Wireless_ResetModuleType(void)
{
	wirelessConfigState = DETECT_UNKNOWN;
	wirelessHardwareType = HARDWARE_NONE;
}


//=================================================================================================================
// Wireless_DetermineModuleType
//
// The Main entry point for detecting the type of wireless interface in the Rex.
// Function return value:
//  - true:  An update occurred on the module, so the UI needs to be updated
//  - false: No updates to the module configuration
//
// We have two wireless modules:
//    - ESP32-WROOM-DA (the new one)
//    - BT740 (old one)
//
// 1. First, determine whether the module is a BT740.
// 2. If not a BT740, try a ESP32
//=================================================================================================================
bool Wireless_DetermineModuleType(void)
{
	static uint8_t retryCounter = 0;		// Retries for each device.
	static long_time_ms_t moduleCommandTimeOut;
	static long_time_ms_t moduleDetectTimeOut;
	static module_response_t commandResponse = RESP_UNKNOWN;
	static wirelessConfigState_t tryModuleType = DETECT_CHECK_IF_BT740;



	if( wirelessConfigState == DETECT_COMPLETE )
		return false;

	if( wirelessConfigState == DETECT_UNKNOWN )
		wirelessConfigState = DETECT_SETUP_UART;


	//=============================================================================
	// Determine which wireless module is connected to the Rex
	//=============================================================================
	switch (wirelessConfigState)
	{
		// Setup UART wireless module query mode
		case DETECT_SETUP_UART:
		{
			SetupUARTConfig(UART_CONFIG_AT_CMD);
			wirelessConfigState = DETECT_WAIT_READY;
			retryCounter = 0;

			// Start with a BT740..
			tryModuleType = DETECT_CHECK_IF_BT740;

			// We have 3s to determine the module type.
			moduleDetectTimeOut = system_millisecond_ticker + 3000;
			break;
		}

		// Send an AT command to the module
		// If the module responds with OK, then we know we can communicate with it.
		case DETECT_WAIT_READY:
		{
			// Stop if we can't detect any modules (and we time out)
			if( Wireless_QueryRemainingTime(moduleDetectTimeOut) == 0 )
			{
				wirelessHardwareType = HARDWARE_NONE;
				wirelessConfigState = DETECT_FAIL;
				break;
			}

			// Prompt the module to start responding...
			Wireless_SendATCommand("AT\r\n");
			Wireless_setBlockingTimeOut(20);

			resetReceptionBuffer();
			Wireless_SendATCommand("AT\r\n");

			wirelessConfigState = DETECT_READY_OK;
			moduleCommandTimeOut = system_millisecond_ticker + 20;
			break;
		}

		// Send an 'AT' prompt and see what the reponse is
		case DETECT_READY_OK:
		{
			// Module has 70ms to respond with full response
			if( Wireless_QueryRemainingTime(moduleCommandTimeOut) )
				break;

			commandResponse = Wireless_SearchResponseData();

			if( commandResponse != RESP_OK ) {
				wirelessConfigState = DETECT_WAIT_READY;
				Wireless_setBlockingTimeOut(70);
			} else {
				// 'tryModuleType' indicates which module we're testing for...
				wirelessConfigState = tryModuleType;
				retryCounter = 0;
			}
			break;
		}

		// Check if BT740 is connected by sending a Version command
		case DETECT_CHECK_IF_BT740:
		{
			commandResponse = RESP_UNKNOWN;

			// Version AT-command for the BT740
			resetReceptionBuffer();
			Wireless_SendATCommand("ATI0\r\n");

			moduleCommandTimeOut = system_millisecond_ticker + WIRELESS_DETECT_TIMEOUT;
			wirelessConfigState = DETECT_IS_BT740;
			break;
		}

		// Check if the Wireless module is a BT740
		case DETECT_IS_BT740:
		{
			// Module has 70ms to respond with full response
			if( Wireless_QueryRemainingTime(moduleCommandTimeOut) )
				break;

			retryCounter++;
			commandResponse = Wireless_SearchResponseData();
			resetReceptionBuffer();

			if( commandResponse == RESP_OK )
			{
				wirelessHardwareType = HARDWARE_BT740;
				wirelessConfigState = DETECT_SUCCESS;
			}
			else if (commandResponse == RESP_ERROR)
			{
				// BT740 returned an ERROR, so try for ESP32...
				tryModuleType = DETECT_CHECK_IF_ESP32;
				wirelessConfigState = DETECT_WAIT_READY;
			}
			else
			{
				if( retryCounter < 3 )
					wirelessConfigState = DETECT_CHECK_IF_BT740;
				else
				{
					tryModuleType = DETECT_CHECK_IF_ESP32;
					wirelessConfigState = DETECT_WAIT_READY;
				}
			}
			break;
		}

		// Check if ESP32 is connected by sending a Version command
		case DETECT_CHECK_IF_ESP32:
		{
			// Check if ESP32-WROOM-DA is connected
			commandResponse = RESP_UNKNOWN;

			// Version AT-command for the ESP32
			resetReceptionBuffer();
			Wireless_SendATCommand("AT+GMR\r\n");

			moduleCommandTimeOut = system_millisecond_ticker + WIRELESS_DETECT_TIMEOUT;
			wirelessConfigState = DETECT_IS_ESP32;
			break;
		}

		// Check if the Wireless module is a ESP32
		case DETECT_IS_ESP32:
		{
			// Module has 70ms to respond with full response
			if( Wireless_QueryRemainingTime(moduleCommandTimeOut) )
				break;

			retryCounter++;
			commandResponse = Wireless_SearchResponseData();
			resetReceptionBuffer();

			if( commandResponse == RESP_OK )
			{
				wirelessHardwareType = HARDWARE_ESP32;
				wirelessConfigState = DETECT_SUCCESS;
				break;
			}
			else if (commandResponse == RESP_ERROR)
			{
				wirelessConfigState = DETECT_FAIL;
			}
			else
			{
				if( retryCounter < 3 )
					wirelessConfigState = DETECT_CHECK_IF_ESP32;
				else
				{
					wirelessHardwareType = HARDWARE_NONE;
					wirelessConfigState = DETECT_FAIL;
				}
			}
			break;
		}

		// When detection fails, indicate this on the UI...?? (perhaps a retry)
		case DETECT_FAIL:
		{
			return true;
		}

		case DETECT_SUCCESS:
		{
			// If the module is a BT740, then there is no "Enable BT connection" menu, as this module
			// is setup to connect automatically.  So we need to enable sending messages from the Rex.
			// When the module is a ESP32, the messages are enabled after script execution.
			if( wirelessHardwareType == HARDWARE_BT740 )
				SetupUARTConfig(UART_CONFIG_MSG);

			wirelessConfigState = DETECT_COMPLETE;
			return true;
		}

		default:
		{
			//assert_param(0);
			break;
		}
	}
	return true;
}

#ifdef __cplusplus
}
#endif
