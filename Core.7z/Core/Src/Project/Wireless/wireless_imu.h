/*
 * wireless_imu.h
 *
 *  Created on: May 10, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_PROJECT_WIRELESS_WIRELESS_IMU_H_
#define SRC_PROJECT_WIRELESS_WIRELESS_IMU_H_

void Wireless_IMUScript(void);


#endif /* SRC_PROJECT_WIRELESS_WIRELESS_IMU_H_ */
