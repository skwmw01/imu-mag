// Rex Bionics Ltd (c) Copyright 2023
//#include "cool_typedefs.h"

#include <stddef.h>
#include <string.h>
#include "project.hpp"
#include "wireless_interface.h"
#include "wireless_lib.h"
#include "wireless_detect.h"
#include "wireless_script.h"
#include "wireless_ssid.h"
#include "wireless_bt_mac.h"


extern UINT32 system_millisecond_ticker;

//#include "managers/manager_user_interface.h"


#define WIRELESS_SCRIPT_TIMEOUT 	30 // 500ms response timeout when setting up the wireless module

static void Wireless_WiFi_GetNewCmd(char* currentCmd, char* newCmd);
static void Wireless_BT_GetNewCmd(char* currentCmd, char* newCmd);


// Callback function for Script
typedef void (*script_callback_t)(char* currentCmd, char* newCmd);

//===================================================================================
// Script structure for the Wireless module
//===================================================================================
typedef struct
{
	script_state_t	state;			// State of the script
	uint8_t 		totalCommands;
	uint8_t			respIndex;
	struct {
		char*				at_cmd;
		module_response_t	resp[3];
		script_callback_t	handler;
	} cmd[];
} script_t;


//===================================================================================
// Scripts for Bluetooth Classic on ESP32
// - Turn on BT Discovery
//===================================================================================
static script_t script_ESP32_BT_Get_MAC = {
	SCRIPT_IDLE, 1, 0,
	{
		{"AT+CIPAPMAC?\r\n",				{RESP_OK, RESP_NEXT, RESP_NULL}, NULL },	// Get the MAC address of ESP32 SpftAP
	}
};


//===================================================================================
// Scripts for Bluetooth Classic on ESP32
// - Turn on BT Discovery
//===================================================================================
#define AT_CMD_BT_NAME_OFFSET 	11

static script_t script_ESP32_BT_Discovery_On = {
	SCRIPT_IDLE, 6, 0,
	{
		{"AT+CIPAPMAC?\r\n",					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Get the MAC address of ESP32 SoftAP
		{"AT+BTINIT=1\r\n",						{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Setup ESP32 as Classic-BT
		{"AT+BTSPPINIT=2\r\n",					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Setup as Slave (1=Master, 2=Slave)
		{"AT+BTNAME=\""BT_BASE_NAME"\"\r\n", 	{RESP_OK, RESP_NEXT, RESP_NULL}, Wireless_BT_GetNewCmd},		// Set the Name
		{"AT+BTSCANMODE=2\r\n",					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Discoverable and connectable (For discovery and pairing)
		{"AT+BTSECPARAM=3,0,\"1234\"\r\n",		{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// PIN code will be ignored
		// {"AT+BTSPPSTART\r\n",				{RESP_OK, RESP_NULL, RESP_NULL}}				// Enter Classic Bluetooth SPP mode (Issued once we receive a 'CONNECT')
	}
};


//===================================================================================
// Neither discoverable nor connectable - Bluetooth Classic
// The module is not connected (or in passthru mode), so this will work.
// - Turn off BT Discovery
//===================================================================================
static script_t script_ESP32_BT_Discovery_Off = {
	SCRIPT_IDLE, 1, 0, {
		{"AT+RST\r\n", {RESP_OK, RESP_NEXT, RESP_NULL}, NULL},
	}
};


//===================================================================================
// Enable BT Classic connection for ESP32
// Connectable, but not Discoverable
//===================================================================================
static script_t script_ESP32_BT_Connect = {
	SCRIPT_IDLE, 9, 0,
	{
		{"AT+CIPAPMAC?\r\n",					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Get the MAC address of ESP32 SoftAP
		{"AT+BTINIT=1\r\n", 					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Setup ESP32 as Classic-BT
		{"AT+BTSPPINIT=2\r\n", 					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Setup as Slave (1=Master, 2=Slave)
		{"AT+BTNAME=\""BT_BASE_NAME"\"\r\n", 	{RESP_OK, RESP_NEXT, RESP_NULL}, Wireless_BT_GetNewCmd},		// Set the Name
		{"AT+BTSCANMODE=1\r\n",					{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Connectable, but not Discoverable
		{"AT+BTSECPARAM=3,0,\"1234\"\r\n", 		{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// PIN code will be ignored
		{"AT+BTSPPSTART\r\n",					{RESP_OK, RESP_CONNECT, RESP_NEXT}, NULL},		// Start Classic Bluetooth SPP Profile (Once CONNECT is received, issue the next command)
		{"ATE0\r\n",							{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},			// Echo Off. This has to be set here... otherwise module does not respond with any responses.
		{"AT+BTSPPSEND\r\n",					{RESP_OK, RESP_NULL, RESP_NULL}, NULL}			// Enter Classic Bluetooth SPP mode (Issued once we receive a 'CONNECT')
	}
};


//=======================================================================================================
// Disable BT connection.
// - We need to disable BT connection differently depending on the current state of the module.
// - Use this if the module has not established an active connection with the PC, but is currently
//   waiting to connect ...
//=======================================================================================================
static script_t script_ESP32_BT_Inactive_Disconnect = {
	SCRIPT_IDLE, 2, 0,
	{
		{"AT+BTINIT=0\r\n",			{RESP_OK, RESP_NEXT, RESP_NULL}, NULL}, 	// Deinitialise Classic BT
		{"ATE1\r\n",				{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},		// Echo On
	}
};


//=======================================================================================================
// Disable BT connection (Disconnect)
// 2. If the module has established an active connection with the PC
//    --> we can't reset the module, as it is in 'pass-through' mode (command will simply pass-thru)
//    --> Issue a +++ (hangup, exit pass-through mode)
//    --> Issue a AT+RST (reset, it's the simplest)
//=======================================================================================================
static script_t script_ESP32_BT_Active_Disconnect = {
	SCRIPT_IDLE, 4, 0,
	{
		{"+++", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},			// +++ (hangup) does not have a respone, so it'll be unknown...
		{"AT\r\n", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},			// Don't care about response...
		{"AT\r\n", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},			// Don't care about response...
		{"AT+RST\r\n", 				{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},
	}
};

//===================================================================================
// Script commands for BT740
//===================================================================================
// Discoverable = YES, Connectable = YES
static script_t script_BT740_BT_Discovery_On = {
 	SCRIPT_IDLE, 1, 0,
	{
		{"AT+BTP\n\r", {RESP_OK, RESP_NEXT, RESP_NULL}, NULL}
	}
};

// Discoverable = NO, Connectable = YES
static script_t script_BT740_BT_Discovery_Off = {
	SCRIPT_IDLE, 1, 0,
	{
		{"AT+BTG\n\r", {RESP_OK, RESP_NEXT, RESP_NULL}, NULL}
	}
};


//===============================================================================================
// Scripts for WiFi on ESP32
// NB: - The 'REX-WIFI-XXXX' string will be replaced with the proper SSID string,
//       where XXXX will be a unique number
//     - We hard-code the index to the script that contains the "REX-WIFI-xxxx" name,
//       so if commands are prepended to this strucutre, the function "Wireless_SetSSID"
//       must also be changed
//===============================================================================================
#define AT_CMD_SSID_OFFSET 	10

static script_t script_ESP32_WiFi_On = {
	SCRIPT_IDLE, 6, 0,
	{
		{"AT+CWMODE=2,0\r\n",										{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},					// Setup wireless as SoftAP
		{"AT+CIPAP=\"192.168.10.1\"\r\n",							{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},					// Set the module IP address
		{"AT+CWSAP=\""WIFI_BASE_SSID_NAME"\",\"\",5,0,1,1\r\n",		{RESP_OK, RESP_NEXT, RESP_NULL}, Wireless_WiFi_GetNewCmd},	// SSID, no password, channel, encryption, max-conn, 1 = not broadcasting SSID (0 = broadcasting)
		{"AT+CIPSTART=\"UDP\",\"192.168.10.2\",49200,49300,0\r\n",	{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},					// Remote IP, Remote Port, Local Port, Keep Alive
		{"AT+CIPMODE=1\r\n",										{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},					// Enter the UART Wi-Fi Passthrough Receiving Mode.
		{"AT+CIPSEND\r\n",											{RESP_OK, RESP_NEXT, RESP_NULL}, NULL}					// Enter the UART Wi-Fi Passthrough Mode and send data.
	}
};


//=================================================================================================================
// When Hanging up, this is from the ESP online docs:
// https://docs.espressif.com/projects/esp-at/en/latest/esp32/AT_Command_Set/TCP-IP_AT_Commands.html#cmd-plus
//
// - This special execution command consists of three identical + characters (0x2b ASCII), and no CR-LF
//   appends to the command tail.
// - Make sure there is more than 20 ms interval before the first + character, more than 20 ms interval after
//   the third + character, less than 20 ms interval among the three + characters. Otherwise, the + characters
//   will be sent out as normal data.
// - This command returns no reply.
// - Please wait for at least one second before sending the next AT command.
//=================================================================================================================
static script_t script_ESP32_WiFi_Off = {
	SCRIPT_IDLE, 5, 0,
	{
		{"+++", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},	// +++ (hangup) does not have a respone, so it'll be unknown...
		{"AT\r\n", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},	// Don't care about response...
		{"AT\r\n", 					{RESP_UNKNOWN, RESP_NEXT, RESP_NULL}, NULL},	// Don't care about response...
		{"AT+CWMODE=0\r\n",			{RESP_OK, RESP_NEXT, RESP_NULL}, NULL},
		{"AT+RST\r\n", 				{RESP_READY, RESP_NEXT, RESP_NULL}, NULL},		// Look for a 'ready' response
	}
};


//================================================================
// Script IDs
//================================================================
typedef struct
{
	UINT8		scriptID;
	script_t*	script;
} scripts_t;


//==========================================================================================
// NB - IMPORTANT - NB
// The order of these must be the same as the order in the 'script_id_e' definition.
//==========================================================================================
scripts_t scripts[] = {
	// Get MAC address of AP
	{SCRIPT_ID_ESP32_GET_MAC_ADDRESS, &script_ESP32_BT_Get_MAC},

	// BT - Bluetooth Classic Discovery
	{SCRIPT_ID_ESP32_BT_DISCOVERY_ON, &script_ESP32_BT_Discovery_On},
	{SCRIPT_ID_ESP32_BT_DISCOVERY_OFF, &script_ESP32_BT_Discovery_Off},

	// BT - Bluetooth Classic Connect/Disconnect
	{SCRIPT_ID_ESP32_BT_CONNECT, &script_ESP32_BT_Connect},
	{SCRIPT_ID_ESP32_BT_DISCONNECT_ACTIVE, &script_ESP32_BT_Active_Disconnect},
	{SCRIPT_ID_ESP32_BT_DISCONNECT_INACTIVE, &script_ESP32_BT_Inactive_Disconnect},

	// BLE - Bluetooth Low Energy
	//{SCRIPT_ID_ESP32_BT_CONNECT, &script_ESP32_BT_Connect},

	// Wifi still to be tested...
	{SCRIPT_ID_ESP32_WIFI_ON, &script_ESP32_WiFi_On},
	{SCRIPT_ID_ESP32_WIFI_OFF, &script_ESP32_WiFi_Off},
	{SCRIPT_ID_ESP32_WIFI_DISCONNECT_ACTIVE, &script_ESP32_WiFi_Off},
	{SCRIPT_ID_ESP32_WIFI_DISCONNECT_INACTIVE, &script_ESP32_WiFi_Off},

	// BT740 Script IDs
	{SCRIPT_ID_BT740_BT_DISCOVERY_ON, &script_BT740_BT_Discovery_On},
	{SCRIPT_ID_BT740_BT_DISCOVERY_OFF, &script_BT740_BT_Discovery_Off},
};

// Current script that is being executed
static script_t *executingScript = NULL;



//=================================================================================================
// This returns whether the BT connection has an active connection with a PC (external device)
//
// NB: Script state becomes IDLE once it completed SUCCESSFULLY
//     Strictly speaking, checking SUCCESS here is not necessary.
//=================================================================================================
bool Wireless_isBTScriptSuccessful(void)
{
	script_t* s = scripts[SCRIPT_ID_ESP32_BT_CONNECT].script;
	if( s->state == SCRIPT_SUCCESS || s->state == SCRIPT_IDLE )
		return true;

	return false;
}


bool Wireless_isWiFiScriptSuccessful(void)
{
	script_t* s = scripts[SCRIPT_ID_ESP32_WIFI_ON].script;
	if( s->state == SCRIPT_SUCCESS || s->state == SCRIPT_IDLE )
		return true;

	return false;
}

//=================================================================================================================
// Sets the Script that is currently being executed
//=================================================================================================================
void Wireless_SetScriptToRun(script_id_t scriptID)
{
	executingScript = scripts[scriptID].script;
}


//=================================================================================================================
// Get the Script state
//=================================================================================================================
script_state_t Wireless_GetScriptState(void)
{
	if (executingScript == NULL)
		return SCRIPT_IDLE;

	return executingScript->state;
}


//=================================================================================================================
// Set the Script state
//=================================================================================================================
void Wireless_SetScriptState(script_state_t newState)
{
	if (executingScript)
		executingScript->state = newState;
}


//=================================================================================================================
// Returns whether the module is connected or not
//  true - module is currently connected
//  false - module is not currently connected
//=================================================================================================================
bool Wireless_isScriptComplete()
{
	if( executingScript == NULL )
		return false;

	switch( executingScript->state )
	{
		case SCRIPT_IDLE:
		case SCRIPT_SUCCESS:
		case SCRIPT_ERROR:
			return true;

		default:
			return false;
	}
}


//========================================================================================
// Create a new SSID name
//========================================================================================
static void Wireless_WiFi_GetNewCmd(char* currentCmd, char* newCmd)
{
	UINT8 cmdLen = strlen(currentCmd);

	// Copy the existing command
	strcpy( &newCmd[0], &currentCmd[0] );

	// Overwrite the existing SSID with the new one
	memcpy( &newCmd[AT_CMD_SSID_OFFSET], Wireless_getSSIDName(), WIFI_SSID_NAME_LEN );

	// Copy the command into the Send buffer (a buffer that will not be overwritten)
	uint8_t* txBuffer = Wireless_GetTransmitBuffer();
	memcpy( txBuffer, newCmd, cmdLen );
	txBuffer[cmdLen] = 0;
}


//========================================================================================
// Create a BT name
//========================================================================================
static void Wireless_BT_GetNewCmd(char* currentCmd, char* newCmd)
{
	UINT8 cmdLen = strlen(currentCmd);


	// Copy the existing command
	strcpy( &newCmd[0], &currentCmd[0] );

	// Overwrite the existing BT name and code
	Wireless_setBTName((UINT8*)BT_BASE_NAME);
	memcpy( &newCmd[AT_CMD_BT_NAME_OFFSET], Wireless_getBTName(), BT_BASE_NAME_LEN );
	memcpy( &newCmd[AT_CMD_BT_NAME_OFFSET+BT_BASE_CODE_OFFSET], Wireless_getBTCode(), BT_BASE_CODE_LEN );

	// Show the Code in the UI.
	// The menu is forced updated here as this code is run from a Script, not run from joystick movement
	Wireless_setBTValid(true);
	//mngUserInterface_ShowWirelessCode(true);
	//mngUserInterface_MenuUpdateUI();

	// Copy the command into the Send buffer (a buffer that will not be overwritten)
	uint8_t* txBuffer = Wireless_GetTransmitBuffer();
	memcpy( txBuffer, newCmd, cmdLen );
	txBuffer[cmdLen] = 0;
}


//=================================================================================================================
// Execute the supplied Script
//
// Note: The hard-coded script command may need to be changed dynamically.
//       We change it when we change the SSID name - we change the code in the SSID name.
//       This is the reason we need to firat copy the command from FLASH into RAM before we can update the data.
//=================================================================================================================
script_state_t Wireless_RunScript(void)
{
	char newCmd[128];			// NB - The command length must be less than buffer length.

	static uint8_t cmdIndex = 0;
	static long_time_ms_t moduleCommandTimeOut;
	module_response_t moduleResponse;



	// Setup module to enable WiFi
	switch (executingScript->state)
	{
	case SCRIPT_IDLE:
		executingScript->state = SCRIPT_BEGIN;
		break;

	case SCRIPT_BEGIN:
		// Before executing any scripts, we need to set UART (Rex) to stop sending any messages,
		// as these will interfere with the script commands.
		SetupUARTConfig(UART_CONFIG_AT_CMD);

		for (uint8_t i = 0; i < 3; i++) {
			Wireless_SendATCommand("AT\r\n");
			Wireless_setBlockingTimeOut(20);
		}

		executingScript->state = SCRIPT_SEND_AT_CMD;
		executingScript->respIndex = 0;
		cmdIndex = 0;
		break;

	case SCRIPT_SEND_AT_CMD:
	{
		// Are there any commands left to execute
		if (cmdIndex == executingScript->totalCommands)
		{
			executingScript->state = SCRIPT_SUCCESS;
			SetupUARTConfig(UART_CONFIG_MSG);
			break;
		}

		char* cmd = executingScript->cmd[cmdIndex].at_cmd;

		// Check if there's some function to execute for this script command.
		if( executingScript->cmd[cmdIndex].handler )
		{
			executingScript->cmd[cmdIndex].handler( cmd, newCmd );
			cmd = (char*) Wireless_GetTransmitBuffer();
		}

		// Clear the RX buffer before sending a new AT command
		resetReceptionBuffer();
		Wireless_SendATCommand(cmd);
		executingScript->state = SCRIPT_WAIT_RESPONSE;
		moduleCommandTimeOut = system_millisecond_ticker + WIRELESS_SCRIPT_TIMEOUT;
		break;
	}

	case SCRIPT_WAIT_RESPONSE:
		// Module has 70ms to respond with full response
		if (Wireless_QueryRemainingTime(moduleCommandTimeOut))
			break;

		// Get the response from the module, as well as the response we are looking for from the Script
		moduleResponse = Wireless_SearchResponseData();
		module_response_t scriptResponse = executingScript->cmd[cmdIndex].resp[executingScript->respIndex];

		// If we don't care about the response, set the script action to this value
		if( scriptResponse == RESP_UNKNOWN )
		{
			cmdIndex++;
			executingScript->state = SCRIPT_SEND_AT_CMD;
			executingScript->respIndex = 0;
			break;
		}

		// Did we receive the response we're expecting? (Like an OK?)
		if (moduleResponse == scriptResponse)
		{
			// Then look at the next action in the list...
			executingScript->respIndex++;
			scriptResponse = executingScript->cmd[cmdIndex].resp[executingScript->respIndex];

			// Reference the next AT command
			if (scriptResponse == RESP_NEXT || scriptResponse == RESP_NULL) {
				cmdIndex++;
				executingScript->state = SCRIPT_SEND_AT_CMD;
				executingScript->respIndex = 0;
				break;
			}
		}

		if (moduleResponse == RESP_ERROR) {
			executingScript->state = SCRIPT_ERROR;
			break;
		} else {
			// Here, we might have missed the response, or it hasn't come through yet.
			executingScript->state = SCRIPT_WAIT_RESPONSE;
			moduleCommandTimeOut = system_millisecond_ticker + WIRELESS_SCRIPT_TIMEOUT;
		}
		break;

	// These states will not be executed...
	case SCRIPT_SUCCESS:
		executingScript->state = SCRIPT_SUCCESS;
		break;

	case SCRIPT_ERROR:
		executingScript->state = SCRIPT_ERROR;
		break;
	}
	return executingScript->state;
}

