// Rex Bionics Ltd (c) Copyright 2015
#include "wireless_lib.h"
//#include "comms/cdi_usart_full_duplex.h"
#include "wireless_bt_mac.h"

#include <stdio.h>
#include <string.h>
#include "project.hpp"
#include "main.h"


typedef struct bus_buffer_configuration_s
{
	uint32_t* transmit_buffer;            	// These buffers must be aligned to 32 bit boundary
	uint16_t  transmit_buffer_length_u32; 	// Length in units of uint32_t
	uint32_t* receive_buffer;             	// These buffers must be aligned to 32 bit boundary
	uint16_t  receive_buffer_length_u32;  	// Length in units of uint32_t
} bus_buffer_configuration_t;



char transmit_buffer[1024];
char receive_buffer[1024];



extern UINT32 system_millisecond_ticker;
extern UART_HandleTypeDef huart3;



static bool getMACAddressFromString(const char* data, UINT8* mac);


static uint32_t received_data_count[4] = {0}; // Used to keep track of partially received response data
static uint8_t port = 0;

// Config code must define these constants and data tables:
//extern const cdi_usart_full_duplex_configuration_item_t cdi_usart_full_duplex_configuration[MIN_SIZE1(TOTAL_USART_FULL_DUPLEX_CONFIGURATION_ITEMS)];
//extern void CDI_USART_Enable_FullDuplex_For_Messaging(void);
static bool searchForString(const char *haystack, uint16_t haystackLen, const char *needle, uint16_t needleLen);



//======================================================================================================
//
//======================================================================================================
void Wireless_QueryTransferCompleteInterrupt(uint8_t usart_port, uint32_t received_bytes)
{
	(void)usart_port;
	(void)received_bytes;
}


//============================================================================
// Send an AT command to the module
//============================================================================
void Wireless_SendATCommand(const char *cmd)
{
	HAL_UART_Transmit(&huart3, (uint8_t *)cmd, strlen(cmd), 1000);

	//HAL_UART_Transmit_IT(&huart3, (uint8_t *)cmd, strlen(cmd));


	//	CommsUSART_SetTxBuffer(DEV_BUS_TYPE_PORT_1, (uint8_t *)cmd, strlen(cmd), false);
//	CommsUSART_EnableTransmit(DEV_BUS_TYPE_PORT_1, true);
}

//============================================================================
// Returns the global Transmit buffer
//============================================================================
uint8_t* Wireless_GetTransmitBuffer(void)
{
	// The first entry in the struct is the wireless UART config
//	bus_buffer_configuration_t const *buffers = &cdi_usart_full_duplex_configuration[0].buffer_configuration;

	return (uint8_t*)&transmit_buffer[0];
}


//=================================================================================================================
// Resets the pointers into the UART RX Buffers
//=================================================================================================================
void resetReceptionBuffer()
{
	for (uint8_t i = 0; i < 4; i++)
		received_data_count[i] = 0;

	// The first entry in the struct is the wireless UART config
//	bus_buffer_configuration_t const *buffers = &cdi_usart_full_duplex_configuration[0].buffer_configuration;

//	CommsUSART_SetRxBuffer(
//		DEV_BUS_TYPE_PORT_1,
//		(uint8_t *)&buffers->receive_buffer[0],
//		4 * buffers->receive_buffer_length_u32);
}

void Wireless_setBlockingTimeOut(long_time_ms_t timeOut)
{
	long_time_ms_t waitTime = system_millisecond_ticker + timeOut;

	// A blocking wait...
	while (Wireless_QueryRemainingTime(waitTime) > 0)
		;
}


//======================================================================================================
// Wireless_QueryReceiveDataInterrupt
//
// Buffer the response as it is received from the wireless module.
//======================================================================================================
void Wireless_QueryReceiveDataInterrupt(uint8_t usart_port, uint32_t received_bytes)
{
//	bus_buffer_configuration_t const *buffers;
//	uint16_t totalReceived = 0;

//	port = usart_port;
//	CommsUSART_EnableReceive(usart_port, false);

	// Assign the buffer configuration to an easily referenced variable
//	buffers = &cdi_usart_full_duplex_configuration[usart_port - 1].buffer_configuration;

//	received_data_count[usart_port - 1] += received_bytes;
//	totalReceived = received_data_count[usart_port - 1];

	// Attempt to receive the remainder of the response data
	// We offset the buffers to append any additional incoming data on to the end of the already received data.
//	assert_param(0 < ((4 * (sint32_t)(buffers->receive_buffer_length_u32)) - (sint32_t)totalReceived)); // Make sure we set the receive buffer to a valid size

//	CommsUSART_SetRxBuffer(usart_port, ((uint8_t *)buffers->receive_buffer) + totalReceived, (4 * buffers->receive_buffer_length_u32) - totalReceived);
//	CommsUSART_EnableReceive(usart_port, true);
}


//=================================================================================================================
// UARTConfig
//
// Setup the UART port to be able to query the wireless module.
// This requires the UART port to be able to send AT commands and receive responses without interference from
// normal messages being sent and received.
//
// The wireless board uses UART Port 1 to communicate with the MC
//=================================================================================================================
void SetupUARTConfig(wireless_uart_config_t setting)
{
	if (setting == UART_CONFIG_AT_CMD)
	{
//		CDI_USART_Disable_FullDuplex_For_Messaging();
//		resetReceptionBuffer();
//
//		CommsUSART_RegisterInterruptHandlers(
//			DEV_BUS_TYPE_PORT_1,
//			Wireless_QueryTransferCompleteInterrupt,
//			NULL,
//			Wireless_QueryReceiveDataInterrupt);
//
//		// The first entry in the struct is the wireless UART config
//		cdi_usart_full_duplex_configuration_item_t const *configPtr = &cdi_usart_full_duplex_configuration[0];
//
//		CommsUSART_SetRxBuffer(
//			DEV_BUS_TYPE_PORT_1,
//			(uint8_t *)(configPtr->buffer_configuration.receive_buffer),
//			4 * (configPtr->buffer_configuration.receive_buffer_length_u32));
//
//		CommsUSART_EnableReceive(DEV_BUS_TYPE_PORT_1, true);
	}

	if (setting == UART_CONFIG_MSG)
	{
	//	CDI_USART_Enable_FullDuplex_For_Messaging();
	}
}



//=================================================================================================================
// Returns 0, or the time remaining until the bluetooth discoverable mode will be disabled
//=================================================================================================================
long_time_ms_t Wireless_QueryRemainingTime(sint32_t timer)
{
//	sint32_t remaining_time = (sint32_t)timer - (sint32_t)system_millisecond_ticker;

	sint32_t remaining_time = (sint32_t)timer - (sint32_t)system_millisecond_ticker;
	if (remaining_time > 0)
		return (long_time_ms_t)remaining_time;
	else
		return 0;
}


//======================================================================================================
// This searches the response data for certain characters
//======================================================================================================
module_response_t Wireless_SearchResponseData(void)
{
	bool found;
	uint16_t totalReceived;
	bus_buffer_configuration_t const *buffers;


	totalReceived = received_data_count[port - 1];
//	buffers = &cdi_usart_full_duplex_configuration[port - 1].buffer_configuration;

	//===================================================================================================
	// Response commands from the wireless module vary in size, and there is no set size.
	// All responses end with either an 'OK' or 'ERROR', and only if we receive one of these in the
	// response, we know we have received all the response bytes.
	//
	// Note: If we're searching for specific strings, we need to look for those before we look for an
	//       'OK' as they will be placed before the OK part
	//===================================================================================================
	found = false;
	if (totalReceived >= 9)
	{
		// Search for 'BTSPPCONN'
		found = searchForString((const char *)buffers->receive_buffer,
								totalReceived,
								(const char *)"BTSPPCONN", 9);
		if (found)
			return RESP_CONNECT;

		// Search for MAC address
		found = searchForString((const char *)buffers->receive_buffer,
								totalReceived,
								(const char *)"+CIPAPMAC:", 10);
		if (found)
		{
			UINT8 BT_MAC_Address[4];

			getMACAddressFromString((const char*)buffers->receive_buffer, BT_MAC_Address);
			Wireless_setBTCode(BT_MAC_Address);
			return RESP_OK;
		}

		// Search for 'ready' after module Reset
		found = searchForString((const char *)buffers->receive_buffer,
								totalReceived,
								(const char *)"ready", 5);
		if (found)
			return RESP_READY;

		// Search for 'OK\r\n'
		found = searchForString((const char *)buffers->receive_buffer,
								totalReceived,
								(const char *)"OK\r\n", 4);
		if (found)
			return RESP_OK;


		// Search for 'ERROR'
		found = searchForString((const char *)buffers->receive_buffer,
								totalReceived,
								(const char *)"ERROR", 5);
		if (found)
			return RESP_ERROR;


	}
	return RESP_UNKNOWN;
}


//======================================================================================================
// Search for a specific string in the data string.
//======================================================================================================
static bool searchForString(const char *haystack, uint16_t haystackLen, const char *needle, uint16_t needleLen)
{
	uint16_t haystackIdx = 0;
	uint16_t needleIdx = 0;
	uint16_t foundCounter = 0;


	while (haystackIdx < haystackLen)
	{
		if (haystack[haystackIdx] == needle[needleIdx])
		{
			foundCounter++;
			needleIdx++;
			if (needleLen == foundCounter)
				return true; // found needle in the haystack :)
		}
		haystackIdx++;
	}
	return false;
}


//======================================================================================================
// Search for a specific string in the data string.
// The MAC Address is returned in the format: +CIPAPMAC:"AA:BB:CC:DD:EE:FF"\r\n\r\nOK\r\n
//======================================================================================================
static bool getMACAddressFromString(const char* data, UINT8* mac)
{
	UINT16 firstQuote = 0;
	UINT16 lastQuote = 0;
	char* result;

	// Find the first "
	result = strchr((const char*)data, (int)'"');
	if( result != NULL ) {
		firstQuote = result - data;
	}

	// Find the second "
	result = strrchr((const char*)data, (int)'"');
	if( result != NULL ) {
		lastQuote = result - data;
	}

	// Get the last 2 bytes from the MAC (they seem to differ between boards)
	if( firstQuote && lastQuote ) {
		memcpy( &mac[0], &data[lastQuote-5], 2 );
		memcpy( &mac[2], &data[lastQuote-2], 2 );
	}

	return true;
}



