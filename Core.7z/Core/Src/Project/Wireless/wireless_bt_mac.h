// Rex Bionics Ltd (c) Copyright 2015
#ifndef __WIRELESS_BT_MAC_H
#define __WIRELESS_BT_MAC_H

//#include "rexlink/manager_pc_comms.h"
//#include "forward.h"
//#include "cool_typedefs.h"

#include "project.hpp"



// Sets the name of the BT device
#define BT_BASE_NAME			"REX-BT-XXXX"		// 11
#define BT_BASE_NAME_LEN		11					// Length of BT_BASE_NAME
#define BT_BASE_CODE_OFFSET		7					// The offset in BT_BASE_NAME where the code starts
#define BT_BASE_CODE_LEN		4					// XXXX - Length of MAC code

// Message displayed on UI: 'BT CODE: xxxx"
#define BT_CODE_UI_MSG 			"REX-BT-"
#define BT_CODE_UI_MSG_LEN 		7

// Used to create buffer storage space in UI struct
#define BT_UI_MESSAGE_LEN		BT_CODE_UI_MSG_LEN + BT_BASE_CODE_LEN + 1

void	Wireless_getBT_UI_Message(char*);
void	Wireless_setBTName(UINT8* ssidName);
UINT8* 	Wireless_getBTName(void);

void 	Wireless_setBTCode(UINT8* code);
UINT8* 	Wireless_getBTCode(void);

bool Wireless_isBTValid(void);
void Wireless_setBTValid(bool value);

UINT8* 	Wireless_getUIMessage(void);

#endif
