/*
 * SPIComms.h
 *
 *  Created on: Mar 7, 2024
 *      Author: Michael.Oleksy
 */

#ifndef SRC_SPICOMMS_H_
#define SRC_SPICOMMS_H_

#include <project.hpp>
#include "main.h"


class SPIBlock
{
public:
	SPIBlock(SPI_HandleTypeDef hspi);
	virtual ~SPIBlock();

	int SendData(UINT8* srcBuffer, UINT16 len);
	int ReceiveData(UINT8* dstBuffer, UINT16 len);

	void setCSHigh();
	void setCSLow();


private:
	SPI_HandleTypeDef spiHandle;
};

#endif /* SRC_SPICOMMS_H_ */
